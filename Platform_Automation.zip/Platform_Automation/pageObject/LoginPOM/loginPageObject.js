/**
 * Created by samrendra_katare on 01-08-2017.
 */

var login_page=function() {
    var username= element(by.css('input#username'));
    var password= element(by.css('input#password'));
    var loginBtn=element(by.css('input#kc-login'));

    //Enter login credentials
    this.enterUserName=function(usrname){
       username.sendKeys(usrname);

    };

    this.enterPassword=function(pass){
        password.sendKeys(pass);

    };

    this.clickLoginButton=function(){
        loginBtn.click();
        console.log('Login successful');
    };
	
	this.login=function(){
		  var loginData=require('../../testData/loginPage.json');
		username.sendKeys(loginData.authentication.login.username);
		password.sendKeys(loginData.authentication.login.password);
		loginBtn.click();
		
	};


}


module.exports=new login_page();