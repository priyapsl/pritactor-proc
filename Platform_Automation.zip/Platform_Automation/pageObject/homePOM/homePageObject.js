
var home_page=function(){

	//Home Page Footer
	var breadcrumb=element(by.css('.sli-large.icon-menu'));
	var termsLink=element(by.css('fng-sidebar ul.footer-list li:nth-child(2) a'));
	var contactsLink=element(by.css('fng-sidebar ul.footer-list li:nth-child(1) a'));
	var privacyLink=element(by.css('fng-sidebar ul.footer-list li:nth-child(3) a'));
	var masterdata=element(by.css('fng-sidebar fng-menu-item-list div:nth-child(4) h3'));
	var legalLink = element(by.css('fng-sidebar ul.footer-list-new-row li:nth-child(1) a'));
	var subsidiaryLink = element(by.cssContainingText('.section>a>h3>span', 'Subsidiaries'));
    var masterdataLink=element(by.cssContainingText('fng-sidebar fng-menu-item-list div:nth-child(4) h3','Master Data'));
    var productsLink=element(by.cssContainingText('.section>a>h3>span', 'Products'));
    var sitesLink=element(by.cssContainingText('.section>a>h3>span', 'Sites'));
    var issuerLink=element(by.cssContainingText('.section>a>h3>span', 'Issuers'));
    var productsLink=element(by.cssContainingText('.section>a>h3>span', 'Products'));
    var branchesLink=element(by.cssContainingText('.section>a>h3>span', 'Branches'));
    var shipmentprovidersLink=element(by.cssContainingText('.section>a>h3>span', 'Shipment Providers'));
    var rapidNewsLink=element(by.cssContainingText('.section>a>h3>span', 'Rapid News'));
    var eventManagementLink=element(by.cssContainingText('.section>a>h3>span', 'Event Management'));


	//Home Page Language Section
        var langdrpdownIcon=element(by.css('.header-icon-panel .fa.fa-caret-down.fa-1.rapid-fa-caret-down '));
        var langdrpdownValues=element(by.css('.dropdown-item .pull-right'));
        var defaultLang=element(by.css('.language-name>span'));

        var flag= false;
        //Home Page Subsidiary link Present
        this.subsidiaryLinkisPresent=function(){
           element.all(subsidiaryLink).then(function(items) {
				expect(items.length).toBe(1);				
                console.log('Subsidary Link is present');	
           });
        };

        

        //Home Page Subsidiary link Click
         clickSubsidiaryLink=function(){
            
                subsidiaryLink.click();
            

        };

         productsLinkisPresent=function(){
            element.all(productsLink).then(function(items) {
				expect(items.length).toBe(1);				
                console.log('Products Link is present');	
            });
        };

         sitesLinkisPresent=function(){
            element.all(sitesLink).then(function(items) {
				expect(items.length).toBe(1);				
                console.log('Sites Link is present');	
            });
        };


        //Home Page Products link click
         clickProductsLink=function(){
                productsLink.click();

        };

         //Home Page Sites link click
        clickSitesLink=function(){
                sitesLink.click();
        };
    //Check If Sites is present (by Default)--Click Sites Link, Else Click on MasterData, then Click Sites Link
    this.clickSitesDirectlyOrClickMasterDataFirst=function(){
        
        element.all(sitesLink).then(function(items) {
               if(items.length==1){
                   clickSitesLink();
                   browser.sleep(5000).then(function(){console.log("Sites link clicked : Present by default")});
               }
                else{
                    clickMasterDataLink();
                    browser.sleep(5000).then(function(){console.log("Masterdata clicked")});
                    clickSitesLink();
                    browser.sleep(5000).then(function(){console.log("Sites link clicked")});
                }
				expect(items.length).toBe(1);				
                console.log('Sites Link is present');	
            });
    };

       

 //Check If Products is present (by Default)--Click Products Link, Else Click on MasterData, then Click Products Link
    
    this.clickProdDirectlyOrClickMasterDataFirst=function(){
        element.all(productsLink).then(function (items) {
                if(items.length==1){
                    productsLink.click();
                    browser.sleep(5000).then(function(){console.log("Clicked on Products link: Present by default")});
                }
                else{
                    masterdataLink.click();
                    browser.sleep(5000).then(function(){console.log("Clicked on MasterData Link")});
                    productsLink.click();
                    browser.sleep(5000).then(function(){console.log("Clicked on Products Link")});
                }
                
            });

    //Check If Subsidiary is present (by Default)--Click Subsidiary Link, Else Click on MasterData, then Click Subsidiary Link
    
    

      this.clickSubDirectlyOrClickMasterDataFirst=function(){

            element.all(subsidiaryLink).then(function (items) {
                if(items.length==1){
                    subsidiaryLink.click();
                    browser.sleep(5000).then(function(){console.log("Clicked on Subsidary click: Present by default")});
                }
                else{
                    masterdataLink.click();
                    browser.sleep(5000).then(function(){console.log("Clicked on MasterData Button")});
                    subsidiaryLink.click();
                    browser.sleep(5000).then(function(){console.log("Clicked on Subsidary click Button")});
                }
                
            });
          /*  if(subsidiaryLink.isPresent()){
                console.log('Subsidiary Link is Present (By Default).');
                subsidiaryLink.click();
                browser.driver.sleep(5000);

            } else
            { console.log('Subsidiary Link Not Present (By Default).');
                this.clickMasterDataLink();
                console.log('Click on Master Data');
                this.clickSubsidiaryLink();
                browser.driver.sleep(5000);
                console.log('Click on Subsidiary Link');
            }*/
        };



    //Home Page Bread Crum link Click
        this.clickBreadCrum=function(){
            breadcrumb.click();

        };

        //Home Page Terms link Present
        this.termsLinkPresent=function(){
            if(termsLink.isPresent()){
                flag=true;
            }
            return flag;
        };

        //Lang Icon Present
        this.langIconPresent=function(){
            if(langdrpdownIcon.isPresent()){
                flag=true;
            }
            return flag;
        };

	//Click Language Dropdown Icon
        this.clickLangIcon=function(){
            if(langdrpdownIcon.isPresent()){
                langdrpdownIcon.click();
                flag=true;
            }
            return flag;
        };
        //Select Languages
        this.selectLang=function(langCode){
            element(by.cssContainingText('.dropdown-item .pull-right', langCode)).click();
            flag=true;
            return flag;
        };

	//Terms Link Click()
	this.clickTermsLink=function(){
		if(termsLink.isPresent()){
			termsLink.click();
            browser.navigate('https://www.gi-de.com/404/');
			flag=true;
		}
		return flag;
	};

        //Home Page Contacts Link Present
        this.contactsLinkPresent=function(){
            if(contactsLink.isPresent()){
                flag=true;
            }
            return flag;
        };
//Contacts Link Click
        this.clickContactsLink=function(){
            if(contactsLink.isPresent()){
                contactsLink.click();
                console.log('HomePage(Theme)--Clicked on Contacts Link');
                browser.navigate('https://www.gi-de.com/en/contact/');
                flag=true;
            }
            return flag;
        };
        //Home Page Privacy Link Present
        this.privacyLinkPresent=function(){
            if(privacyLink.isPresent()){
                flag=true;
            }
            return flag;
        };
//Privacy Link Click
        this.clickPrivacyLink=function(){
            if(privacyLink.isPresent()){
                privacyLink.click();
                browser.navigate('http://10.51.232.73:3000/privacy');
                flag=true;
                console.log('HomePage(Theme)--Clicked on Privacy Link');
            }
            return flag;
        };

        //Home Page Legal Link Present
        this.legalLinkPresent=function(){
            if(legalLink.isPresent()){
                flag=true;
            }
            return flag;
        };
//Legal Link Click
        this.clickLegalLink=function(){
            if(legalLink.isPresent()){
               legalLink.click();
                browser.navigate('http://10.51.232.73:3000/legal');
                console.log('HomePage(Theme)--Clicked on Legal Link');
                flag=true;
            }
            return flag;
        };
//MasterData Link
        //Home Page Legal Link Present
        this.masterdataLinkPresent=function(){
            if(masterdata.isPresent()){
                flag=true;
            }
            return flag;
        };

//MasterData Link Click
        this.clickMasterDataLink=function(){
            if(masterdata.isPresent()){
                masterdataLink.click();
                console.log('HomePage(Theme)--Clicked on Master Data Link');
                flag=true;
            }
            return flag;
        };

    };



module.exports=new home_page();