require('../documentCatgoryPOM/createDocumentCategoryPageObject.js');	
require('../documentCatgoryPOM/detailsDocumentCategoryPageObject.js');
require('../documentCatgoryPOM/editDocumentCategoryPageObject.js');

var docCategory_page=function(){
	//Subsidary Page Button
	var docCategoryText=by.css('.col-md-4>h5');
	var filterButton=by.css('#document_filters_button');
    var deleteButton=by.css('#document_delete_button');
	var createButton=by.css('#document_create_button');
	var exoprtOption=by.css('#site_export_button');
	var delete_Yes_button=by.buttonText('Yes');
	var delete_No_button=by.buttonText('No');
	var delete_PopupMessage=by.css('.modal-body>p');
	var delet_PopUpCloseIcon=by.css('.modal-dialog .confirm-close-icon');
	
	
	//Subsidary Grid table Element
	var checkBoxToSelectAll=by.css('thead .table-checkbox>input');
	var documnet_Category=by.css('.table-responsive thead tr th:nth-child(2)');
	var description=by.css('.table-responsive thead tr th:nth-child(3)');
	var valid_from=by.css('.table-responsive thead tr th:nth-child(4)');	
	var valid_To=by.css('.table-responsive thead tr th:nth-child(5)');	
	var updatedBy=by.css('.table-responsive thead tr th:nth-child(6)');
	var updatedOn=by.css('.table-responsive thead tr th:nth-child(7)');
	
	
	//filter pane elements
	//var filter_SubsidaryCode_drpdwn=by.css('span.btn.btn-default.btn-secondary.form-control.ui-select-toggle'));
	var filterDocCategory_drpdwn=by.css('#document_filter_name .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
	var filter_DocCategory_inputBox=by.css('input.form-control.ui-select-search');	
	var filter_Descrption=by.css('input#description');

	var filter_Clear_Button=by.buttonText('Clear');
	var filter_Apply_Button=by.css('#document_filter_apply_button');
	var filter_CloseIcon=by.css('i.fa.fa-times.close-icon');
	var firstElementFromDropDown=by.css('.ui-select-choices li:nth-child(1) a div');

	
	//Table Element
	var firstRowFromTable=by.css('document-listing fng-table table tbody tr:nth-child(1)');
	var allRowsFromTable=by.css('document-listing fng-table table tbody tr');
	var firstRowEditButton= by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(8) button i');	
	var firstRowDocCategory=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(2) div div');
	var firstRowDescription=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(3) div div');	
	var firstRowUpdatedBy=By.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(6) div div');
	var firstRowUpdatedOn=By.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(7) div div');
	var selectFirstRecordwithCheckbox=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(1) input');
 
	//var descrptionList=by.css('.table-responsive>table>tbody>tr td:nth-child(3) div');
	
	var editIconForEachIssuer=by.css('.table-responsive>table>tbody>tr>td:nth-child(8) i');
    //Pagination
	var nextSingleArrowOfPagination=by.css('li:nth-child(7) .page-link');
	var pageSizeSelector=by.css('#pageSizeSelector');
	var selectSize=by.css('select option[value="0"]');
	var noOfRecordsdisplayed=by.css('.col-sm-5.table-footer-text>p');
	var flag=false;
	
	//Subsidary Page Button Present
	this.docCategoryTextIsPresent=function(){		
		 element.all(docCategoryText).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('docCategoryText is present');				
		});		
		
	};

	
	this.filterButtonIsPresent=function(){		
		element.all(filterButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('docCategory Filter Button is present');				
		});	
	};
	
	this.deleteButtonIsPresent=function(){		
		element.all(deleteButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('issuer Delete Button is present');				
		});
	};
	
	this.deleteButtonIsEnabled=function(){
		if(element(deleteButton).isEnabled()){
			console.log('Delete button is enabled');
			flag=true;
		}
		return flag;
	};
	
	this.createButtonIsPresent=function(){		
		element.all(createButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('docCategory Create Button is present');				
		});
		
	};
	
   	this.exportOptionIsPresent=function(){		
		element.all(exoprtOption).then(function(items) {
				expect(items.length).toBe(1);				
				console.log(' Exoprt OPtion is present');				
		});
		
	};

	//Subsidary Grid Element Present or Not
	this.checkBoxToSelectAllIsPresent=function(){		
       element.all(checkBoxToSelectAll).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('checkBox To Select All element on Page is present');				
		});		
	};
	
	this.clickOnCheckBoxToSelectAllDocumentsOnPage=function(){
		element(checkBoxToSelectAll).click();
        browser.sleep(10000).then(function(){console.log("click on Select all records on page")});
				
	};
	
	this.documnet_CategoryIsPresent=function(){		
        element.all(documnet_Category).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('documnet_Category is present');				
		});				
	};

	this.descriptionIsPresent=function(){		
        element.all(description).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('description is present');				
		});				
	};
	
	
	
	
	
	this.valid_fromIsPresent=function(){	
        element.all(valid_from).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('valid_from is present');				
		});			
	};
	
	this.valid_ToIsPresent=function(){			
        element.all(valid_To).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('valid_To is present');				
		});			
	};
	
	this.updatedByIsPresent=function(){		
        element.all(updatedBy).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('updatedBy is present');				
		});			
	};
	
	this.updatedOnIsPresent=function(){		
        element.all(updatedOn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('updatedOn is present');				
		});			
	};
	
	
	//Click On Filter,Delete,Create Button of Subsidary
	this.clickOnfilterButton=function(){
		element(filterButton).click();		
	};
	
	this.clickOnDeleteButton=function(){
		element(deleteButton).click();		
	};
	
	this.clickOnCreateButton=function(){
		element(createButton).click();
        return require('./createDocumentCategoryPageObject.js');		
	};
	
	this.clickOnDeleteYesButton=function(){
		element(delete_Yes_button).click();
	}
	
	this.clickOnDeleteNoButton=function(){
		element(delete_No_button).click();
	}
	
    this.closeIconOfPopUpIsPresent=function(){		
        element.all(delet_PopUpCloseIcon).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('delet_PopUpCloseIcon is present');				
		});      		
	};

    this.clickOnCloseIconOfPopUp=function(){
			element(delet_PopUpCloseIcon).click();
	};

	this.getTextOfDeletePopup=function(){
		element.all(delete_PopupMessage).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);					  
						itemList[0].getText().then(function(text) {								         
								console.log('Message='+text);
								expect(text).toBe("Are you sure you want to delete the selected records?");		
							 
						});					
			});	
     }
	 
	 this.getTextOfDeletePopupForEntirePage=function(){
		element.all(delete_PopupMessage).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);					  
						itemList[1].getText().then(function(text) {								         
								console.log('Message='+text);
								expect(text).toContain("Records selected");		
							 
						});					
			});	
     }
	 
	//Filter Pane element present verification
	this.filterDocCategory_drpdwnIsPresent=function(){		
        element.all(filterDocCategory_drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filterDocCategory_drpdwn is present');				
		});    	
		
	};
	
	this.filter_DescrptionIsPresent=function(){		
        element.all(filter_Descrption).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Descrption is present');				
		});    			
	};
	
	


	
	
	this.filter_Clear_ButtonIsPresent=function(){		
       element.all(filter_Clear_Button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Clear_Button is present');				
		});   		
	};
	
	this.filter_Clear_ButtonIsNotPresent=function(){		
       element(filter_Clear_Button).getText().then(function(items) {
				expect(items).toBe('');				
				console.log('filter_Clear_Button is not present');				
		});   		
	};

	this.filter_Apply_ButtonIsPresent=function(){		
       element.all(filter_Apply_Button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Apply_Button is present');			
		});  		
	};
	
	this.filter_Apply_ButtonIsNotPresent=function(){		
       element(filter_Apply_Button).getText().then(function(items) {
				expect(items).toBe('');				
				console.log('filter_Apply_Button is not present');				

				
		});  		
	};
	this.filter_CloseIconIsPresent=function(){		
        element.all(filter_CloseIcon).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_CloseIcon is present');				
		});  		
	};
	
	
	this.clickfilter_CloseIcon=function(){
			element(filter_CloseIcon).click();	
			console.log('Clicked on close icon of Filter Pane');
	};
	
	
	this.clickOnfilterDocCategoryDrpdwn=function(){		
		element(filterDocCategory_drpdwn).click();
	};

	
	
	this.enterTextInFilterDocCategoryDrpDown=function(docCategory){
           element(filter_DocCategory_inputBox).sendKeys(docCategory);
	};

	
 

	this.getTextOfFilterIssuerCodeDrpdown=function(){
		element(filter_DocCategory_inputBox).getText().then(function (text) {
			expect(text).toBe("");
			console.log('TextOf filter_DocCategory_inputBox='+text.length);
		});
	};

   this.getTextOffilterDescrption=function(){
     

      element(filter_Descrption).getText().then(function (text) {
		  expect(text).toBe('');
		  console.log('filter_Descrption text length='+text.length);
	  });   
   };
 
 


	this.selectParticularDocumentCategory=function(docCategory){
		console.log('Select particular docCategory ='+docCategory);       
		 element(by.cssContainingText('.dropdown-item>div', docCategory)).click();      
	};

	this.selectParticularProdCode=function(issuerCode){
		console.log('Select particular prod code='+issuerCode);
		element(by.cssContainingText('.dropdown-item>div', issuerCode)).click();

			/*element.all(filter_ProductsCodeList).then(function(itemList) {
				      var flag1=false;
					   var count=0;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						//  var count=0;
						itemList[i].getText().then(function(text) {
						  
							  if (text == productCode) {
								count++;
								//expect(text).toEqual(productCode);
								//break;
								//itemList[i].click();
								console.log('text=prodCode='+text);
							  } 
							 
						});
						
					 };
					 itemList[count].click();				
			});*/
	};

	
	
	this.isParticularIssuerCodePresentInDropDown=function(IssuerCode){
		
			element.all(filter_IssuerCodeList).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						  var count=0;
						itemList[i].getText().then(function(text) {
						  
							  if (text == productCode) {
								count++;
								expect(text).toEqual(IssuerCode);
								//break;
							  } 
							 
						});
					 };
				
			});
		
	};
   

   this.elementsInIssuerCodeDrpDown=function(){
	   element.all(filter_IssuerCodeList).then(function(itemList){
		   console.log("Total values in dropdown are: " + itemList.length);
		   expect(itemList.length>0).toBe(true);
	   });
   }

	this.issuerCodeContaingText=function(IssuerCode){	
		//element(by.cssContainingText('.dropdown-item>div', productCode)).click();

			element.all(filter_IssuerCodeList).then(function(itemList) {
				     
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						//  var count=0;
						itemList[i].getText().then(function(text) {				  
							 
								expect(text.toLowerCase()).toContain(IssuerCode);								
								console.log('text=prodCode='+text);							 
						});
						
					 };					 			
			});
	};
	
  this.issuerCodeNotPresentInDropDown=function(){
      element.all(filter_IssuerCodeList).then(function(itemList) {
          expect(itemList.length).toBe(0);
		  console.log('Elements in list='+itemList.length);
	  });
  };

  this.elementsPresentInDropDown=function(){
      element.all(filter_IssuerCodeList).then(function(itemList) {
          expect(itemList.length>0).toBe(true);
		  console.log('Elements in list are more than 0='+itemList.length);
	  });
  };

	/*issuerCodeDrpdwnContainsAllCode()=function(){
		element.all(filter_ProductsCodeList).then(function(itemList) {			
			expect(itemList.length>0).toBe(true);
		});
	};*/

    this.productDescriptionContaingText=function(description){	
		//element(by.cssContainingText('.dropdown-item>div', productCode)).click();

			element.all(descrptionList).then(function(itemList) {
				      var flag1=false;
					   var count=0;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						//  var count=0;
						itemList[i].getText().then(function(text) {				  
							 
								expect(text).toContain(description);								
								console.log('text=prodCode='+text);							 
						});
						
					 };					 			
			});
	};

	this.isParticularProductCodeNotPresntDropDown=function(productCode){
		  element.all(by.cssContainingText('.dropdown-item>div', productCode)).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('productCode is not present='+items.length);				
		});  	
	};
 
    this.isParticularIssuerNotPresntDropDown=function(issuerCode){
		  element.all(by.cssContainingText('.dropdown-item>div', issuerCode)).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('issuerCode is not present='+items.length);				
		});  	
	};


	this.firstElementFromDropDownIsPresent=function(){		
		 element.all(firstElementFromDropDown).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('firstElementFromDropDown is present');
				
		});		
	};
	
	this.selectFirstElementFromDropDown=function(){		
		element(firstElementFromDropDown).click();
	};
	
	this.clickOnFilterApplyButton=function(){
		element(filter_Apply_Button).click();
	};
	
	this.clickOnFilterClearButton=function(){
		element(filter_Clear_Button).click();
	};
	
	//Table element
	this.firstRowFromTableIsPresent= function(){
	   element.all(firstRowFromTable).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('firstRowFromTable is present');				
		});		
		
	};

	this.firstRowFromTableNotPresent=function(){
		element.all(allRowsFromTable).then(function(items) {
				expect(items.length).toBe(0);
				console.log('item in ='+items.length);
				console.log('elements are not present');
				
		});		
	};

	this.rowCountInTable=function(){
		element.all(allRowsFromTable).then(function(items) {
			     // if(items.length>=1)
				expect(items.length>=1).toBe(true);
				console.log('item in ='+items.length);
				console.log('elements in tables are more than 0');
				
		});		
	};

	this.defaultRecordsInPage=function(){
		element.all(allRowsFromTable).then(function(items) {
			     // if(items.length>=1)
				expect(items.length).toBe(10);
				console.log('item in ='+items.length);
				console.log('elements in tables are 10');
				
		});		
	};
	
	this.eneterTextInFilter_Descrption=function(description)
	{
		element(filter_Descrption).sendKeys(description);
	};
	
	this.clearTextInFilter_Descrption=function()
	{
		element(filter_Descrption).clear();
	};
	
	
	//To read the data of particular column
	this.getDataOfFirstRowParticularColumn=function(columnNo,data){
		
			  element(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).getText().then(function(text){
				  console.log('sjfjgh='+text);
				  expect(text).toBe(data);
				  
			  });

				 // console.log(text);         	
	};
	
	this.dataForParticularColumnIsPresent=function(columnNo){
		
			/*  if(element(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).isPresent()){
				  flag=true;
			  }
				return flag;*/

			element.all(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).then(function(items) {
				var flag=false;
				if(items.length>0){
					flag=true;
				}
				expect(flag).toBe(true);
				console.log('item in ='+items.length);				
		   });	
	};
	
	this.checkEditButtonForIssuer=function(){				 
					
            element.all(editIconForEachIssuer).then(function(items) {				
				expect(items.length>0).toBe(true);
				console.log('item in ='+items.length);				
		   });

	};
	
	

  
	this.clickOnFirstRowsEditButton=function(){
		 element(firstRowEditButton).click();
		 return require('./editIssuerPageObject.js');	
	};


	
	this.checkMultipleRecordsWithCheckBox=function(){
                           var count=0;		
							for(var i=1;i<4;i++){							  
										 if(element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input[type="checkbox"]')).isPresent()){
											 element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input[type="checkbox"]')).click();
												count++;
												console.log('j='+i);												
										 }										 												
							 } 	
							 
							 if(count>1){
								 flag=true;
								 console.log('Count Of check box='+count);
							 }
		       return flag;
	};
	this.nextSingleArrowOfPaginationIsEnabled= function(){
		if(element(nextSingleArrowOfPagination).isEnabled()){
			flag=true;
		}
		return flag;
	};
	
	this.clickOnNextSingleArrowOfPagination= function(){
		element(nextSingleArrowOfPagination).click();
		
	}; 

	this.clickOnPageSizeSelector=function() {
	 element(pageSizeSelector).click();	
	};
	
	this.selectParticularPageSize=function(){
        element(selectSize).click();
	};

	this.verifyRecordsOnPage=function(){
	
       element(noOfRecordsdisplayed).getText().then(function(text) {
		   expect(text).toContain('11 - 20');
	   });
	};
	
	this.clickOnFirstRowDocCategory=function(){
		 element(firstRowDocCategory).click();
		 return require('./detailsDocumentCategoryPageObject.js');	
	};

	this.getTextOfFirstRowDocCategory=function(docCategory){		
		
		 element(firstRowDocCategory).getText().then(function (text) {
			console.log('firstRowDocCategory'+text);
			expect(text).toContain(docCategory); 
		 });
	};

	this.verifyLengthOfDocCategory=function(){
          element(firstRowDocCategory).getText().then(function (text) {
			console.log('firstRowDocCategory'+text);
			expect(text.length<=30).toBe(true); 
		 });
	};
	
	this.getTextOfFirstRowDescription=function(description){	

		 element(firstRowDescription).getText().then(function (text) {
			console.log('firstRowDescription'+text);
			expect(text).toContain(description); 
		 });
	};

	



	this.getTextOfFirstRowUpdatedBy=function(){	

		 element(firstRowUpdatedBy).getText().then(function (text) {
			console.log('UpdatedBy='+text);
			expect(text).toBe(''); 
		 });
	};

  	this.verifyTextOfFirstRowUpdatedBy=function(updateBy){	

		 element(firstRowUpdatedBy).getText().then(function (text) {
			console.log('UpdatedBy='+text);
			expect(text).toBe(updateBy.toLowerCase()); 
		 });
	};

	this.getTextOfFirstRowUpdatedOn=function(){	

		 element(firstRowUpdatedOn).getText().then(function (text) {
			console.log('UpdatedOn'+text);
			expect(text).toBe(''); 
		 });
	};
	

	this.selectFirstRecordwithCheckbox=function(){
		element(selectFirstRecordwithCheckbox).click();
		browser.sleep(5000).then(function(){console.log("Selected first record with checkbox")});			
	};

	this.selectMultipleRecordsWithCheckBox=function(){
		var count=0;
		for(i=1;i<4;i++){
              element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input')).click();
			  browser.sleep(2000).then(function(){console.log("Selected first 3 record with checkbox")});
			  count++;
		}
		expect(count>1).toBe(true);
	};
	
};
module.exports=new docCategory_page();