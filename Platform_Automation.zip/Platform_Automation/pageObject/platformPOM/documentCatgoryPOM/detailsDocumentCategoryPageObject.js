require('../documentCatgoryPOM/documentCategoryPageObject.js');
require('../documentCatgoryPOM/editDocumentCategoryPageObject.js');

var details_DocCategory_page=function(){
	
            var details_DocCategory_Edit_button=by.buttonText('Edit');
			var details_DocCategory_Back_button=by.buttonText('Back');
			var details_DocCategory=by.css('.form-group .row:nth-child(1) .col-sm-3:nth-child(1) .view-page-value');
			var details_Description=by.css('.form-group .row:nth-child(1) .col-sm-3:nth-child(2) .view-page-value');			
			var details_ValidFrom=by.css('.form-group .row:nth-child(1) .col-sm-3:nth-child(3) .view-page-value');
			var details_ValidTo=by.css('.form-group .row:nth-child(1) .col-sm-3:nth-child(4) .view-page-value');
           
		    var details_DocCategory_updateOn=by.css('.form-group .row:nth-child(3)  .col-sm-3:nth-child(3) .view-page-value');
			var details_DocCategory_updateBy=by.css('.form-group .row:nth-child(3)  .col-sm-3:nth-child(4) .view-page-value');
			var details_DocCategory_createdBy=by.css('.form-group .row:nth-child(3)  .col-sm-3:nth-child(2) .view-page-value');
			var details_DocCategory_createdOn=by.css('.form-group .row:nth-child(3)  .col-sm-3:nth-child(1) .view-page-value');
            var details_DocCategory_Users=by.css('.col-sm-5:nth-child(1) .user_selection_table tr:nth-child(2) td:nth-child(1)  .view-page-label');
			var details_DocCategory_USers2=by.css('.col-sm-5:nth-child(1) .user_selection_table tr:nth-child(3) td:nth-child(1)  .view-page-label');
		    var details_DocCategory_Groups=by.css('.col-sm-5:nth-child(3) .user_selection_table tbody tr:nth-child(2) td:nth-child(1) .view-page-label');
			var details_DocCategory_Groups1=by.css('.col-sm-5:nth-child(3) .user_selection_table tbody tr:nth-child(3) td:nth-child(1) .view-page-label');
			
			
			this.clickOnDetailsEditButton=function(){
				element(details_DocCategory_Edit_button).click();
				 return require('./editDocumentCategoryPageObject.js');
			};
			
			this.clickOnDetailsBackButton=function(){
			    element(details_DocCategory_Back_button).click();
				return require('./documentCategoryPageObject.js');
			};
           
           this.detailsDocCategoryEditButtonIsPresent=function(){			  
			      element.all(details_DocCategory_Edit_button).then(function(items) {
					expect(items.length).toBe(1);				
					console.log('documentCategoryPageObject edit button is present='+items.length);				
	            });		
		   }

		    this.detailsDocCategoryBackButtonIsPresent=function(){			  
			      element.all(details_DocCategory_Back_button).then(function(items) {
					expect(items.length).toBe(1);				
					console.log('DocCategory back button is present='+items.length);				
	            });		
		   }


          this.verifyTextOfDocCategory=function(docCategory){
               element(details_DocCategory).getText().then(function (data) {
				   expect(data).toBe(docCategory);
				   console.log('details_DocCategory ='+data);
			   });
		   };

		   this.verifyTextOfDescription=function(description){
               element(details_Description).getText().then(function (data) {
				   expect(data).toBe(description);
				   console.log('details_Description ='+data);
			   });
		   };



	

		   this.verifyTextOfValidFrom=function(validFrom){
               element(details_ValidFrom).getText().then(function (data) {
				   expect(data).toBe(validFrom);
				   console.log('details_ValidFrom ='+data);
			   });
		   };

		   this.verifyTextOfValidTo=function(validTo){
               element(details_ValidTo).getText().then(function (data) {
				   expect(data).toBe(validTo);
				   console.log('details_ValidTo ='+data);
			   });
		   };

		   this.verifyTextOfUpdatedOn=function(){
               element(details_DocCategory_updateOn).getText().then(function (data) {
				   expect(data).toBe('');
				   console.log('details_DocCategory_updateOn ='+data);
			   });
		   };

           this.verifyTextOfUpdatedBy=function(){
               element(details_DocCategory_updateBy).getText().then(function (data) {
				   expect(data).toBe('');
				   console.log('details_DocCategory_updateBy ='+data);
			   });
		   };

		   this.verifyTextOfCreatedBy=function(createdBy){
               element(details_DocCategory_createdBy).getText().then(function (data) {
				   expect(data).toBe(createdBy.toLowerCase());
				   console.log('details_DocCategory_createdBy ='+data);
			   });
		   };

		   this.verifyTextOfUsers=function(users){
               element(details_DocCategory_Users).getText().then(function (data) {
				   expect(data).toContain(users);
				   console.log('details_DocCategory_Users ='+data);
			   });
		   };

		   this.verifyTextOfUsers2=function(users1){
               element(details_DocCategory_USers2).getText().then(function (data) {
				   expect(data).toContain(users1);
				   console.log('details_DocCategory_USers2 ='+data);
			   });
		   };


		   this.verifyTextOfGroups=function(groups){
               element(details_DocCategory_Groups).getText().then(function (data) {
				   expect(data).toContain(groups);
				   console.log('details_DocCategory_Groups ='+data);
			   });
		   };

		    this.verifyTextOfGroups1=function(groups){
               element(details_DocCategory_Groups1).getText().then(function (data) {
				   expect(data).toContain(groups);
				   console.log('details_DocCategory_Groups1 ='+data);
			   });
		   };


		   this.verifyTextOfCreatedOn=function(){
						var today = new Date();
						var dd = today.getDate();
						var mm = today.getMonth()+1; //January is 0!
						var yyyy = today.getFullYear();

						if(dd<10) {
							dd = '0'+dd
						} 

						if(mm<10) {
							mm = '0'+mm
						} 

						today = yyyy+'-'+mm +'-'+dd ;
						console.log('today='+today);

						element(details_DocCategory_createdOn).getText().then(function (data) {
							expect(data).toContain(today);
							console.log('details_DocCategory_createdOn ='+data);
						});
		   }



};
module.exports=new details_DocCategory_page();
