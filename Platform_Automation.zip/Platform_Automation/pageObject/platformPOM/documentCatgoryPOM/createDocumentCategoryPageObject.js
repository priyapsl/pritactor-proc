require('../documentCatgoryPOM/documentCategoryPageObject.js');

var create_DocumentCategory_page=function(){

			var document_Category=by.css('create-document-category #document_edit_category_name');
            var description=by.css('create-document-category #document_edit_description');
            var validFrom=by.css('create-document-category #subsidiary_edit_validfrom');
			var validTo=by.css('create-document-category #subsidiary_edit_validto');


			var users_DrpDown=by.css('create-document-category .col-sm-5:nth-child(1) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
			var users_InputBox=by.css('create-document-category .col-sm-5:nth-child(1) .form-control.ui-select-search');

            var groups_Drpdwn=by.css('create-document-category .col-sm-5:nth-child(3) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
            var groups_Inputbox=by.css('create-document-category .col-sm-5:nth-child(3) .form-control.ui-select-search');
			var permission_Upload=by.css('td:nth-child(2) .checkbox-opacity.ng-untouched.ng-pristine.ng-valid');
			var permission_Delete=by.css('td:nth-child(4) .checkbox-opacity.ng-untouched.ng-pristine.ng-valid');		
		
			var docCategorySave_button=by.buttonText('Save');
			var docCategory_Cancel_button=by.css('create-document-category #document_edit_cancel_button');
           
            
       
			 
			 var docCategoryStar=by.css('.col-sm-3:nth-child(1) .required-icon');
			 var descriptionStar=by.css('.col-sm-3:nth-child(2) .required-icon');
			 var validFromStar=by.css('.col-md-3.custom-datepicker:nth-child(3) .required-icon');
			 var validToStar=by.css('.col-md-3.custom-datepicker:nth-child(4) .required-icon');
			

			//var missingIssuerErrorMsg=by.css('.col-sm-3:nth-child(3) .error-msg>span:nth-child(2)');
			var missingIssuerCodeErrorMsg=by.css('.form-group:nth-child(1) .has-error:nth-child(1) .error-msg>span:nth-child(2)');
			var missingIssuerNameErrorMsg=by.css('.form-group:nth-child(1) .has-error:nth-child(2) .error-msg>span:nth-child(2)');
           var missingSubsidiaryCodeErrorMsg=by.css('.form-group:nth-child(2) .col-sm-3:nth-child(3) .error-msg span:nth-child(2)');
		   var wrongNotificationRetentionErrorMsg=by.css('.form-group:nth-child(3) .col-sm-3:nth-child(3) .error-msg span:nth-child(2)');

           var duplicateIssuerCodeErrorMsg=by.css('.entity-details-container>div.error-msg>span:nth-child(2)');
		
		
			var create_CancelPopUpOKBtn=by.css('#canceldialog_ok_button');
			var cancelPopUpMessage=by.css('cancel-dialog .modal-body>p');
			var create_CancelPopUpCancelBtn=by.css('#canceldialog_cancel_button');
			var firstElementFromDropDown=by.css('.ui-select-choices li:nth-child(1) a div');
 
           //Shipment Provider Pane
		   var addShipMentProviderIcon=by.css('#issuer_create_add_shipment i');
           var shipmentProviderCodeDrpwn=by.css('#shp_code_0');
           var selectShipmentMethodsDrpwn=by.css('#shp_methods_0 .overSelect');
           var shipmentDescription=by.css('.form-control.issuer-truncate-text.input-style');
           var shipment_ValidFrom=by.css('shp_validFrm_0');
		   var shipment_ValidTo=by.css('#shp_validTo_0');
           var shipment_DeleteIcon=by.css('#shp_del_0');
			var flag=false;

            this.document_CategoryIsPresent=function(){				
				element.all(document_Category).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('document_Category is present');				
				});  
			};

			 this.descriptionIsPresent=function(){				
				element.all(description).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('description is present');				
				});  
			};

		

   
   
            
			
			
			 this.createDocumentCategoryValidFromIsPresent=function(){				
				element.all(validFrom).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('validFrom is present');				
				});  
			};
			
			 this.createDocumentCategoryValidToIsPresent=function(){				
				element.all(validTo).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('validTo is present');				
				});  
			};

			 this.usersDrpDwnIsPresent=function(){				
				element.all(users_DrpDown).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('users_DrpDown is present');				
				});  
			};

          this.groupsDrpDwnIsPresent=function(){				
				element.all(groups_Drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('groups_Drpdwn is present');				
				});  
			};

			this.permissionUploadIsPresent=function(){				
				element.all(permission_Upload).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('permission_Upload is present');				
				});  
			};

			this.permissionDeleteIsPresent=function(){				
				element.all(permission_Delete).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('permission_Delete is present');				
				});  
			};

			

			this.docCategoryCancelButtonIsPresent=function(){				
				element.all(docCategory_Cancel_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('docCategory_Cancel_button is present');				
				});  
			};
			
			
			this.docCategorySaveButtonIsPresent=function(){			
				element.all(docCategorySave_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('docCategorySave_button is present');				
				});  
			};

			this.docCategoryStarIsPresent=function(){			
				element.all(docCategoryStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('docCategoryStar is present');				
				});  
			};

			this.descriptionStarIsPresent=function(){			
				element.all(descriptionStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('descriptionStar is present');				
				});  
			};

			this.validFromStarIsPresent=function(){			
				element.all(validFromStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('validFromStar is present');				
				});  
			};

			this.validToStarIsPresent=function(){			
				element.all(validToStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('validToStar is present');				
				});  
			};

		
			

		
			
			this.verifyTextOfErrorMessage=function(actualErrorMessage){
               element(create_ErrorMessageForDuplicateSubCode).getText().then(function (errorMessage) {
				   expect(errorMessage).toContain(actualErrorMessage);
				   console.log('error message='+errorMessage);
			   });
			};

		
			
			
			this.enterTextInDocument_Category=function(docCategory)
				{
					element(document_Category).sendKeys(docCategory);
				};	

          this.enterTextInDescription=function(desc)
				{
					element(description).sendKeys(desc);
				};			
		  
			this.enterTextInValidDateFrom=function(dateFrom)
				{
					element(validFrom).sendKeys(dateFrom);
				};	
				
			this.enterTextInValidDateTo=function(dateTo)
				{
					element(validTo).sendKeys(dateTo);
				};


            this.enterTextInUsersInputBox=function(users)
				{
					element(users_InputBox).sendKeys(users);
				};

			 this.enterTextInGroupsInputBox=function(groups)
				{
					element(groups_Inputbox).sendKeys(groups);
				};

          
				



			
			

			this.clickOnUsersDrpDwn=function(){
               
			   element(users_DrpDown).click();
			};	

			this.selectUserUploadPermission=function(){
              element(permission_Upload).click();
			};

			this.selectUserDeletePermission=function(){
              element(permission_Delete).click();
			};

			this.clickOnGroupsDrpDwn=function(){
               
			   element(groups_Drpdwn).click();
			};	

           
 

			
			this.clickOnSaveButton=function(){
				element(docCategorySave_button).click();
				return require('./documentCategoryPageObject.js');
			};

			this.selectParticularUsers=function(users){	
						 element(by.cssContainingText('.dropdown-item>div', users)).click();
			}	
          

		  	this.selectParticularGroups=function(groups){	
						 element(by.cssContainingText('.dropdown-item>div', groups)).click();
			}	

          
          
			
			this.clickOnCancelButton=function(){
			    element(docCategory_Cancel_button).click();
				
			};
			this.clickOnCanacelPopUpOk=function(){
                element(create_CancelPopUpOKBtn).click();
				return require('./documentCategoryPageObject.js');
			};

			this.clickOnCanacelPopUpCancel=function(){
                element(create_CancelPopUpCancelBtn).click();
				return require('./createDocumentCategoryPageObject.js');
			};

			this.selectFirstElementFromDropDown=function(){		
				element(firstElementFromDropDown).click();
			};

			this.verifyErrorMessage=function(){
              element(missingIssuerErrorMsg).getText().then(function (text) {
				  expect(text).toBe('Please choose an Issuer');
			  })
			};

			this.verifyMissingSubsidiaryErrorMessage=function(errorMsg){
              element(missingSubsidiaryCodeErrorMsg).getText().then(function (text) {
				  expect(text).toBe(errorMsg);
			  })
			};

			this.verifyMissingIssuerCodeErrorMessage=function(errorMsg){
              element(missingIssuerCodeErrorMsg).getText().then(function (text) {
				  expect(text).toBe(errorMsg);
			  })
			};

			this.verifyMissingIssuerNameErrorMessage=function(errorMsg){
              element(missingIssuerNameErrorMsg).getText().then(function (text) {
				  expect(text).toBe(errorMsg);
			  })
			};

		  this.verifyWrongRetentionNotificationErrorMessage=function(errorMsg){
              element(wrongNotificationRetentionErrorMsg).getText().then(function (text) {
				  expect(text).toBe(errorMsg);
			  })
			};
           
		   this.verifyCancelPopUpMessage=function(){
              element(cancelPopUpMessage).getText().then(function (text) {
				 expect(text).toContain('Are you sure you want to cancel the request? You will lose unsaved data'); 
				 console.log('PopUpMessage='+text);
			  });
		   };

		   	this.verifyDuplicateIssuerCodeMsg=function(actualErrorMessage){
               element(duplicateIssuerCodeErrorMsg).getText().then(function (errorMessage) {
				   expect(errorMessage).toContain(actualErrorMessage);
				   console.log('error message='+errorMessage);
			   });
			};


		   //Shipment ProviderPane
		   this.clickOnShipmentProviderAddIcon=function(){
              element(addShipMentProviderIcon).click();
		   };

       this.shipmentProviderAddIconIsPresent=function(){				
				element.all(addShipMentProviderIcon).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('addShipMentProviderIcon is present');				
				});  
		};


		   this.clickOnShipmentProviderCodeDrpdwn=function(){
              element(shipmentProviderCodeDrpwn).click();
		   };

		 this.shipmentProviderCodeDrpwnIsPresent=function(){				
				element.all(shipmentProviderCodeDrpwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('shipmentProviderCodeDrpwn is present');				
				});  
		};

		 this.clickOnSelectShipmentMethodsCodeDrpdwn=function(){
              element(selectShipmentMethodsDrpwn).click();
		   };

		 this.selectShipmentMethodsDrpwnIsPresent=function(){				
				element.all(selectShipmentMethodsDrpwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('selectShipmentMethodsDrpwn is present');				
				});  
		};
		
		this.selectParticularShipmentMethods=function(shipmentMethods){	
						 element(by.cssContainingText('.view-page-value', shipmentMethods)).click();
		}

		this.selectParticularShipmentProvider=function(shimentProvider){
                element(by.cssContainingText('option', shimentProvider)).click();
		};

		 this.shipmentDescriptionIsPresent=function(){				
				element.all(shipmentDescription).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('shipmentDescription is present');				
				});  
		};	

		 this.shipmentValidFromIsPresent=function(){				
				element.all(shipment_ValidFrom).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('shipment_ValidFrom is present');				
				});  
		};	

		 this.shipmentValidToIsPresent=function(){				
				element.all(shipment_ValidTo).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('shipment_ValidTo is present');				
				});  
		};	

		 this.shipmentDeleteIconIsPresent=function(){				
				element.all(shipment_DeleteIcon).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('shipment_DeleteIcon is present');				
				});  
		};	
       
	   this.clickOnShipmentDeleteIcon=function(){
              element(shipment_DeleteIcon).click();
		   };

		this.noOfElementsInDrpDwn=function(){
             element.all('.dropdown-item>div').then(function (items) {
				 expect(items.length>0).toBe(true);
				 console.log('Elements='+items.length);
			 });
		};

};
module.exports=new create_DocumentCategory_page();