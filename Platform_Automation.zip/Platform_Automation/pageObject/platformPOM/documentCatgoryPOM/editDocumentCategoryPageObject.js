require('../documentCatgoryPOM/documentCategoryPageObject.js');

var edit_DocCategory_page=function(){
	
			var edit_DocCategory_code=by.css('input#document_edit_category_name');

			var edit_Description=by.css('edit-document-category #document_edit_description');
          
			var edit_DocCategory_ValidFrom=by.css('edit-document-category #subsidiary_edit_validfrom');
			var edit_DocCategory_ValidTo=by.css('edit-document-category #subsidiary_edit_validto');
			var edit_DocCategory_Save_button=by.buttonText('Save');
			var edit_DocCategory_Cancel_button=by.css('edit-document-category #document_edit_cancel_button');

			var edit_subsidiaryDrpDwn=by.css('edit-issuer #issuer_edit_subsidiarySelector');
			var edit_subsidiaryInputBox=by.css('edit-issuer #issuer_edit_subsidiarySelector .form-control.ui-select-search');
            
            var edit_Parent_Issuer_Drpdwn=by.css('edit-issuer #issuer_edit_parentIssuerSelector');
            var edit_Parent_Issuer_InputBox=by.css('edit-issuer #issuer_edit_parentIssuerSelector input');

			var edit_LanguageDrpDwn=by.css('edit-issuer #isssuer_edit_languageSelect');
            var edit_LanguageInputBox=by.css('edit-issuer #isssuer_edit_languageSelect input');

			var documentRetentionInputBox=by.css('#documentRetentionPeriodId');
            var documentRetentionSpanDrpDwn=by.css('edit-issuer #issuer_edit_documentRetentionUnitSelector ng-select');
         
		    var notificationRetentionInputBox=by.css('#issuer_edit_notificationRetentionUnitSelector input:nth-child(1)');
			var changeLogoOption=by.css('.upload-btn');

	

			var edit_ProductCodeErrorMsg=by.css('edit-product .col-sm-3.has-error:nth-child(1) .error-msg>span:nth-child(2)');			
			var edit_DescriptionErrorMsg=by.css('edit-product .col-sm-3.has-error:nth-child(2) .error-msg>span:nth-child(2)');
			
            var edit_prodCodeStar=by.css('.col-sm-3:nth-child(1) .required-icon');
			var edit_DescriptionStar=by.css('.col-sm-3:nth-child(2) .required-icon');
            var edit_IssuerStar=by.css('.col-sm-3:nth-child(3) .required-icon');
            var edit_fromDateStar=by.css('.col-md-3:nth-child(1) .required-icon');
             var edit_ToDateStar=by.css('.col-md-3:nth-child(2) .required-icon');
			var flag=false;
            
			 this.editDocCategoryCodeIsPresent=function(){				
				element.all(edit_DocCategory_code).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_DocCategory_code is present');				
				});  
			};

			this.verifyTextOfEditDocCategory=function(docCategory){	
				element(edit_DocCategory_code).getAttribute('value').then(function (text) {
				expect(text).toBe(docCategory);
				console.log('text='+text);
				});
			};
   
            
			 this.editDescriptionIsPresent=function(){				
				element.all(edit_Description).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Description is present');				
				});  
			};

			this.verifyTextOfEditDescription=function(description){	
				element(edit_Description).getAttribute('value').then(function (text) {
				expect(text).toBe(description);
				console.log('issuerName='+text);
				});
			};

		
               

			
			
			 this.editValidFromIsPresent=function(){				
				element.all(edit_DocCategory_ValidFrom).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_DocCategory_ValidFrom is present');				
				}); 
			};
			
			 this.editValidToIsPresent=function(){				
				element.all(edit_DocCategory_ValidTo).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_DocCategory_ValidTo is present');				
				}); 
			};
			
			this.editDocCategoryCancelButtonIsPresent=function(){
				
				element.all(edit_DocCategory_Cancel_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_DocCategory_Cancel_button is present');				
				}); 
			};

            this.editProductIssuerDrpdwnIsPresent=function(){
				
				element.all(edit_Product_Issuer_Drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Product_Issuer_Drpdwn is present');				
				}); 
			};
			
			
			this.editDocCategorySaveButtonIsPresent=function(){				
				element.all(edit_DocCategory_Save_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_DocCategory_Save_button is present');				
				}); 
			};
			
            this.editProductStarIsPresent=function(){				
				element.all(edit_prodCodeStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_prodCodeStar is present');				
				}); 
			};
           
           this.editDescriptionStarIsPresent=function(){				
				element.all(edit_DescriptionStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_DescriptionStar is present');				
				}); 
			};

             this.editIssuerStarIsPresent=function(){				
				element.all(edit_IssuerStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_IssuerStar is present');				
				}); 
			};

             this.editFromDateStarIsPresent=function(){				
				element.all(edit_fromDateStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_fromDateStar is present');				
				}); 
			};
 
            this.editToDateStarIsPresent=function(){				
				element.all(edit_ToDateStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_ToDateStar is present');				
				}); 
			};

			 this.editParentIssuerDrpdwnIsPresent=function(){				
				element.all(edit_Parent_Issuer_Drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Parent_Issuer_Drpdwn is present');				
				}); 
			};

			 this.editSubsidiaryDrpdwnIsPresent=function(){				
				element.all(edit_subsidiaryDrpDwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_subsidiaryDrpDwn is present');				
				}); 
			};

			
		   

             this.editDocumentRetentionIsPresent=function(){				
				element.all(documentRetentionInputBox).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('documentRetentionInputBox is present');				
				}); 
			};


              this.editNotificationRetentionIsPresent=function(){				
				element.all(notificationRetentionInputBox).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('notificationRetentionInputBox is present');				
				}); 
			};


            this.changeLogoOptionIsPresent=function(){				
				element.all(changeLogoOption).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('changeLogoOption is present');				
				}); 
			};


             this.clickOnParentIssuerDrpdwn=function(){
                 element(edit_Parent_Issuer_Drpdwn).click();
			 };

			 this.elementNotPresentInParentIssuerDrpdwn=function(parentIssuer){
                element.all(by.cssContainingText('.dropdown-item>div',parentIssuer)).then(function(items){
                   expect(items.length).toBe(0);
				   console.log('Control comes in Dropdown list')
				});
			 };
            

			
			
			this.eneterTextInEditDocCategory=function(docCategory)
				{
					element(edit_DocCategory_code).sendKeys(docCategory);
				};				
				
		    this.clearEditDocCategory=function()
				{
					element(edit_DocCategory_code).clear();
				};
			
		    this.eneterTextInEditDescription=function(description)
				{
					element(edit_Description).sendKeys(description);
				};	

            this.clearEditDescriptione=function()
				{
					element(edit_Description).clear();
				};	

			


             this.clearValidFromDate=function()
				{
					element(edit_DocCategory_ValidFrom).clear();
				};	

				this.clearValidToDate=function()
				{
					element(edit_DocCategory_ValidTo).clear();
				};	
				
			this.eneterTextInValidDateFrom=function(dateFrom)
				{
					element(edit_DocCategory_ValidFrom).sendKeys(dateFrom);
				};	
				
			this.eneterTextInValidDateTo=function(dateTo)
				{
					element(edit_DocCategory_ValidTo).sendKeys(dateTo);
				};	
			
			this.clickOnSaveButton=function(){
				element(edit_DocCategory_Save_button).click();
				return require('./documentCategoryPageObject.js');
			};

            this.clickOnClearSaveButton=function(){
				element(edit_Issuer_Save_button).click();
				//return require('./produtcsPageObject.js');
			};
			
			
			this.clickOnCancelButton=function(){
			    element(edit_DocCategory_Cancel_button).click();
				//return require('./productsPageObject.js');
			};
            
            this.verifyProductDescriptionErrorMsg=function(errorMsg){
               element(edit_DescriptionErrorMsg).getText().then(function (text) {
                   expect(text).toBe(errorMsg);
                   console.log('Error Message='+errorMsg);
               })
            };

            this.verifyProductMissingErrorMsg=function(errorMsg){
               element(edit_ProductCodeErrorMsg).getText().then(function (text) {
                   expect(text).toBe(errorMsg);
                   console.log('Error Message='+errorMsg);
               })
            };



};
module.exports=new edit_DocCategory_page();