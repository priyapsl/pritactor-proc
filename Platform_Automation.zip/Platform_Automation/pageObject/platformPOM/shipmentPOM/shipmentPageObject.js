require('../sitesPOM/createSitesPageObject.js');
require('../sitesPOM/editSitesPageObject.js');	
require('../sitesPOM/detailsSitesPageObject.js');
require('../subsidaryPOM/subsidaryPageObject.js');

var sites_page=function(){
	//Subsidary Page Button
	var shipmentText=by.css('.col-md-4>h5');
	var shipmentFilterButton=by.css('#shipmentprovider_filter_button');
	var shipmentCloseFilterPane=by.css('.fa.fa-times.close-icon');
	//ar filter_CloseIcon=by.css('i.fa.fa-times.close-icon');
    var shipmentDeleteButton=by.css('#shipmentprovider_delete_button');
	var shipmentcreateButton=by.css('#shipmentprovider_create_button');
	var shipmentexportButton=by.css('#shipmentprovider_export_button');
	var shipmentclearButton=by.css('#shipmentprovider_filter_clear_button');
	var shipmentapplyButton=by.css('#shipmentprovider_filter_apply_button');
	var shipmentDelete_Yes_button=by.buttonText('Yes');
	var shipmentDelete_No_button=by.buttonText('No');
	var shipmentDelete_PopupMessage=by.css('.modal-body>p');
	var shipmentDelet_PopUpCloseIcon=by.css('.modal-dialog .confirm-close-icon');
	
	
	//Shipment Grid table Element
	var checkBoxToSelectAll=by.css('shipment-providers-listing .table-responsive thead tr th:nth-child(1) input');
	var shipment_provider=by.css('shipment-providers-listing .table-responsive thead tr th:nth-child(2)');
	var ship_Description=by.css('shipment-providers-listing .table-responsive thead tr th:nth-child(3)');
	var valid_from=by.css('shipment-providers-listing .table-responsive thead tr th:nth-child(4)');	
	var valid_To=by.css('shipment-providers-listing .table-responsive thead tr th:nth-child(5)');	
	var updatedBy=by.css('shipment-providers-listing .table-responsive thead tr th:nth-child(6)');
	var updatedOn=by.css('shipment-providers-listing .table-responsive thead tr th:nth-child(7)');
	var editIconForEachSite=by.css('.table-responsive>table>tbody>tr>td:nth-child(8)');
	var firstRowEditButton= by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(8)');
	var selectFirstRecordwithCheckbox=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(1) input');
	
	//Site Sorting
	var sort_site_header = element(by.cssContainingText('.pull-left.th-tittle', 'Site'));
	var sort_subsidiaryCode_header = element(by.cssContainingText('.pull-left.th-tittle', 'Subsidiary Code'));
	var sort_description_header = element(by.cssContainingText('.pull-left.th-tittle', 'Description'));
	var sort_validFrom_header = element(by.cssContainingText('.pull-left.th-tittle', 'Valid From'));
	var sort_validTo_header = element(by.cssContainingText('.pull-left.th-tittle', 'Valid To'));
	var sort_updatedBy_header = element(by.cssContainingText('.pull-left.th-tittle', 'Updated By'));
	var sort_updatedOn_header = element(by.cssContainingText('.pull-left.th-tittle', 'Updated On'));

	//filter pane elements
	//var filter_SubsidaryCode_drpdwn=by.css('span.btn.btn-default.btn-secondary.form-control.ui-select-toggle'));
	var filter_ShipmentProvider_drpdwn=by.css('.btn.btn-default.btn-secondary.form-control.ui-select-toggle');
	var filter_ShipmentProvider_inputBox=by.css('input.form-control.ui-select-search');
	var filter_ShipmentProviderList=by.css('.dropdown-item>div');
	var filter_Description_InputBox=by.css('#shipmentprovider_filter_description');
	//var filter_Issuer_drpdwn=by.css('.col-sm-3:nth-child(3) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
	var filter_Issuer_inputBox=by.css('input.form-control.ui-select-search');
	var filter_Clear_Button=by.css('#shipmentprovider_filter_clear_button');
	var filter_Apply_Button=by.css('#shipmentprovider_filter_apply_button');
	var filter_CloseIcon=by.css('i.fa.fa-times.close-icon');
	var firstElementFromDropDown=by.css('.ui-select-choices li:nth-child(1)');
	//var secondElementFromDropDown=by.css('.ui-select-choices li:nth-child(2)');
	//Table Element
	var firstRowFromTable=by.css('fng-table table tbody tr:nth-child(1)');
	var allRowsFromTable=by.css('fng-table table tbody tr');
	var nextSingleArrowOfPagination=by.css('[ng-reflect-inner-h-t-m-l="&#8250;"]');
	var firstRowEditButton= by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(9) button i');
	var firstRowSubsidiaryCode=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(2) div');	
	var firstRowDescription=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(4) div');	
	var selectFirstRecordwithCheckbox=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(1) input');
	
	var editIconForEachProduct=by.css('.table-responsive>table>tbody>tr>td:nth-child(9) button');
	var flag=false;
	
	// Sorting based on Site
	this.clickSortingForSite=function(){	
		element(sort_site_header).click();
	};

	// Sorting based on Subsidiary
	this.clickSortingForSubsidiary=function(){	
		element(sort_subsidiaryCode_header).click();
	};

	// Sorting based on Description
	this.clickSortingForDescription=function(){	
		element(sort_description_header).click();
	};

	// Sorting based on Valid From
	this.clickSortingForValidFrom=function(){	
		element(sort_validFrom_header).click();
	};

	// Sorting based on Valid From
	this.clickSortingForValidTo=function(){	
		element(sort_validTo_header).click();
	};

	// Click Close Subsidiary Code List
	this.clickSubsidiaryCodeList=function(){	
		element(filter_SubsidiaryCodeList).click();
	};
	// Click Close Filter Pane
	this.closeFilterPane=function(){	
		element(sitesCloseFilterPane).click();
	};
	//Sites Page Button Disabled
	this.checkSitesClearBtnDisabled=function(){	
			status = true;
		expect(status).toBe(true);
	};
	

	//Shipment Text is Present
	this.shipmentTextIsPresent=function(){		
		element.all(shipmentText).then(function(items) {
		//		expect(items.length).toBe(1);				
		//		console.log('shipmentText is present');				
		//});		
		var flag = false;
		//expect(shipmentText.isPresent()).toBe(true);
		if(items.length > 0)
			{
				 console.log('Correct Shipment Header Text is present on Shipment Page');
				  console.log('No of Shipment Text present : '+items.length);
				  flag = true;
			}
			else {
				 console.log('Shipment Header Text not present on Shipment Page');
				 console.log('No of Shipment Text present : '+items.length);
			}
				expect(flag).toBe(true);
		});
	};
	
	this.shipmentfilterButtonIsPresent=function(){		
		element.all(shipmentFilterButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('Shipment Filter Button is present');	
				console.log('No of filter buttons present : '+items.length);			
		});	
	};

	this.shipmentproviderDropdownIsPresent=function(){		
		element.all(filter_ShipmentProvider_drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_ShipmentProvider_drpdwn is present');	
				console.log('No of shipment provider dropdowns present : '+items.length);			
		});	
	};

	this.shipmentDescriptionInputBoxIsPresent=function(){		
		element.all(filter_Description_InputBox).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Description_InputBox is present');	
				console.log('No of Shipment description Input Boxes present : '+items.length);			
		});	
	};


	this.shipmentexportButtonIsPresent=function(){		
		element.all(shipmentexportButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('Shipment Export Button is present');	
				console.log('No of export buttons present : '+items.length);			
		});	
	};

	this.shipmentClearButtonIsPresent=function(){		
		element.all(shipmentclearButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('Shipment Clear Button is present');
				console.log('No of clear buttons present : '+items.length);				
		});	
	};

	this.shipmentApplyButtonIsPresent=function(){		
		element.all(shipmentapplyButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('Shipment Apply Button is present');
				console.log('No of Shipment Apply Buttons present : '+items.length);				
		});	
	};
	
	this.shipmentDeleteButtonIsPresent=function(){		
		element.all(shipmentDeleteButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('shipmentDeleteButton is present');	
				console.log('No of Shipment Delete Buttons present : '+items.length);			
		});
	};
	
	this.sitesDeleteButtonIsEnabled=function(){
		if(element(sitesDeleteButton).isEnabled()){
			console.log('Sites Delete button is enabled');
			flag=true;
		}
		return flag;
	};
	
	this.shipmentCreateButtonIsPresent=function(){		
		element.all(shipmentcreateButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('shipmentcreateButton is present');				
		});
		
	};
	
	//Subsidary Grid Element Present or Not
	this.checkBoxToSelectAllIsPresent=function(){		
       element.all(checkBoxToSelectAll).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('checkBox To Select All element on Page is present');				
		});		
	};
	
	this.clickOnCheckBoxToSelectAllSubsidaryOnPage=function(){
		element(checkBoxToSelectAll).click();
				
	};
	
	this.productCodeIsPresent=function(){		
        element.all(product_code).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('product_code is present');				
		});				
	};
	
	
	this.sites_DescriptionIsPresent=function(){		
        element.all(sites_Description).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('sites_Description is present');				
		});			
	};

	this.sites_IssuerIsPresent=function(){		
        element.all(sites_Issuer).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('sites_Issuer is present');				
		});			
	};
	
	this.valid_fromIsPresent=function(){	
        element.all(valid_from).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('valid_from is present');				
		});			
	};
	
	this.valid_ToIsPresent=function(){			
        element.all(valid_To).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('valid_To is present');				
		});			
	};
	
	this.updatedByIsPresent=function(){		
        element.all(updatedBy).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('updatedBy is present');				
		});			
	};
	
	this.updatedOnIsPresent=function(){		
        element.all(updatedOn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('updatedOn is present');				
		});			
	};
	
	
	//Click On Filter,Delete,Create Button of Subsidary
	this.clickOnSitesFilterButton=function(){
		element(sitesFilterButton).click();		
	};
	
	this.clickOnSitesDeleteButton=function(){
		element(sitesDeleteButton).click();		
	};
	
	this.clickOnSitesCreateButton=function(){
		element(sitescreateButton).click();
        return require('../sitesPOM/createSitesPageObject.js');		
	};
	
		this.clickOnSubsidiaryNavLink=function(){
		element(by.cssContainingText('.section>a>h3>span', 'Subsidiaries')).click();
        return require('../subsidaryPOM/subsidaryPageObject.js');		
	};
	

	this.clickOnSitesDeleteYesButton=function(){
		element(sitesDelete_Yes_button).click();
		console.log('Record Deleted Successfully');
	}
	
	this.clickOnSitesDeleteNoButton=function(){
		element(sitesDelete_No_button).click();
	}
	
    this.closeIconOfPopUpIsPresent=function(){		
        element.all(sitesDelet_PopUpCloseIcon).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('delet_PopUpCloseIcon is present');				
		});      		
	};

    this.clickOnCloseIconOfPopUp=function(){
			element(sitesDelet_PopUpCloseIcon).click();
	};

	this.getTextOfDeletePopup=function(){
		element.all(prodDelete_PopupMessage).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);					  
						itemList[0].getText().then(function(text) {								         
								console.log('Message='+text);
								expect(text).toBe("Are you sure you want to delete the selected records?");		
							 
						});					
			});	
     }
	 
	 this.getTextOfDeletePopupForEntirePage=function(){
		element.all(prodDelete_PopupMessage).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);					  
						itemList[1].getText().then(function(text) {								         
								console.log('Message='+text);
								expect(text).toContain("Records selected");		
							 
						});					
			});	
     }
	 
	//Filter Pane element present verification
	this.filter_SubsidiaryCode_drpdwnIsPresent=function(){		
        element.all(filter_SubsidiaryCode_drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_SubsidiaryCode_drpdwn is present');				
		});    	
		
	};
	
	this.filter_DescriptionInputBoxIsPresent=function(){		
        element.all(filter_Description_InputBox).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Description_InputBox is present');				
		});    			
	};
	
	this.filter_SiteInputBoxIsPresent=function(){		
        element.all(filter_Site_InputBox).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Site_InputBox is present');				
		});    	
		
	};
	
	this.filter_Clear_ButtonIsPresent=function(){		
       element.all(filter_Clear_Button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Clear_Button is present');				
		});   		
	};
	
	this.filter_Clear_ButtonIsNotPresent=function(){		
       element(filter_Clear_Button).getText().then(function(items) {
				expect(items).toBe('');				
				console.log('filter_Clear_Button is not present');				
		});   		
	};

	this.filter_Apply_ButtonIsPresent=function(){		
       element.all(filter_Apply_Button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Apply_Button is present');			
		});  		
	};
	
	this.filter_Apply_ButtonIsNotPresent=function(){		
       element(filter_Apply_Button).getText().then(function(items) {
				expect(items).toBe('');				
				console.log('filter_Apply_Button is not present');				
		});  		
	};
	this.filter_CloseIconIsPresent=function(){		
        element.all(filter_CloseIcon).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_CloseIcon is present');				
		});  		
	};
	
	
	this.clickfilter_CloseIcon=function(){
			element(filter_CloseIcon).click();	
			console.log('Clicked on close icon of Filter Pane');
	};
	
	this.clickOnSubsidiaryLink=function(){		
		element(filter_SubsidiaryCode_drpdwn).click();
	};
	
	this.clickOnFilterSubsidiaryCodeDrpdwn=function(){		
		element(filter_SubsidiaryCode_drpdwn).click();
	};

	this.clickOnFilterIssuerCodeDrpdwn=function(){		
		element(filter_Issuer_drpdwn).click();
	};
	
	this.enterTextInFilterSubsidaryCodeDrpDown=function(subsidiaryCode){
           element(filter_SubsidiaryCode_inputBox).sendKeys(subsidiaryCode);
	};

	this.enterTextInSiteInputBox=function(site){
           element(filter_Site_InputBox).sendKeys(site);
	};

	this.enterTextInDescriptionInputBox=function(description){
           element(filter_Description_InputBox).sendKeys(description);
	};

	this.getTextOfFilterSubsidaryCodeDrpdown=function(){
		element(filter_SubsidiaryCode_inputBox).getText().then(function (text) {
			expect(text).toBe("");
			console.log('TextOfFilterSubsidaryCodeDrpdown='+text.length);
		});
	};

   this.getTextOfFilterDescription=function(){
      element(filter_Description).getText().then(function (text) {
		  expect(text).toBe("");
		  console.log('filter_Description text length='+text.length);
	  });   
   };
 
   this.getTextOfFilterIssuerCodeDrpdown=function(){
		element(filter_Issuer_inputBox).getText().then(function (text) {
			expect(text).toBe("");
			console.log('TextOfFilterIssuer Drpdown='+text.length);
		});
	};

	this.selectParticularSubCode=function(subsidaryCode){
		element(by.cssContainingText('.dropdown-item>div', subsidaryCode)).click();
	};
	
	this.isParticularSubCodePresentInDropDown=function(subCode){
		
			element.all(filter_SubsidiaryCodeList).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						  var count=0;
						itemList[i].getText().then(function(text) {
						  
							  if (text == subCode) {
								count++;
								expect(text).toEqual(subCode);
								//break;
							  } 
							 
						});
					 };
				
			});
		
	};
	
	this.isParticularProductCodeNotPresntDropDown=function(subsidiaryCode){
		  element.all(by.cssContainingText('.dropdown-item>div', subsidiaryCode)).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('SubCode is not present='+items.length);				
		});  	
	};

	this.firstElementFromDropDownIsPresent=function(){		
		 element.all(firstElementFromDropDown).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('firstElementFromDropDown is present');
				
		});		
	};
	
	this.selectParticularSubCode=function(subsidaryCode){
		element(by.cssContainingText('.dropdown-item>div', subsidaryCode)).click();
	};
	
	this.isParticularSubCodeNotPresntDropDown=function(subsidaryCode){

		  element.all(by.cssContainingText('.dropdown-item>div', subsidaryCode)).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('SubCode is not present='+items.length);				
		});  	
	};

	this.selectFirstElementFromDropDown=function(){		
		element(firstElementFromDropDown).click();
	};
	
	this.clickOnFilterApplyButton=function(){
		element(filter_Apply_Button).click();
	};
	
	this.clickOnFilterClearButton=function(){
		element(filter_Clear_Button).click();
	};
	
	//Table element
	this.firstRowFromTableIsPresent= function(){
	   element.all(firstRowFromTable).then(function(items) {
		   if(items.length > 0 ){			
				console.log('Checking Table - firstRowFromTable is present');	
		   }
			else
				{
				console.log('Checking Table - firstRowFromTable is NOT present');		
				}	
			expect(items.length).toBe(1);			
		});		
		
	};

	this.firstRowFromTableNotPresent=function(){
		element.all(allRowsFromTable).then(function(items) {
				expect(items.length).toBe(0);
				console.log('item in ='+items.length);
				console.log('Checking Data in Table -- elements are not present');
				
		});		
	};
	
	this.eneterTextInDescriptionBox=function(descriptionText)
	{
		element(filter_Description).sendKeys(descriptionText);
	};
	
	
	
	//To read the data of particular column
	this.getDataOfFirstRowParticularColumn=function(columnNo,data){
		
			  element(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).getText().then(function(text){
				  console.log('Data of First Row Particular Column='+text);
				  expect(text).toBe(data);
				  
			  });

				 // console.log(text);         	
	};
	
	this.dataForParticularColumnIsPresent=function(columnNo){
		
			/*  if(element(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).isPresent()){
				  flag=true;
			  }
				return flag;*/

			element.all(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).then(function(items) {
				var flag=false;
				if(items.length>0){
					flag=true;
				}
				expect(flag).toBe(true);
				console.log('item in ='+items.length);				
		   });	
	};
	
	this.checkEditButtonForEachProduct=function(){				 
					
            element.all(editIconForEachProduct).then(function(items) {				
				expect(items.length).toBe(10);
				console.log('item in ='+items.length);				
		   });

	};
	
	this.checkMultipleRecordsWithCheckBox=function(){
                           var count=0;		
							for(var i=1;i<4;i++){							  
										 if(element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input[type="checkbox"]')).isPresent()){
											 element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input[type="checkbox"]')).click();
												count++;
												console.log('j='+i);												
										 }										 												
							 } 	
							 
							 if(count>1){
								 flag=true;
								 console.log('Count Of check box='+count);
							 }
		       return flag;
	};
	nextSingleArrowOfPaginationIsEnabled= function(){
		if(element(nextSingleArrowOfPagination).isEnabled()){
			flag=true;
		}
		return flag;
	};
	
	clickOnNextSingleArrowOfPagination= function(){
		element(nextSingleArrowOfPagination).click();
		
	};

	this.clickOnfirstRowSubsidaryCode=function(){
		 element(firstRowSubsidiaryCode).click();
		 return require('./detailsSitesPageObject.js');	
	};

	this.clickOnFirstRowsEditButton=function(){
		 element(firstRowEditButton).click();
		 return require('./editSitesPageObject.js');	
	};
	
	this.clickOnfirstRowProductCode=function(){
		 element(firstRowProductCode).click();
		 return require('./detailsSubsidaryPageObject.js');	
	};

	this.getTextOfFirstRowProductCode=function(prodCode){		
		
		 element(firstRowProductCode).getText().then(function (text) {
			console.log('firstRowProductCode'+text);
			expect(text).toContain(prodCode); 
		 });
	};
	
	this.getTextOfFirstRowDescription=function(description){	

		 element(firstRowDescription).getText().then(function (text) {
			console.log('firstRowDescription'+text);
			expect(text).toContain(description); 
		 });
	};
	

	this.selectFirstRecordwithCheckbox=function(){
		element(selectFirstRecordwithCheckbox).click();
		
	};
	
};
module.exports=new sites_page();