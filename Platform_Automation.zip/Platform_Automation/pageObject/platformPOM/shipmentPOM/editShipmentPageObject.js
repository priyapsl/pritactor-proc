require('../sitesPOM/sitesPageObject.js');

var edit_sites_page=function(){
	
			var edit_Subsidary_code=by.css('.ui-select-match-text.pull-left.ui-select-allow-clear');
			var edit_filter_SubsidiaryCode_drpdwn=by.css('.btn.btn-default.btn-secondary.form-control.ui-select-toggle');
			var edit_filter_SubsidiaryCode_inputBox=by.css('input.form-control.ui-select-search');
			var edit_Site_Site=by.css('#site');
			var edit_Site_Description=by.css('#description');
			var edit_Site_ValidFrom=by.css('#validfrom');
			var edit_Site_ValidTo=by.css('#validto');
			var edit_Site_Save_button=by.css('#site_edit_save_button');
			var edit_Site_Cancel_button=by.css('#site_edit_cancel_button');
			var edit_SubsidaryCodeErrorMsg=by.css('edit-subsidiary .col-sm-2.has-error .error-msg>span:nth-child(2)');			
			var edit_DescriptionErrorMsg=by.css('edit-subsidiary .col-sm-4.has-error .error-msg>span:nth-child(2)');
			
			
			var flag=false;

			 this.clickFilterSubsidiaryDrpdwn=function(){				
				element(edit_filter_SubsidiaryCode_drpdwn).click();
			};

			
            
			 this.editSubsidaryCodeIsPresent=function(){				
				element.all(edit_Subsidary_code).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Subsidary_code is present');				
				});  
			};

			
			 this.editSitesIsPresent=function(){				
				element.all(edit_Site_Site).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Subsidary_Description is present');				
				});  
			};
   
            
			 this.editSitesDescriptionIsPresent=function(){				
				element.all(edit_Site_Description).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Subsidary_Description is present');				
				});  
			};
			
			 this.editSubsidaryValidFromIsPresent=function(){				
				element.all(edit_Site_ValidFrom).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Subsidary_ValidFrom is present');				
				}); 
			};
			
			 this.editSubsidaryValidToIsPresent=function(){				
				element.all(edit_Site_ValidTo).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Subsidary_ValidTo is present');				
				}); 
			};
			
			this.editSubsidaryCancelButtonIsPresent=function(){
				
				element.all(edit_Site_Cancel_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Subsidary_Cancel_button is present');				
				}); 
			};
			
			
			this.editSubsidarySaveButtonIsPresent=function(){				
				element.all(edit_Site_Save_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Subsidary_Save_button is present');				
				}); 
			};
			
			
			
			this.eneterTextInEditSubsidaryCode=function(subsidaryCode)
				{
					element(edit_filter_SubsidiaryCode_inputBox).sendKeys(subsidaryCode);
				};				
				
		    this.clearEditSite=function()
				{
					element(by.css('#site')).clear();
				};

				 this.clearEditDescription=function()
				{
					element(edit_Site_Description).clear();
				};

				 this.clearEditValidFrom=function()
				{
					element(edit_Site_ValidFrom).clear();
				};

				 this.clearEditValidTo=function()
				{
					element(edit_Site_ValidTo).clear();
				};


			this.eneterTextInEditSite=function(site)
				{
					element(edit_Site_Site).sendKeys(site);
				};				
				
		    this.eneterTextInEditSiteDescription=function(siteDescription)
				{
					element(edit_Site_Description).sendKeys(siteDescription);
				};				
				
			this.eneterTextInValidDateFrom=function(dateFrom)
				{
					element(edit_Site_ValidFrom).sendKeys(dateFrom);
				};	
				
			this.eneterTextInValidDateTo=function(dateTo)
				{
					element(edit_Site_ValidTo).sendKeys(dateTo);
				};	
			
			this.clickOnSaveButton=function(){
				element(edit_Site_Save_button).click();
				return require('./sitesPageObject.js');
			};
			
			this.clickOnCancelButton=function(){
			    element(edit_Site_Cancel_button).click();
				return require('./sitesPageObject.js');
			};
};
module.exports=new edit_sites_page();