require('../productsPOM/productsPageObject.js');

var create_products_page=function(){

			var create_Product_code=by.css('create-product #product_create_productcode');
			var create_Product_Description=by.css('create-product #product_create_description');
			var create_Product_Issuer_DrpDown=by.css('create-product .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
			var create_IssuerInputBox=by.css('.products-details-container .form-control.ui-select-search');
			var create_Product_ValidFrom=by.css('create-product #product_create_validfrom');
			var create_Product_ValidTo=by.css('create-product #product_create_validto	');
			var create_products_Save_button=by.buttonText('Save');
			var create_products_Cancel_button=by.css('create-product #product_create_cancel_button');

			var missingIssuerErrorMsg=by.css('.col-sm-3:nth-child(3) .error-msg>span:nth-child(2)');

			var create_CancelPopUpOKBtn=by.css('#canceldialog_ok_button');
			var cancelPopUpMessage=by.css('cancel-dialog .modal-body>p');
			var create_CancelPopUpCancelBtn=by.css('#canceldialog_cancel_button');
			var firstElementFromDropDown=by.css('.ui-select-choices li:nth-child(1) a div');
			var flag=false;

            this.createProductCodeIsPresent=function(){				
				element.all(create_Product_code).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Product_code is present');				
				});  
			};
   
            
			 this.creatProductDescriptionIsPresent=function(){			
				element.all(create_Product_Description).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Product_Description is present');				
				});  
			};
			
			 this.creatProductValidFromIsPresent=function(){				
				element.all(create_Product_ValidFrom).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Product_ValidFrom is present');				
				});  
			};
			
			 this.creatProductValidToIsPresent=function(){				
				element.all(create_Product_ValidTo).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Product_ValidTo is present');				
				});  
			};
			
			this.creatProductCancelButtonIsPresent=function(){				
				element.all(create_products_Cancel_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_products_Cancel_button is present');				
				});  
			};
			
			
			this.creatProductSaveButtonIsPresent=function(){			
				element.all(create_products_Save_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_products_Save_button is present');				
				});  
			};
			
			this.verifyTextOfErrorMessage=function(actualErrorMessage){
               element(create_ErrorMessageForDuplicateSubCode).getText().then(function (errorMessage) {
				   expect(errorMessage).toContain(actualErrorMessage);
				   console.log('error message='+errorMessage);
			   });
			};
			
			
			this.eneterTextInCreateProductCode=function(productCode)
				{
					element(create_Product_code).sendKeys(productCode);
				};	

			this.eneterTextInCreateIssuerCode=function(productCode)
				{
					element(create_Product_code).sendKeys(productCode);
				};			
				
		    this.eneterTextInCreateProductDescription=function(productDescription)
				{
					element(create_Product_Description).sendKeys(productDescription);
				};				
				
			this.eneterTextInValidDateFrom=function(dateFrom)
				{
					element(create_Product_ValidFrom).sendKeys(dateFrom);
				};	
				
			this.eneterTextInValidDateTo=function(dateTo)
				{
					element(create_Product_ValidTo).sendKeys(dateTo);
				};

            this.eneterTextInIssuerInputBox=function(issuer)
				{
					element(create_IssuerInputBox).sendKeys(issuer);
				};
			

			this.clickOnIssuerDrpDwn=function(){
               
			   element(create_Product_Issuer_DrpDown).click();
			};	
			
			this.clickOnSaveButton=function(){
				element(create_products_Save_button).click();
				return require('./productsPageObject.js');
			};

			this.selectParticularIssuerCode=function(issuer){	
						 element(by.cssContainingText('.dropdown-item>div', issuer)).click();
			}		
			
			this.clickOnCancelButton=function(){
			    element(create_products_Cancel_button).click();
				
			};
			this.clickOnCanacelPopUpOk=function(){
                element(create_CancelPopUpOKBtn).click();
				return require('./productsPageObject.js');
			};

			this.clickOnCanacelPopUpCancel=function(){
                element(create_CancelPopUpCancelBtn).click();
				return require('./productsPageObject.js');
			};

			this.selectFirstElementFromDropDown=function(){		
				element(firstElementFromDropDown).click();
			};

			this.verifyErrorMessage=function(){
              element(missingIssuerErrorMsg).getText().then(function (text) {
				  expect(text).toBe('Please choose an Issuer');
			  })
			};
           
		   this.verifyCancelPopUpMessage=function(){
              element(cancelPopUpMessage).getText().then(function (text) {
				 expect(text).toContain('Are you sure you want to cancel the request? You will lose unsaved data'); 
				 console.log('PopUpMessage='+text);
			  });
		   };

};
module.exports=new create_products_page();