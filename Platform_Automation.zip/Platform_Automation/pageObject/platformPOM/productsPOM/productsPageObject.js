require('../productsPOM/createProductsPageObject.js');
require('../productsPOM/editProductPageObject.js');	
require('../subsidaryPOM/detailsSubsidaryPageObject.js');

var products_page=function(){
	//Subsidary Page Button
	var productsText=by.css('.header-title>h5');
	var prodFilterButton=by.buttonText('Filters');
    var prodDeleteButton=by.buttonText('Delete');
	var prodcreateButton=by.buttonText('Create');
	var prodExoprtOPtion=by.css('#product_export_button');
	var prodDelete_Yes_button=by.buttonText('Yes');
	var prodDelete_No_button=by.buttonText('No');
	var prodDelete_PopupMessage=by.css('.modal-body>p');
	var prodDelet_PopUpCloseIcon=by.css('.modal-dialog .confirm-close-icon');
	
	
	//Subsidary Grid table Element
	var checkBoxToSelectAll=by.css('product-listing .table-responsive thead tr th:nth-child(1) input');
	var product_code=by.css('product-listing .table-responsive thead tr th:nth-child(2)');
	var prod_Description=by.css('product-listing .table-responsive thead tr th:nth-child(3)');
	var prod_Issuer=by.css('product-listing .table-responsive thead tr th:nth-child(4)');
	var valid_from=by.css('product-listing .table-responsive thead tr th:nth-child(5)');	
	var valid_To=by.css('product-listing .table-responsive thead tr th:nth-child(6)');	
	var updatedBy=by.css('product-listing .table-responsive thead tr th:nth-child(7)');
	var updatedOn=by.css('product-listing .table-responsive thead tr th:nth-child(8)');
	
	
	//filter pane elements
	//var filter_SubsidaryCode_drpdwn=by.css('span.btn.btn-default.btn-secondary.form-control.ui-select-toggle'));
	var filter_Products_drpdwn=by.css('.col-sm-3:nth-child(1) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
	var filter_ProductsCode_inputBox=by.css('input.form-control.ui-select-search');
	var filter_ProductsCodeList=by.css('.dropdown-item>div');
	var filter_Description=by.css('input#product_filter_description');
	var filter_Issuer_drpdwn=by.css('.col-sm-3:nth-child(3) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
	var filter_Issuer_inputBox=by.css('input.form-control.ui-select-search');
	var filter_Clear_Button=by.buttonText('Clear');
	var filter_Apply_Button=by.buttonText('Apply');
	var filter_CloseIcon=by.css('i.fa.fa-times.filter-close-icon');
	var firstElementFromDropDown=by.css('product-listing .ui-select-choices li:nth-child(1) a div');
	
	//Table Element
	var firstRowFromTable=by.css('product-listing fng-table table tbody tr:nth-child(1)');
	var allRowsFromTable=by.css('product-listing fng-table table tbody tr');
	var nextSingleArrowOfPagination=by.css('[ng-reflect-inner-h-t-m-l="&#8250;"]');
	var firstRowEditButton= by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(9) button i');
	var firstRowProductCode=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(2) div div');	
	var firstRowDescription=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(3) div div');	
	var firstRowUpdatedBy=By.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(7) div div');
	var firstRowUpdatedOn=By.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(8) div div');
	var selectFirstRecordwithCheckbox=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(1) input');
    var firstRowEditButton=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(9) button');
	var descrptionList=by.css('.table-responsive>table>tbody>tr td:nth-child(3) div');
	
	var editIconForEachProduct=by.css('.table-responsive>table>tbody>tr>td:nth-child(9) button');
	var flag=false;
	
	//Subsidary Page Button Present
	this.productsTextIsPresent=function(){		
		 element.all(productsText).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('products Text is present');				
		});		
		
	};
	
	this.prodfilterButtonIsPresent=function(){		
		element.all(prodFilterButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('Filter Button is present');				
		});	
	};
	
	this.prodDeleteButtonIsPresent=function(){		
		element.all(prodDeleteButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('Prod Delete Button is present');				
		});
	};
	
	this.prodDeleteButtonIsEnabled=function(){
		if(element(prodDeleteButton).isEnabled()){
			console.log('Delete button is enabled');
			flag=true;
		}
		return flag;
	};
	
	this.prodCreateButtonIsPresent=function(){		
		element.all(prodcreateButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('Prod Create Button is present');				
		});
		
	};
	
   	this.prodExportOptionIsPresent=function(){		
		element.all(prodExoprtOPtion).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('Prod Create Button is present');				
		});
		
	};

	//Subsidary Grid Element Present or Not
	this.checkBoxToSelectAllIsPresent=function(){		
       element.all(checkBoxToSelectAll).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('checkBox To Select All element on Page is present');				
		});		
	};
	
	this.clickOnCheckBoxToSelectAllProductsOnPage=function(){
		element(checkBoxToSelectAll).click();
				
	};
	
	this.productCodeIsPresent=function(){		
        element.all(product_code).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('product_code is present');				
		});				
	};
	
	
	this.prod_DescriptionIsPresent=function(){		
        element.all(prod_Description).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('prod_Description is present');				
		});			
	};

	this.prod_IssuerIsPresent=function(){		
        element.all(prod_Issuer).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('prod_Issuer is present');				
		});			
	};
	
	this.valid_fromIsPresent=function(){	
        element.all(valid_from).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('valid_from is present');				
		});			
	};
	
	this.valid_ToIsPresent=function(){			
        element.all(valid_To).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('valid_To is present');				
		});			
	};
	
	this.updatedByIsPresent=function(){		
        element.all(updatedBy).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('updatedBy is present');				
		});			
	};
	
	this.updatedOnIsPresent=function(){		
        element.all(updatedOn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('updatedOn is present');				
		});			
	};
	
	
	//Click On Filter,Delete,Create Button of Subsidary
	this.clickOnProdFilterButton=function(){
		element(prodFilterButton).click();		
	};
	
	this.clickOnProdDeleteButton=function(){
		element(prodDeleteButton).click();		
	};
	
	this.clickOnProdCreateButton=function(){
		element(prodcreateButton).click();
        return require('./createProductsPageObject.js');		
	};
	
	this.clickOnProdDeleteYesButton=function(){
		element(prodDelete_Yes_button).click();
	}
	
	this.clickOnProdDeleteNoButton=function(){
		element(prodDelete_No_button).click();
	}
	
    this.closeIconOfPopUpIsPresent=function(){		
        element.all(prodDelet_PopUpCloseIcon).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('delet_PopUpCloseIcon is present');				
		});      		
	};

    this.clickOnCloseIconOfPopUp=function(){
			element(prodDelet_PopUpCloseIcon).click();
	};

	this.getTextOfDeletePopup=function(){
		element.all(prodDelete_PopupMessage).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);					  
						itemList[0].getText().then(function(text) {								         
								console.log('Message='+text);
								expect(text).toBe("Are you sure you want to delete the selected records?");		
							 
						});					
			});	
     }
	 
	 this.getTextOfDeletePopupForEntirePage=function(){
		element.all(prodDelete_PopupMessage).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);					  
						itemList[1].getText().then(function(text) {								         
								console.log('Message='+text);
								expect(text).toContain("Records selected");		
							 
						});					
			});	
     }
	 
	//Filter Pane element present verification
	this.filter_Products_drpdwnIsPresent=function(){		
        element.all(filter_Products_drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Products_drpdwn is present');				
		});    	
		
	};
	
	this.filter_DescriptionIsPresent=function(){		
        element.all(filter_Description).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Description is present');				
		});    			
	};
	
	this.filter_Issuer_drpdwnIsPresent=function(){		
        element.all(filter_Issuer_drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Issuer_drpdwn is present');				
		});    	
		
	};
	
	this.filter_Clear_ButtonIsPresent=function(){		
       element.all(filter_Clear_Button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Clear_Button is present');				
		});   		
	};
	
	this.filter_Clear_ButtonIsNotPresent=function(){		
       element(filter_Clear_Button).getText().then(function(items) {
				expect(items).toBe('');				
				console.log('filter_Clear_Button is not present');				
		});   		
	};

	this.filter_Apply_ButtonIsPresent=function(){		
       element.all(filter_Apply_Button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Apply_Button is present');			
		});  		
	};
	
	this.filter_Apply_ButtonIsNotPresent=function(){		
       element(filter_Apply_Button).getText().then(function(items) {
				expect(items).toBe('');				
				console.log('filter_Apply_Button is not present');				
		});  		
	};
	this.filter_CloseIconIsPresent=function(){		
        element.all(filter_CloseIcon).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('filter_CloseIcon is not present');				
		});  		
	};
	
	
	this.clickfilter_CloseIcon=function(){
			element(filter_CloseIcon).click();	
			console.log('Clicked on close icon of Filter Pane');
	};
	
	
	this.clickOnFilterProductsCodeDrpdwn=function(){		
		element(filter_Products_drpdwn).click();
	};

	this.clickOnFilterIssuerCodeDrpdwn=function(){		
		element(filter_Issuer_drpdwn).click();
	};
	
	this.enterTextInFilterProductCodeDrpDown=function(productCode){
           element(filter_ProductsCode_inputBox).sendKeys(productCode);
	};

	this.enterTextInFilterIssuerDrpDown=function(productCode){
           element(filter_Issuer_inputBox).sendKeys(productCode);
	};

	this.getTextOfFilterSubsidaryCodeDrpdown=function(){
		element(filter_ProductsCode_inputBox).getText().then(function (text) {
			expect(text).toBe("");
			console.log('TextOfFilterProductCodeCodeDrpdown='+text.length);
		});
	};

   this.getTextOfFilterDescription=function(){
      element(filter_Description).getText().then(function (text) {
		  expect(text).toBe("");
		  console.log('filter_Description text length='+text.length);
	  });   
   };
 
   this.getTextOfFilterIssuerCodeDrpdown=function(){
		element(filter_Issuer_inputBox).getText().then(function (text) {
			expect(text).toBe("");
			console.log('TextOfFilterIssuer Drpdown='+text.length);
		});
	};

	this.selectParticularIssuer=function(issuer){
		console.log('Select particular issuer ='+issuer);       
		 element(by.cssContainingText('.dropdown-item>div', issuer)).click();      
	};

	this.selectParticularProdCode=function(productCode){
		console.log('Select particular prod code='+productCode);
		element(by.cssContainingText('.dropdown-item>div', productCode)).click();

			/*element.all(filter_ProductsCodeList).then(function(itemList) {
				      var flag1=false;
					   var count=0;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						//  var count=0;
						itemList[i].getText().then(function(text) {
						  
							  if (text == productCode) {
								count++;
								//expect(text).toEqual(productCode);
								//break;
								//itemList[i].click();
								console.log('text=prodCode='+text);
							  } 
							 
						});
						
					 };
					 itemList[count].click();				
			});*/
	};

	
	
	this.isParticularProdCodePresentInDropDown=function(productCode){
		
			element.all(filter_ProductsCodeList).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						  var count=0;
						itemList[i].getText().then(function(text) {
						  
							  if (text == productCode) {
								count++;
								expect(text).toEqual(productCode);
								//break;
							  } 
							 
						});
					 };
				
			});
		
	};
   

   this.elementsInProdCodeDrpDown=function(){
	   element.all(filter_ProductsCodeList).then(function(itemList){
		   console.log("Total values in dropdown are: " + itemList.length);
		   expect(itemList.length>0).toBe(true);
	   });
   }

	this.productCodeContaingText=function(productCode){	
		//element(by.cssContainingText('.dropdown-item>div', productCode)).click();

			element.all(filter_ProductsCodeList).then(function(itemList) {
				     
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						//  var count=0;
						itemList[i].getText().then(function(text) {				  
							 
								expect(text.toLowerCase()).toContain(productCode);								
								console.log('text=prodCode='+text);							 
						});
						
					 };					 			
			});
	};
	
  this.productCodeNotPresentInDropDown=function(){
      element.all(filter_ProductsCodeList).then(function(itemList) {
          expect(itemList.length).toBe(0);
		  console.log('Elements in list='+itemList.length);
	  });
  };

  this.elementsPresentInDropDown=function(){
      element.all(filter_ProductsCodeList).then(function(itemList) {
          expect(itemList.length>0).toBe(true);
		  console.log('Elements in list are more than 0='+itemList.length);
	  });
  };

	/*issuerCodeDrpdwnContainsAllCode()=function(){
		element.all(filter_ProductsCodeList).then(function(itemList) {			
			expect(itemList.length>0).toBe(true);
		});
	};*/

    this.productDescriptionContaingText=function(description){	
		//element(by.cssContainingText('.dropdown-item>div', productCode)).click();

			element.all(descrptionList).then(function(itemList) {
				      var flag1=false;
					   var count=0;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						//  var count=0;
						itemList[i].getText().then(function(text) {				  
							 
								expect(text).toContain(description);								
								console.log('text=prodCode='+text);							 
						});
						
					 };					 			
			});
	};

	this.isParticularProductCodeNotPresntDropDown=function(productCode){
		  element.all(by.cssContainingText('.dropdown-item>div', productCode)).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('productCode is not present='+items.length);				
		});  	
	};
 
    this.isParticularIssuerNotPresntDropDown=function(issuerCode){
		  element.all(by.cssContainingText('.dropdown-item>div', issuerCode)).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('issuerCode is not present='+items.length);				
		});  	
	};


	this.firstElementFromDropDownIsPresent=function(){		
		 element.all(firstElementFromDropDown).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('firstElementFromDropDown is present');
				
		});		
	};
	
	this.selectFirstElementFromDropDown=function(){		
		element(firstElementFromDropDown).click();
	};
	
	this.clickOnFilterApplyButton=function(){
		element(filter_Apply_Button).click();
	};
	
	this.clickOnFilterClearButton=function(){
		element(filter_Clear_Button).click();
	};
	
	//Table element
	this.firstRowFromTableIsPresent= function(){
	   element.all(firstRowFromTable).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('firstRowFromTable is present');				
		});		
		
	};

	this.firstRowFromTableNotPresent=function(){
		element.all(allRowsFromTable).then(function(items) {
				expect(items.length).toBe(0);
				console.log('item in ='+items.length);
				console.log('elements are not present');
				
		});		
	};

	this.rowCountInTable=function(){
		element.all(allRowsFromTable).then(function(items) {
			     // if(items.length>=1)
				expect(items.length>=1).toBe(true);
				console.log('item in ='+items.length);
				console.log('elements in tables are more than 0');
				
		});		
	};
	
	this.eneterTextInDescriptionBox=function(descriptionText)
	{
		element(filter_Description).sendKeys(descriptionText);
	};
	
	
	
	//To read the data of particular column
	this.getDataOfFirstRowParticularColumn=function(columnNo,data){
		
			  element(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).getText().then(function(text){
				  console.log('sjfjgh='+text);
				  expect(text).toBe(data);
				  
			  });

				 // console.log(text);         	
	};
	
	this.dataForParticularColumnIsPresent=function(columnNo){
		
			/*  if(element(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).isPresent()){
				  flag=true;
			  }
				return flag;*/

			element.all(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).then(function(items) {
				var flag=false;
				if(items.length>0){
					flag=true;
				}
				expect(flag).toBe(true);
				console.log('item in ='+items.length);				
		   });	
	};
	
	this.checkEditButtonForEachProduct=function(){				 
					
            element.all(editIconForEachProduct).then(function(items) {				
				expect(items.length).toBe(10);
				console.log('item in ='+items.length);				
		   });

	};

	this.clickOnFirstRowsEditButton=function(){
		 element(firstRowEditButton).click();
		 return require('./editProductPageObject.js');	
	};
	
	this.checkMultipleRecordsWithCheckBox=function(){
                           var count=0;		
							for(var i=1;i<4;i++){							  
										 if(element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input[type="checkbox"]')).isPresent()){
											 element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input[type="checkbox"]')).click();
												count++;
												console.log('j='+i);												
										 }										 												
							 } 	
							 
							 if(count>1){
								 flag=true;
								 console.log('Count Of check box='+count);
							 }
		       return flag;
	};
	nextSingleArrowOfPaginationIsEnabled= function(){
		if(element(nextSingleArrowOfPagination).isEnabled()){
			flag=true;
		}
		return flag;
	};
	
	clickOnNextSingleArrowOfPagination= function(){
		element(nextSingleArrowOfPagination).click();
		
	};
	
	this.clickOnFirstRowsEditButton=function(){
		 element(firstRowEditButton).click();
		 return require('./editProductPageObject.js');	
	};
	
	this.clickOnfirstRowProductCode=function(){
		 element(firstRowProductCode).click();
		 return require('./detailsSubsidaryPageObject.js');	
	};

	this.getTextOfFirstRowProductCode=function(prodCode){		
		
		 element(firstRowProductCode).getText().then(function (text) {
			console.log('firstRowProductCode'+text);
			expect(text).toContain(prodCode); 
		 });
	};

	this.verifyLengthOfProdCode=function(){
          element(firstRowProductCode).getText().then(function (text) {
			console.log('firstRowProductCode'+text);
			expect(text.length<=30).toBe(true); 
		 });
	};
	
	this.getTextOfFirstRowDescription=function(description){	

		 element(firstRowDescription).getText().then(function (text) {
			console.log('firstRowDescription'+text);
			expect(text).toContain(description); 
		 });
	};

	this.getTextOfFirstRowUpdatedBy=function(){	

		 element(firstRowUpdatedBy).getText().then(function (text) {
			console.log('UpdatedBy='+text);
			expect(text).toBe(''); 
		 });
	};

	this.getTextOfFirstRowUpdatedOn=function(){	

		 element(firstRowUpdatedOn).getText().then(function (text) {
			console.log('UpdatedOn'+text);
			expect(text).toBe(''); 
		 });
	};
	

	this.selectFirstRecordwithCheckbox=function(){
		element(selectFirstRecordwithCheckbox).click();
		browser.sleep(5000).then(function(){console.log("Selected first record with checkbox")});			
	};

	this.selectMultipleRecordsWithCheckBox=function(){
		var count=0;
		for(i=1;i<4;i++){
              element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input')).click();
			  browser.sleep(2000).then(function(){console.log("Selected first 3 record with checkbox")});
			  count++;
		}
		expect(count>1).toBe(true);
	};
	
};
module.exports=new products_page();