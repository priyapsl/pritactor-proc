require('../productsPOM/productsPageObject.js');

var edit_product_page=function(){
	
			var edit_Product_code=by.css('edit-product input#product_edit_productcode');
			var edit_Product_Description=by.css('edit-product input#product_edit_description');
			var edit_Product_ValidFrom=by.css('edit-product input#product_edit_validfrom');
			var edit_Product_ValidTo=by.css('edit-product input#product_edit_validto');
			var edit_Product_Save_button=by.buttonText('Save');
			var edit_Product_Cancel_button=by.css('edit-product #product_edit_cancel_button');
            var edit_Product_Issuer_Drpdwn=by.css('.btn.btn-default.btn-secondary.form-control.ui-select-toggle');

			var edit_ProductCodeErrorMsg=by.css('edit-product .col-sm-3.has-error:nth-child(1) .error-msg>span:nth-child(2)');			
			var edit_DescriptionErrorMsg=by.css('edit-product .col-sm-3.has-error:nth-child(2) .error-msg>span:nth-child(2)');
			
            var edit_prodCodeStar=by.css('.col-sm-3:nth-child(1) .required-icon');
			var edit_DescriptionStar=by.css('.col-sm-3:nth-child(2) .required-icon');
            var edit_IssuerStar=by.css('.col-sm-3:nth-child(3) .required-icon');
            var edit_fromDateStar=by.css('.col-md-3:nth-child(1) .required-icon');
             var edit_ToDateStar=by.css('.col-md-3:nth-child(2) .required-icon');
			var flag=false;
            
			 this.editProductCodeIsPresent=function(){				
				element.all(edit_Product_code).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Product_code is present');				
				});  
			};
   
            
			 this.editProductDescriptionIsPresent=function(){				
				element.all(edit_Product_Description).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Product_Description is present');				
				});  
			};
			
			 this.editProductValidFromIsPresent=function(){				
				element.all(edit_Product_ValidFrom).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Product_ValidFrom is present');				
				}); 
			};
			
			 this.editProductValidToIsPresent=function(){				
				element.all(edit_Product_ValidTo).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Product_ValidTo is present');				
				}); 
			};
			
			this.editProductCancelButtonIsPresent=function(){
				
				element.all(edit_Product_Cancel_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Product_Cancel_button is present');				
				}); 
			};

            this.editProductIssuerDrpdwnIsPresent=function(){
				
				element.all(edit_Product_Issuer_Drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Product_Issuer_Drpdwn is present');				
				}); 
			};
			
			
			this.editProductSaveButtonIsPresent=function(){				
				element.all(edit_Product_Save_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Product_Save_button is present');				
				}); 
			};
			
            this.editProductStarIsPresent=function(){				
				element.all(edit_prodCodeStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_prodCodeStar is present');				
				}); 
			};
           
           this.editDescriptionStarIsPresent=function(){				
				element.all(edit_DescriptionStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_DescriptionStar is present');				
				}); 
			};

             this.editIssuerStarIsPresent=function(){				
				element.all(edit_IssuerStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_IssuerStar is present');				
				}); 
			};

             this.editFromDateStarIsPresent=function(){				
				element.all(edit_fromDateStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_fromDateStar is present');				
				}); 
			};
 
            this.editToDateStarIsPresent=function(){				
				element.all(edit_ToDateStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_ToDateStar is present');				
				}); 
			};


            

			
			
			this.eneterTextInEditProductCode=function(productCode)
				{
					element(edit_Product_code).sendKeys(productCode);
				};				
				
		    this.clearEditProductCode=function()
				{
					element(edit_Product_code).clear();
				};
			
		    this.eneterTextInEditProductDescription=function(productDescription)
				{
					element(edit_Product_Description).sendKeys(productDescription);
				};	

                 this.clearEditProductDescription=function()
				{
					element(edit_Product_Description).clear();
				};			
				
			this.eneterTextInValidDateFrom=function(dateFrom)
				{
					element(edit_Product_ValidFrom).sendKeys(dateFrom);
				};	
				
			this.eneterTextInValidDateTo=function(dateTo)
				{
					element(edit_Product_ValidTo).sendKeys(dateTo);
				};	
			
			this.clickOnSaveButton=function(){
				element(edit_Product_Save_button).click();
				return require('./productsPageObject.js');
			};

            this.clickOnClearSaveButton=function(){
				element(edit_Product_Save_button).click();
				//return require('./produtcsPageObject.js');
			};
			
			
			this.clickOnCancelButton=function(){
			    element(edit_Product_Cancel_button).click();
				return require('./productsPageObject.js');
			};
            
            this.verifyProductDescriptionErrorMsg=function(errorMsg){
               element(edit_DescriptionErrorMsg).getText().then(function (text) {
                   expect(text).toBe(errorMsg);
                   console.log('Error Message='+errorMsg);
               })
            };

            this.verifyProductMissingErrorMsg=function(errorMsg){
               element(edit_ProductCodeErrorMsg).getText().then(function (text) {
                   expect(text).toBe(errorMsg);
                   console.log('Error Message='+errorMsg);
               })
            };



};
module.exports=new edit_product_page();