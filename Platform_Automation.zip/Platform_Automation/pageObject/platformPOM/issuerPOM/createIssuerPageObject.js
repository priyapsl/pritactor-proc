require('../issuerPOM/issuerPageObject.js');

var create_issuer_page=function(){

			var create_Issuer_code=by.css('create-issuer #issuer_create_issuercode');
            var create_Issuer_Name=by.css('create-issuer #issuer_create_issuername');
            var create_Issuer_Debitor=by.css('create-issuer #issuer_create_debitor');
            var create_Issuer_Disponent=by.css('create-issuer #issuer_create_disponent');
            var create_Issuer_ValidFrom=by.css('create-issuer #issuer_create_validfrom');
			var create_Issuer_ValidTo=by.css('create-issuer #issuer_create_validto');			
			var create_Issuer_Subsidiary_DrpDown=by.css('#issuer_create_subsidiarySelector .ui-select-toggle');
			var create_Issuer_Subsidiary_InputBox=by.css('#issuer_create_subsidiarySelector .form-control.ui-select-search');
            var create_Parent_Issuer_Drpdwn=by.css('#issuer_create_parentIssuerSelector .form-control.ui-select-toggle');
            var create_Parent_Issuer_Inputbox=by.css('#issuer_create_parentIssuerSelector .form-control.ui-select-search');		
			var create_Issuer_Save_button=by.buttonText('Save');
			var create_Issuer_Cancel_button=by.css('create-issuer #issuer_create_cancel_button');
            var default_Language_Drpdwn=by.css('#issuer_create_languageSelect .form-control.ui-select-toggle');
            var default_Language_Inputbox=by.css('#issuer_create_languageSelect .form-control.ui-select-search');
            var documentRetentionPeriod=by.css('#issuer_create_documentRetentionUnitSelector input:nth-child(1)');
             var documentRetentionUnit=by.css('#issuer_create_documentRetentionUnitSelector input:nth-child(3)');
			 var notificationRetentionPeriod=by.css('#issuer_create_notificationRetentionUnitSelector input:nth-child(1)');
			 var notificationRetentionUnit=by.css('#issuer_create_notificationRetentionUnitSelector input:nth-child(3)');
             var uploadLogoBtn=by.css('.input-image-picker .upload-btn'); 
			 
			 var issuer_codeStar=by.css('.form-group:nth-child(1) .col-sm-3:nth-child(1) .required-icon');
			 var issuer_nameStar=by.css('.form-group:nth-child(1) .col-sm-3:nth-child(2) .required-icon');
			 var validFromStar=by.css('.form-group:nth-child(2) .col-md-3:nth-child(1) .required-icon');
			 var validToStar=by.css('.form-group:nth-child(2) .col-md-3:nth-child(2) .required-icon');
			 var subsidiaryStar=by.css('.form-group:nth-child(2) .col-sm-3 .required-icon');
             var languageStar=by.css('.form-group:nth-child(3) .col-sm-3:nth-child(1) .required-icon');
			 var notificationRetentionStar=by.css('.form-group:nth-child(3) .col-sm-3:nth-child(3) .required-icon');


			//var missingIssuerErrorMsg=by.css('.col-sm-3:nth-child(3) .error-msg>span:nth-child(2)');
			var missingIssuerCodeErrorMsg=by.css('.form-group:nth-child(1) .has-error:nth-child(1) .error-msg>span:nth-child(2)');
			var missingIssuerNameErrorMsg=by.css('.form-group:nth-child(1) .has-error:nth-child(2) .error-msg>span:nth-child(2)');
           var missingSubsidiaryCodeErrorMsg=by.css('.form-group:nth-child(2) .col-sm-3:nth-child(3) .error-msg span:nth-child(2)');
		   var wrongNotificationRetentionErrorMsg=by.css('.form-group:nth-child(3) .col-sm-3:nth-child(3) .error-msg span:nth-child(2)');

           var duplicateIssuerCodeErrorMsg=by.css('.entity-details-container>div.error-msg>span:nth-child(2)');
			var create_CancelPopUpOKBtn=by.css('#canceldialog_ok_button');
			var cancelPopUpMessage=by.css('cancel-dialog .modal-body>p');
			var create_CancelPopUpCancelBtn=by.css('#canceldialog_cancel_button');
			var firstElementFromDropDown=by.css('.ui-select-choices li:nth-child(1) a div');
 
           //Shipment Provider Pane
		   var addShipMentProviderIcon=by.css('#issuer_create_add_shipment i');
           var shipmentProviderCodeDrpwn=by.css('#shp_code_0');
           var selectShipmentMethodsDrpwn=by.css('#shp_methods_0 .overSelect');
           var shipmentDescription=by.css('.form-control.issuer-truncate-text.input-style');
           var shipment_ValidFrom=by.css('shp_validFrm_0');
		   var shipment_ValidTo=by.css('#shp_validTo_0');
           var shipment_DeleteIcon=by.css('#shp_del_0');
			var flag=false;

            this.createIssuerCodeIsPresent=function(){				
				element.all(create_Issuer_code).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Issuer_code is present');				
				});  
			};

			 this.createIssuerNameIsPresent=function(){				
				element.all(create_Issuer_Name).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Issuer_Name is present');				
				});  
			};

			this.createIssuerDebitorIsPresent=function(){				
				element.all(create_Issuer_Debitor).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Issuer_Debitor is present');				
				});  
			};

			this.createIssuerDisponentIsPresent=function(){				
				element.all(create_Issuer_Disponent).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Issuer_Disponent is present');				
				});  
			};

   
   
            
			
			
			 this.createIssuerValidFromIsPresent=function(){				
				element.all(create_Issuer_ValidFrom).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Issuer_ValidFrom is present');				
				});  
			};
			
			 this.createIssuerValidToIsPresent=function(){				
				element.all(create_Issuer_ValidTo).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Issuer_ValidTo is present');				
				});  
			};

			 this.createIssuerSubisidiaryDrpDwnIsPresent=function(){				
				element.all(create_Issuer_Subsidiary_DrpDown).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Issuer_Subsidiary_DrpDown is present');				
				});  
			};

          this.createParentIssuerDrpDwnIsPresent=function(){				
				element.all(create_Parent_Issuer_Drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Parent_Issuer_Drpdwn is present');				
				});  
			};

			this.defaultLanguageDrpDwnIsPresent=function(){				
				element.all(default_Language_Drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('default_Language_Drpdwn is present');				
				});  
			};


            this.documentRetentionPeriodInputIsPresent=function(){				
				element.all(documentRetentionPeriod).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('documentRetentionPeriod is present');				
				});  
			};

			this.documentRetentionUnitInputIsPresent=function(){				
				element.all(documentRetentionUnit).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('documentRetentionUnit is present');				
				});  
			};
			

			  this.notificationRetentionPeriodInputIsPresent=function(){				
				element.all(notificationRetentionPeriod).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('notificationRetentionPeriod is present');				
				});  
			};
			
            this.notificationRetentionUnitInputIsPresent=function(){				
				element.all(notificationRetentionUnit).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('notificationRetentionUnit is present');				
				});  
			};

			 this.uploadLogoBtnIsPresent=function(){				
				element.all(uploadLogoBtn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('uploadLogoBtn is present');				
				});  
			};

			this.creatISsuerCancelButtonIsPresent=function(){				
				element.all(create_Issuer_Cancel_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Issuer_Cancel_button is present');				
				});  
			};
			
			
			this.creatIssuerSaveButtonIsPresent=function(){			
				element.all(create_Issuer_Save_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Issuer_Save_button is present');				
				});  
			};

			this.issuerCodeStarIsPresent=function(){			
				element.all(issuer_codeStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('issuer_codeStar is present');				
				});  
			};

			this.issuerNameStarIsPresent=function(){			
				element.all(issuer_nameStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('issuer_nameStar is present');				
				});  
			};

			this.validFromStarIsPresent=function(){			
				element.all(validFromStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('validFromStar is present');				
				});  
			};

			this.validToStarIsPresent=function(){			
				element.all(validToStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('validToStar is present');				
				});  
			};

			this.subsidiaryStarIsPresent=function(){			
				element.all(subsidiaryStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('subsidiaryStar is present');				
				});  
			};

			this.languageStarIsPresent=function(){			
				element.all(languageStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('languageStar is present');				
				});  
			};
			

			this.notificationStarIsPresent=function(){			
				element.all(notificationRetentionStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('notificationRetentionStar is present');				
				});  
			};
			
			this.verifyTextOfErrorMessage=function(actualErrorMessage){
               element(create_ErrorMessageForDuplicateSubCode).getText().then(function (errorMessage) {
				   expect(errorMessage).toContain(actualErrorMessage);
				   console.log('error message='+errorMessage);
			   });
			};

		
			
			
			this.eneterTextInCreateIssuerCode=function(issuerCode)
				{
					element(create_Issuer_code).sendKeys(issuerCode);
				};	

          this.eneterTextInCreateIssuerName=function(issuerName)
				{
					element(create_Issuer_Name).sendKeys(issuerName);
				};

				this.eneterTextInCreateIssuerDebitor=function(debitor)
				{
					element(create_Issuer_Debitor).sendKeys(debitor);
				};	

				this.eneterTextInCreateIssuerDisponent=function(disponent)
				{
					element(create_Issuer_Disponent).sendKeys(disponent);
				};	
	

			
		  
			this.eneterTextInValidDateFrom=function(dateFrom)
				{
					element(create_Issuer_ValidFrom).sendKeys(dateFrom);
				};	
				
			this.eneterTextInValidDateTo=function(dateTo)
				{
					element(create_Issuer_ValidTo).sendKeys(dateTo);
				};

            this.eneterTextInIssuerSubsidiaryInputBox=function(subsidiary)
				{
					element(create_Issuer_Subsidiary_InputBox).sendKeys(subsidiary);
				};

			 this.eneterTextInParentIssuerInputBox=function(parentIssuer)
				{
					element(create_Parent_Issuer_Inputbox).sendKeys(parentIssuer);
				};

             this.eneterTextInDefaultLanguage=function(defaultLanguage)
				{
					element(default_Language_Inputbox).sendKeys(defaultLanguage);
				};


             this.eneterTextInDocumentRetentionPeriod=function(docRetentionPeriod)
				{
					element(documentRetentionPeriod).sendKeys(docRetentionPeriod);
				};

			 this.eneterTextInNotificationRetentionPeriod=function(notifyRetentionPeriod)
				{
					element(notificationRetentionPeriod).sendKeys(notifyRetentionPeriod);
				};	


			
			

			this.clickOnIssuerSubsidiaryDrpDwn=function(){
               
			   element(create_Issuer_Subsidiary_DrpDown).click();
			};	

			this.clickOnParentIssuerDrpDwn=function(){
               
			   element(create_Parent_Issuer_Drpdwn).click();
			};	

           this.clickOnDefaultLanguageDrpDwn=function(){               
			   element(default_Language_Drpdwn).click();
			};	
 
           this.clickOnDocumentRetentionUnitDrpDwn=function(){               
			   element(documentRetentionUnit).click();
			};

			 this.clickOnNotificationRetentionUnitDrpDwn=function(){               
			   element(notificationRetentionUnit).click();
			};	


			
			this.clickOnSaveButton=function(){
				element(create_Issuer_Save_button).click();
				return require('./issuerPageObject.js');
			};

			this.selectParticularIssuerSubsidiaryCode=function(subisidiary){	
						 element(by.cssContainingText('.dropdown-item>div', subisidiary)).click();
			}	

           this.selectParticularLanguage=function(language){	
						 element(by.cssContainingText('.dropdown-item>div', language)).click();
			}	
			this.selectParticularParentIssuer=function(parentIssuer){	
						 element(by.cssContainingText('.dropdown-item>div', parentIssuer)).click();
			}	

			this.selectParticularDocumentRetentionUnit=function(retentionUnit){	
						 element(by.cssContainingText('.dropdown-item>div', retentionUnit)).click();
			}	

			this.selectParticularNotifyRetentionUnit=function(notifyUnit){	
						 element(by.cssContainingText('.dropdown-item>div', notifyUnit)).click();
			}		
				
			
			this.clickOnCancelButton=function(){
			    element(create_Issuer_Cancel_button).click();
				
			};
			this.clickOnCanacelPopUpOk=function(){
                element(create_CancelPopUpOKBtn).click();
				return require('./issuerPageObject.js');
			};

			this.clickOnCanacelPopUpCancel=function(){
                element(create_CancelPopUpCancelBtn).click();
				return require('./issuerPageObject.js');
			};

			this.selectFirstElementFromDropDown=function(){		
				element(firstElementFromDropDown).click();
			};

			this.verifyErrorMessage=function(){
              element(missingIssuerErrorMsg).getText().then(function (text) {
				  expect(text).toBe('Please choose an Issuer');
			  })
			};

			this.verifyMissingSubsidiaryErrorMessage=function(errorMsg){
              element(missingSubsidiaryCodeErrorMsg).getText().then(function (text) {
				  expect(text).toBe(errorMsg);
			  })
			};

			this.verifyMissingIssuerCodeErrorMessage=function(errorMsg){
              element(missingIssuerCodeErrorMsg).getText().then(function (text) {
				  expect(text).toBe(errorMsg);
			  })
			};

			this.verifyMissingIssuerNameErrorMessage=function(errorMsg){
              element(missingIssuerNameErrorMsg).getText().then(function (text) {
				  expect(text).toBe(errorMsg);
			  })
			};

		  this.verifyWrongRetentionNotificationErrorMessage=function(errorMsg){
              element(wrongNotificationRetentionErrorMsg).getText().then(function (text) {
				  expect(text).toBe(errorMsg);
			  })
			};
           
		   this.verifyCancelPopUpMessage=function(){
              element(cancelPopUpMessage).getText().then(function (text) {
				 expect(text).toContain('Are you sure you want to cancel the request? You will lose unsaved data'); 
				 console.log('PopUpMessage='+text);
			  });
		   };

		   	this.verifyDuplicateIssuerCodeMsg=function(actualErrorMessage){
               element(duplicateIssuerCodeErrorMsg).getText().then(function (errorMessage) {
				   expect(errorMessage).toContain(actualErrorMessage);
				   console.log('error message='+errorMessage);
			   });
			};


		   //Shipment ProviderPane
		   this.clickOnShipmentProviderAddIcon=function(){
              element(addShipMentProviderIcon).click();
		   };

       this.shipmentProviderAddIconIsPresent=function(){				
				element.all(addShipMentProviderIcon).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('addShipMentProviderIcon is present');				
				});  
		};


		   this.clickOnShipmentProviderCodeDrpdwn=function(){
              element(shipmentProviderCodeDrpwn).click();
		   };

		 this.shipmentProviderCodeDrpwnIsPresent=function(){				
				element.all(shipmentProviderCodeDrpwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('shipmentProviderCodeDrpwn is present');				
				});  
		};

		 this.clickOnSelectShipmentMethodsCodeDrpdwn=function(){
              element(selectShipmentMethodsDrpwn).click();
		   };

		 this.selectShipmentMethodsDrpwnIsPresent=function(){				
				element.all(selectShipmentMethodsDrpwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('selectShipmentMethodsDrpwn is present');				
				});  
		};
		
		this.selectParticularShipmentMethods=function(shipmentMethods){	
						 element(by.cssContainingText('.view-page-value', shipmentMethods)).click();
		}

		this.selectParticularShipmentProvider=function(shimentProvider){
                element(by.cssContainingText('option', shimentProvider)).click();
		};

		 this.shipmentDescriptionIsPresent=function(){				
				element.all(shipmentDescription).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('shipmentDescription is present');				
				});  
		};	

		 this.shipmentValidFromIsPresent=function(){				
				element.all(shipment_ValidFrom).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('shipment_ValidFrom is present');				
				});  
		};	

		 this.shipmentValidToIsPresent=function(){				
				element.all(shipment_ValidTo).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('shipment_ValidTo is present');				
				});  
		};	

		 this.shipmentDeleteIconIsPresent=function(){				
				element.all(shipment_DeleteIcon).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('shipment_DeleteIcon is present');				
				});  
		};	
       
	   this.clickOnShipmentDeleteIcon=function(){
              element(shipment_DeleteIcon).click();
		   };

		this.noOfElementsInDrpDwn=function(){
             element.all('.dropdown-item>div').then(function (items) {
				 expect(items.length>0).toBe(true);
				 console.log('Elements='+items.length);
			 });
		};

};
module.exports=new create_issuer_page();