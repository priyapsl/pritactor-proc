require('../issuerPOM/issuerPageObject.js');

var edit_issuer_page=function(){
	
			var edit_issuer_code=by.css('edit-issuer input#issuer_edit_issuercode');
			var edit_issuer_Name=by.css('edit-issuer input#issuer_edit_issuername');
            var edit_issuer_Debitor=by.css('edit-issuer input#issuer_edit_debitor');
		    var edit_issuer_Disponent=by.css('edit-issuer input#issuer_edit_disponent');
			var edit_Issuer_ValidFrom=by.css('edit-issuer input#issuer_edit_validfrom');
			var edit_Issuer_ValidTo=by.css('edit-issuer input#issuer_edit_validto');
			var edit_Issuer_Save_button=by.buttonText('Save');
			var edit_Issuer_Cancel_button=by.css('edit-issuer #issuer_edit_cancel_button');

			var edit_subsidiaryDrpDwn=by.css('edit-issuer #issuer_edit_subsidiarySelector');
			var edit_subsidiaryInputBox=by.css('edit-issuer #issuer_edit_subsidiarySelector .form-control.ui-select-search');
            
            var edit_Parent_Issuer_Drpdwn=by.css('edit-issuer #issuer_edit_parentIssuerSelector');
            var edit_Parent_Issuer_InputBox=by.css('edit-issuer #issuer_edit_parentIssuerSelector input');

			var edit_LanguageDrpDwn=by.css('edit-issuer #isssuer_edit_languageSelect');
            var edit_LanguageInputBox=by.css('edit-issuer #isssuer_edit_languageSelect input');

			var documentRetentionInputBox=by.css('#documentRetentionPeriodId');
            var documentRetentionSpanDrpDwn=by.css('edit-issuer #issuer_edit_documentRetentionUnitSelector ng-select');
         
		    var notificationRetentionInputBox=by.css('#issuer_edit_notificationRetentionUnitSelector input:nth-child(1)');
			var changeLogoOption=by.css('.upload-btn');

	

			var edit_ProductCodeErrorMsg=by.css('edit-product .col-sm-3.has-error:nth-child(1) .error-msg>span:nth-child(2)');			
			var edit_DescriptionErrorMsg=by.css('edit-product .col-sm-3.has-error:nth-child(2) .error-msg>span:nth-child(2)');
			
            var edit_prodCodeStar=by.css('.col-sm-3:nth-child(1) .required-icon');
			var edit_DescriptionStar=by.css('.col-sm-3:nth-child(2) .required-icon');
            var edit_IssuerStar=by.css('.col-sm-3:nth-child(3) .required-icon');
            var edit_fromDateStar=by.css('.col-md-3:nth-child(1) .required-icon');
             var edit_ToDateStar=by.css('.col-md-3:nth-child(2) .required-icon');
			var flag=false;
            
			 this.editIssuerCodeIsPresent=function(){				
				element.all(edit_issuer_code).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_issuer_code is present');				
				});  
			};

			this.verifyTextOfEditIssuerCode=function(issuerCode){	
				element(edit_issuer_code).getAttribute('value').then(function (text) {
				expect(text).toBe(issuerCode);
				console.log('text='+text);
				});
			};
   
            
			 this.editIssuerNameIsPresent=function(){				
				element.all(edit_issuer_Name).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_issuer_Name is present');				
				});  
			};

			this.verifyTextOfEditIssuerName=function(issuerName){	
				element(edit_issuer_Name).getAttribute('value').then(function (text) {
				expect(text).toBe(issuerName);
				console.log('issuerName='+text);
				});
			};

			 this.editIssuerDisponentIsPresent=function(){				
				element.all(edit_issuer_Disponent).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_issuer_Disponent is present');				
				});  
			};

            this.verifyTextOfEditDisponent=function(disponent){	
				element(edit_issuer_Disponent).getAttribute('value').then(function (text) {
				expect(text).toBe(disponent);
				console.log('disponent='+text);
				});
			};
               

			 this.editIssuerDebitorIsPresent=function(){				
				element.all(edit_issuer_Debitor).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_issuer_Debitor is present');				
				});  
			};

			 this.verifyTextOfEditDebitor=function(debitor){	
				element(edit_issuer_Debitor).getAttribute('value').then(function (text) {
				expect(text).toBe(debitor);
				console.log('debitor='+text);
				});
			};
			
			 this.editValidFromIsPresent=function(){				
				element.all(edit_Issuer_ValidFrom).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Issuer_ValidFrom is present');				
				}); 
			};
			
			 this.editValidToIsPresent=function(){				
				element.all(edit_Issuer_ValidTo).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Issuer_ValidTo is present');				
				}); 
			};
			
			this.editIssuerCancelButtonIsPresent=function(){
				
				element.all(edit_Issuer_Cancel_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Product_Cancel_button is present');				
				}); 
			};

            this.editProductIssuerDrpdwnIsPresent=function(){
				
				element.all(edit_Product_Issuer_Drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Product_Issuer_Drpdwn is present');				
				}); 
			};
			
			
			this.editIssuerSaveButtonIsPresent=function(){				
				element.all(edit_Issuer_Save_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Issuer_Save_button is present');				
				}); 
			};
			
            this.editProductStarIsPresent=function(){				
				element.all(edit_prodCodeStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_prodCodeStar is present');				
				}); 
			};
           
           this.editDescriptionStarIsPresent=function(){				
				element.all(edit_DescriptionStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_DescriptionStar is present');				
				}); 
			};

             this.editIssuerStarIsPresent=function(){				
				element.all(edit_IssuerStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_IssuerStar is present');				
				}); 
			};

             this.editFromDateStarIsPresent=function(){				
				element.all(edit_fromDateStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_fromDateStar is present');				
				}); 
			};
 
            this.editToDateStarIsPresent=function(){				
				element.all(edit_ToDateStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_ToDateStar is present');				
				}); 
			};

			 this.editParentIssuerDrpdwnIsPresent=function(){				
				element.all(edit_Parent_Issuer_Drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Parent_Issuer_Drpdwn is present');				
				}); 
			};

			 this.editSubsidiaryDrpdwnIsPresent=function(){				
				element.all(edit_subsidiaryDrpDwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_subsidiaryDrpDwn is present');				
				}); 
			};

			 this.editLanguageDrpdwnIsPresent=function(){				
				element.all(edit_LanguageDrpDwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_LanguageDrpDwn is present');				
				}); 
			};


            this.clickLanguageDrpdwnt=function(){				
				element(edit_LanguageDrpDwn).click();
				
			};

		   this.selectParticularLanguage=function(language){	
						 element(by.cssContainingText('.dropdown-item>div', language)).click();
			}	


             this.editDocumentRetentionIsPresent=function(){				
				element.all(documentRetentionInputBox).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('documentRetentionInputBox is present');				
				}); 
			};


              this.editNotificationRetentionIsPresent=function(){				
				element.all(notificationRetentionInputBox).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('notificationRetentionInputBox is present');				
				}); 
			};


            this.changeLogoOptionIsPresent=function(){				
				element.all(changeLogoOption).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('changeLogoOption is present');				
				}); 
			};


             this.clickOnParentIssuerDrpdwn=function(){
                 element(edit_Parent_Issuer_Drpdwn).click();
			 };

			 this.elementNotPresentInParentIssuerDrpdwn=function(parentIssuer){
                element.all(by.cssContainingText('.dropdown-item>div',parentIssuer)).then(function(items){
                   expect(items.length).toBe(0);
				   console.log('Control comes in Dropdown list')
				});
			 };
            

			
			
			this.eneterTextInEditIssuerCode=function(issuerCode)
				{
					element(edit_issuer_code).sendKeys(issuerCode);
				};				
				
		    this.clearEditIssuerCode=function()
				{
					element(edit_issuer_code).clear();
				};
			
		    this.eneterTextInEditIssuerName=function(issuerName)
				{
					element(edit_issuer_Name).sendKeys(issuerName);
				};	

            this.clearEditIssuerName=function()
				{
					element(edit_issuer_Name).clear();
				};	

			this.eneterTextInEditIssuerDebitor=function(debitor)
				{
					element(edit_issuer_Debitor).sendKeys(debitor);
				};

				 this.clearEditIssuerDebitor=function()
				{
					element(edit_issuer_Debitor).clear();
				};

			this.eneterTextInEditIssuerDisponent=function(disponent)
				{
					element(edit_issuer_Disponent).sendKeys(disponent);
				};					
				
		    this.clearEditIssuerDisponent=function()
				{
					element(edit_issuer_Disponent).clear();
				};	


             this.clearValidFromDate=function()
				{
					element(edit_Issuer_ValidFrom).clear();
				};	

				this.clearValidToDate=function()
				{
					element(edit_Issuer_ValidTo).clear();
				};	
				
			this.eneterTextInValidDateFrom=function(dateFrom)
				{
					element(edit_Issuer_ValidFrom).sendKeys(dateFrom);
				};	
				
			this.eneterTextInValidDateTo=function(dateTo)
				{
					element(edit_Issuer_ValidTo).sendKeys(dateTo);
				};	
			
			this.clickOnSaveButton=function(){
				element(edit_Issuer_Save_button).click();
				return require('./issuerPageObject.js');
			};

            this.clickOnClearSaveButton=function(){
				element(edit_Issuer_Save_button).click();
				//return require('./produtcsPageObject.js');
			};
			
			
			this.clickOnCancelButton=function(){
			    element(edit_Issuer_Cancel_button).click();
				return require('./productsPageObject.js');
			};
            
            this.verifyProductDescriptionErrorMsg=function(errorMsg){
               element(edit_DescriptionErrorMsg).getText().then(function (text) {
                   expect(text).toBe(errorMsg);
                   console.log('Error Message='+errorMsg);
               })
            };

            this.verifyProductMissingErrorMsg=function(errorMsg){
               element(edit_ProductCodeErrorMsg).getText().then(function (text) {
                   expect(text).toBe(errorMsg);
                   console.log('Error Message='+errorMsg);
               })
            };



};
module.exports=new edit_issuer_page();