require('../issuerPOM/issuerPageObject.js');
require('../issuerPOM/editIssuerPageObject.js');

var details_issuer_page=function(){
	
            var details_Issuer_Edit_button=by.buttonText('Edit');
			var details_Issuer_Back_button=by.buttonText('Back');
			var details_IssuerCode=by.css('.form-group:nth-child(1) .col-sm-3:nth-child(1) .view-page-value');
			var details_IssuerName=by.css('.form-group:nth-child(1) .col-sm-3:nth-child(2) .view-page-value');
			var details_Debitor=by.css('.form-group:nth-child(1) .col-sm-3:nth-child(3) .view-page-value');
			var details_Disponent=by.css('.form-group:nth-child(1) .col-sm-3:nth-child(4) .view-page-value');
			var details_ValidFrom=by.css('.form-group:nth-child(2) .col-md-3:nth-child(1) .view-page-value');
			var details_ValidTo=by.css('.form-group:nth-child(2) .col-md-3:nth-child(2) .view-page-value');
            var details_Issuer_updateOn=by.css('.form-group:nth-child(4) .col-sm-3:nth-child(3) .view-page-value');
			var details_Issuer_updateBy=by.css('.form-group:nth-child(4) .col-sm-3:nth-child(4) .view-page-value');
			var details_Issuer_createdBy=by.css('.form-group:nth-child(4) .col-sm-3:nth-child(2) .view-page-value');

			var details_subsidaryCode_data=by.css('.form-group .row:nth-child(1) .col-sm-2 div');
			var details_subsidaryDescription_data=by.css('.form-group .row:nth-child(1) .col-sm-4 div');
			var flag=false;
			
			
			this.clickOnDetailsEditButton=function(){
				element(details_Issuer_Edit_button).click();
				 return require('./editIssuerPageObject.js');
			};
			
			this.clickOnDetailsBackButton=function(){
			    element(details_Issuer_Back_button).click();
				return require('./issuerPageObject.js');
			};
           
           this.detailsIssuerEditButtonIsPresent=function(){			  
			      element.all(details_Issuer_Edit_button).then(function(items) {
					expect(items.length).toBe(1);				
					console.log('issuer edit button is present='+items.length);				
	            });		
		   }

		    this.detailsIssuerBackButtonIsPresent=function(){			  
			      element.all(details_Issuer_Back_button).then(function(items) {
					expect(items.length).toBe(1);				
					console.log('issuer back button is present='+items.length);				
	            });		
		   }


          this.verifyTextOfIssuerCode=function(issuerCode){
               element(details_IssuerCode).getText().then(function (data) {
				   expect(data).toBe(issuerCode);
				   console.log('details_Issuer_updateOn ='+data);
			   });
		   };

		   this.verifyTextOfIssuerName=function(issuerName){
               element(details_IssuerName).getText().then(function (data) {
				   expect(data).toBe(issuerName);
				   console.log('details_Issuer_updateOn ='+data);
			   });
		   };


		     this.verifyTextOfDebitor=function(debitor){
               element(details_Debitor).getText().then(function (data) {
				   expect(data).toBe(debitor);
				   console.log('details_Debitor ='+data);
			   });
		   };

		    this.verifyTextOfDisponent=function(disponent){
               element(details_Disponent).getText().then(function (data) {
				   expect(data).toBe(disponent);
				   console.log('details_Disponent ='+data);
			   });
		   };


		   this.verifyTextOfValidFrom=function(validFrom){
               element(details_ValidFrom).getText().then(function (data) {
				   expect(data).toBe(validFrom);
				   console.log('details_ValidFrom ='+data);
			   });
		   };

		   this.verifyTextOfValidTo=function(validTo){
               element(details_ValidTo).getText().then(function (data) {
				   expect(data).toBe(validTo);
				   console.log('details_ValidTo ='+data);
			   });
		   };

		   this.verifyTextOfUpdatedOn=function(){
               element(details_Issuer_updateOn).getText().then(function (data) {
				   expect(data).toBe('');
				   console.log('details_Issuer_updateOn ='+data);
			   });
		   };

           this.verifyTextOfUpdatedBy=function(){
               element(details_Issuer_updateBy).getText().then(function (data) {
				   expect(data).toBe('');
				   console.log('details_Issuer_updateBy ='+data);
			   });
		   };

		   this.verifyTextOfCreatedBy=function(createdBy){
               element(details_Issuer_createdBy).getText().then(function (data) {
				   expect(data).toBe(createdBy.toLowerCase());
				   console.log('details_Issuer_createdBy ='+data);
			   });
		   };

};
module.exports=new details_issuer_page();
