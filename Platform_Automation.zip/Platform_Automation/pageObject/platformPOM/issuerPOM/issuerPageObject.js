require('../issuerPOM/editIssuerPageObject.js');	
require('../issuerPOM/detailsIssuerPageObject.js');
require('../issuerPOM/createIssuerPageObject.js');

var issuer_page=function(){
	//Subsidary Page Button
	var issuerText=by.css('.header-title>h5');
	var issuerFilterButton=by.buttonText('Filters');
    var issuerDeleteButton=by.buttonText('Delete');
	var issuerCreateButton=by.buttonText('Create');
	var issuerExoprtOPtion=by.css('#issuer_export_button');
	var issuerDelete_Yes_button=by.buttonText('Yes');
	var issuerDelete_No_button=by.buttonText('No');
	var issuerDelete_PopupMessage=by.css('.modal-body>p');
	var issuerDelet_PopUpCloseIcon=by.css('.modal-dialog .confirm-close-icon');
	
	
	//Subsidary Grid table Element
	var checkBoxToSelectAll=by.css('issuers .table-responsive thead tr th:nth-child(1) input');
	var issuer_code=by.css('issuers .table-responsive thead tr th:nth-child(2)');
	var issuer_Name=by.css('issuers .table-responsive thead tr th:nth-child(3)');
	var issuer_Debitor=by.css('issuers .table-responsive thead tr th:nth-child(4)');
	var issuer_Disponent=by.css('issuers .table-responsive thead tr th:nth-child(5)');
	var valid_from=by.css('issuers .table-responsive thead tr th:nth-child(6)');	
	var valid_To=by.css('issuers .table-responsive thead tr th:nth-child(7)');	
	var updatedBy=by.css('issuers .table-responsive thead tr th:nth-child(8)');
	var updatedOn=by.css('issuers .table-responsive thead tr th:nth-child(9)');
	
	
	//filter pane elements
	//var filter_SubsidaryCode_drpdwn=by.css('span.btn.btn-default.btn-secondary.form-control.ui-select-toggle'));
	var filter_IssuerCode_drpdwn=by.css('#issuer_filter_issuercode .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
	var filter_IssuerCode_inputBox=by.css('input.form-control.ui-select-search');	
	var filter_IssuerCodeList=by.css('.dropdown-item>div');

	var filter_IssuerName=by.css('input#issuer_filter_issuername');
	var filter_Issuer_Debitor=by.css('input#issuer_filter_debitor');
    var filter_Issuer_Disponent=by.css('input#issuer_filter_disponent'); 
	var filter_Clear_Button=by.buttonText('Clear');
	var filter_Apply_Button=by.buttonText('Apply');
	var filter_CloseIcon=by.css('i.fa.fa-times.close-icon');
	var firstElementFromDropDown=by.css('issuers .ui-select-choices li:nth-child(1) a div');

	
	//Table Element
	var firstRowFromTable=by.css('issuers fng-table table tbody tr:nth-child(1)');
	var allRowsFromTable=by.css('issuers fng-table table tbody tr');
	

	var firstRowEditButton= by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(10) .btn-group div:nth-child(2) button i');
	var firstRowIssuerHIerarchyIcon= by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(10) .btn-group div:nth-child(1) button i');
	var firstRowIssuerHierarchy=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(10) button:nth-child(1)');	
	var firstRowIssuerCode=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(2) div div');		
	var firstRowIssuerName=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(3) div div');	
	var firstRowDebitor=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(4) div div');
    var firstRowDisponenet=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(5) div div');
	
	var firstRowUpdatedBy=By.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(8) div div');
	var firstRowUpdatedOn=By.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(9) div div');
	var selectFirstRecordwithCheckbox=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(1) input');
    var selectAllRecordsOnPage=by.css('thead .table-checkbox>input');
  
	//var descrptionList=by.css('.table-responsive>table>tbody>tr td:nth-child(3) div');
	
	var editIconForEachIssuer=by.css('.table-responsive>table>tbody>tr>td:nth-child(10) button:nth-child(2) i');
	var issuerHierarchyIconForEachIssuer=by.css('.table-responsive>table>tbody>tr>td:nth-child(10) .btn-group div:nth-child(1) button i');
	var highLightedIssuer=by.css('#issuer_hierarchy_popup .highlight-issuer');
	var issuerHierarchyCloseIcon=by.css('#issuer_hierarchy_popup_close');
    //Pagination
	var nextSingleArrowOfPagination=by.css('li:nth-child(7) .page-link');
	var pageSizeSelector=by.css('#pageSizeSelector');
	var selectSize=by.css('select option[value="0"]');
	var noOfRecordsdisplayed=by.css('.col-sm-5.table-footer-text>p');
	var flag=false;
	
	//Subsidary Page Button Present
	this.issuerTextIsPresent=function(){		
		 element.all(issuerText).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('issuer Text is present');				
		});		
		
	};
	
	this.issuerFilterButtonIsPresent=function(){		
		element.all(issuerFilterButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('issuer Filter Button is present');				
		});	
	};
	
	this.issuerDeleteButtonIsPresent=function(){		
		element.all(issuerDeleteButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('issuer Delete Button is present');				
		});
	};
	
	this.issuerDeleteButtonIsEnabled=function(){
		if(element(issuerDeleteButton).isEnabled()){
			console.log('Delete button is enabled');
			flag=true;
		}
		return flag;
	};
	
	this.issuerCreateButtonIsPresent=function(){		
		element.all(issuerCreateButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('issuer Create Button is present');				
		});
		
	};
	
   	this.issuerExportOptionIsPresent=function(){		
		element.all(issuerExoprtOPtion).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('issuer Exoprt OPtion is present');				
		});
		
	};

	//Subsidary Grid Element Present or Not
	this.checkBoxToSelectAllIsPresent=function(){		
       element.all(checkBoxToSelectAll).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('checkBox To Select All element on Page is present');				
		});		
	};
	
	this.clickOnCheckBoxToSelectAllProductsOnPage=function(){
		element(checkBoxToSelectAll).click();
				
	};
	
	this.issuerCodeIsPresent=function(){		
        element.all(issuer_code).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('issuer code is present');				
		});				
	};

	this.issuerNameIsPresent=function(){		
        element.all(issuer_Name).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('issuer Name is present');				
		});				
	};
	
	this.issuerDebitorIsPresent=function(){		
        element.all(issuer_Debitor).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('issuer Debitor is present');				
		});				
	};
	
	this.issuerDisponentIsPresent=function(){		
        element.all(issuer_Disponent).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('issuer Disponent is present');				
		});				
	};
	
	this.valid_fromIsPresent=function(){	
        element.all(valid_from).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('valid_from is present');				
		});			
	};
	
	this.valid_ToIsPresent=function(){			
        element.all(valid_To).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('valid_To is present');				
		});			
	};
	
	this.updatedByIsPresent=function(){		
        element.all(updatedBy).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('updatedBy is present');				
		});			
	};
	
	this.updatedOnIsPresent=function(){		
        element.all(updatedOn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('updatedOn is present');				
		});			
	};
	
	
	//Click On Filter,Delete,Create Button of Subsidary
	this.clickOnissuerFilterButton=function(){
		element(issuerFilterButton).click();		
	};
	
	this.clickOnIssuerDeleteButton=function(){
		element(issuerDeleteButton).click();		
	};
	
	this.clickOnIssuerCreateButton=function(){
		element(issuerCreateButton).click();
        return require('./createIssuerPageObject.js');		
	};
	
	this.clickOnIssuerDeleteYesButton=function(){
		element(issuerDelete_Yes_button).click();
	}
	
	this.clickOnIssuerDeleteNoButton=function(){
		element(issuerDelete_No_button).click();
	}
	
    this.closeIconOfPopUpIsPresent=function(){		
        element.all(issuerDelet_PopUpCloseIcon).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('issuerDelet_PopUpCloseIcon is present');				
		});      		
	};

    this.clickOnCloseIconOfPopUp=function(){
			element(issuerDelet_PopUpCloseIcon).click();
	};

	this.getTextOfDeletePopup=function(){
		element.all(issuerDelete_PopupMessage).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);					  
						itemList[0].getText().then(function(text) {								         
								console.log('Message='+text);
								expect(text).toBe("Are you sure you want to delete the selected records?");		
							 
						});					
			});	
     }
	 
	 this.getTextOfDeletePopupForEntirePage=function(){
		element.all(issuerDelete_PopupMessage).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);					  
						itemList[1].getText().then(function(text) {								         
								console.log('Message='+text);
								expect(text).toContain("Records selected");		
							 
						});					
			});	
     }
	 
	//Filter Pane element present verification
	this.filter_IssuerCode_drpdwnIsPresent=function(){		
        element.all(filter_IssuerCode_drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_IssuerCode_drpdwn is present');				
		});    	
		
	};
	
	this.filter_IssuerNameIsPresent=function(){		
        element.all(filter_IssuerName).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_IssuerName is present');				
		});    			
	};
	
	this.filter_Issuer_DebitorIsPresent=function(){		
        element.all(filter_Issuer_Debitor).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Issuer_Debitor is present');				
		});    	
		
	};

	this.filter_Issuer_DisponentIsPresent=function(){		
        element.all(filter_Issuer_Disponent).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Issuer_Disponent is present');				
		});    	
		
	};
	
	
	this.filter_Clear_ButtonIsPresent=function(){		
       element.all(filter_Clear_Button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Clear_Button is present');				
		});   		
	};
	
	this.filter_Clear_ButtonIsNotPresent=function(){		
       element(filter_Clear_Button).getText().then(function(items) {
				expect(items).toBe('');				
				console.log('filter_Clear_Button is not present');				
		});   		
	};

	this.filter_Apply_ButtonIsPresent=function(){		
       element.all(filter_Apply_Button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Apply_Button is present');			
		});  		
	};
	
	this.filter_Apply_ButtonIsNotPresent=function(){		
       element(filter_Apply_Button).getText().then(function(items) {
				expect(items).toBe('');				
				console.log('filter_Apply_Button is not present');				
		});  		
	};
	this.filter_CloseIconIsPresent=function(){		
        element.all(filter_CloseIcon).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_CloseIcon is present');				
		});  		
	};
	
	
	this.clickfilter_CloseIcon=function(){
			element(filter_CloseIcon).click();	
			console.log('Clicked on close icon of Filter Pane');
	};
	
	
	this.clickOnFilterIssuerCodeDrpdwn=function(){		
		element(filter_IssuerCode_drpdwn).click();
	};

	
	
	this.enterTextInFilterIssuerCodeDrpDown=function(issuerCode){
           element(filter_IssuerCode_inputBox).sendKeys(issuerCode);
	};

	this.enterTextInFilterIssuerDebitor=function(debitor){
           element(filter_Issuer_Debitor).sendKeys(debitor);
	};

   this.enterTextInFilterIssuerDisponent=function(disponent){
           element(filter_Issuer_Disponent).sendKeys(disponent);
	};


	this.getTextOfFilterIssuerCodeDrpdown=function(){
		element(filter_IssuerCode_inputBox).getText().then(function (text) {
			expect(text).toBe("");
			console.log('TextOfFilterProductCodeCodeDrpdown='+text.length);
		});
	};

   this.getTextOfFilterIssuerName=function(){
     

      element(filter_IssuerName).getText().then(function (text) {
		  expect(text).toBe('');
		  console.log('filter_IssuerName text length='+text.length);
	  });   
   };
 
 this.getTextOfFilterIssuerDebitor=function(debitor){
    element(filter_Issuer_Debitor).getText().then(function (text) {
		  expect(text).toBe('');
		  console.log('filter_Issuer_Debitor ='+text.length);
	  }); 
   };
  
  this.getTextOfFilterIssuerDisponent=function(disponent){

	 element(filter_Issuer_Disponent).getText().then(function (text) {
		  expect(text).toBe('');
		  console.log('filter_Issuer_Disponent ='+text.length);
	  });  
   };
  

	this.selectParticularIssuer=function(issuer){
		console.log('Select particular issuer ='+issuer);       
		 element(by.cssContainingText('.dropdown-item>div', issuer)).click();      
	};

	this.selectParticularProdCode=function(issuerCode){
		console.log('Select particular prod code='+issuerCode);
		element(by.cssContainingText('.dropdown-item>div', issuerCode)).click();

			/*element.all(filter_ProductsCodeList).then(function(itemList) {
				      var flag1=false;
					   var count=0;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						//  var count=0;
						itemList[i].getText().then(function(text) {
						  
							  if (text == productCode) {
								count++;
								//expect(text).toEqual(productCode);
								//break;
								//itemList[i].click();
								console.log('text=prodCode='+text);
							  } 
							 
						});
						
					 };
					 itemList[count].click();				
			});*/
	};

	
	
	this.isParticularIssuerCodePresentInDropDown=function(IssuerCode){
		
			element.all(filter_IssuerCodeList).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						  var count=0;
						itemList[i].getText().then(function(text) {
						  
							  if (text == productCode) {
								count++;
								expect(text).toEqual(IssuerCode);
								//break;
							  } 
							 
						});
					 };
				
			});
		
	};
   

   this.elementsInIssuerCodeDrpDown=function(){
	   element.all(filter_IssuerCodeList).then(function(itemList){
		   console.log("Total values in dropdown are: " + itemList.length);
		   expect(itemList.length>0).toBe(true);
	   });
   }

	this.issuerCodeContaingText=function(IssuerCode){	
		//element(by.cssContainingText('.dropdown-item>div', productCode)).click();

			element.all(filter_IssuerCodeList).then(function(itemList) {
				     
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						//  var count=0;
						itemList[i].getText().then(function(text) {				  
							 
								expect(text.toLowerCase()).toContain(IssuerCode);								
								console.log('text=prodCode='+text);							 
						});
						
					 };					 			
			});
	};
	
  this.issuerCodeNotPresentInDropDown=function(){
      element.all(filter_IssuerCodeList).then(function(itemList) {
          expect(itemList.length).toBe(0);
		  console.log('Elements in list='+itemList.length);
	  });
  };

  this.elementsPresentInDropDown=function(){
      element.all(filter_IssuerCodeList).then(function(itemList) {
          expect(itemList.length>0).toBe(true);
		  console.log('Elements in list are more than 0='+itemList.length);
	  });
  };

	/*issuerCodeDrpdwnContainsAllCode()=function(){
		element.all(filter_ProductsCodeList).then(function(itemList) {			
			expect(itemList.length>0).toBe(true);
		});
	};*/

    this.productDescriptionContaingText=function(description){	
		//element(by.cssContainingText('.dropdown-item>div', productCode)).click();

			element.all(descrptionList).then(function(itemList) {
				      var flag1=false;
					   var count=0;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						//  var count=0;
						itemList[i].getText().then(function(text) {				  
							 
								expect(text).toContain(description);								
								console.log('text=prodCode='+text);							 
						});
						
					 };					 			
			});
	};

	this.isParticularProductCodeNotPresntDropDown=function(productCode){
		  element.all(by.cssContainingText('.dropdown-item>div', productCode)).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('productCode is not present='+items.length);				
		});  	
	};
 
    this.isParticularIssuerNotPresntDropDown=function(issuerCode){
		  element.all(by.cssContainingText('.dropdown-item>div', issuerCode)).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('issuerCode is not present='+items.length);				
		});  	
	};


	this.firstElementFromDropDownIsPresent=function(){		
		 element.all(firstElementFromDropDown).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('firstElementFromDropDown is present');
				
		});		
	};
	
	this.selectFirstElementFromDropDown=function(){		
		element(firstElementFromDropDown).click();
	};
	
	this.clickOnFilterApplyButton=function(){
		element(filter_Apply_Button).click();
	};
	
	this.clickOnFilterClearButton=function(){
		element(filter_Clear_Button).click();
	};
	
	//Table element
	this.firstRowFromTableIsPresent= function(){
	   element.all(firstRowFromTable).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('firstRowFromTable is present');				
		});		
		
	};

	this.firstRowFromTableNotPresent=function(){
		element.all(allRowsFromTable).then(function(items) {
				expect(items.length).toBe(0);
				console.log('item in ='+items.length);
				console.log('elements are not present');
				
		});		
	};

	this.rowCountInTable=function(){
		element.all(allRowsFromTable).then(function(items) {
			     // if(items.length>=1)
				expect(items.length>=1).toBe(true);
				console.log('item in ='+items.length);
				console.log('elements in tables are more than 0');
				
		});		
	};

	this.defaultRecordsInPage=function(){
		element.all(allRowsFromTable).then(function(items) {
			     // if(items.length>=1)
				expect(items.length).toBe(10);
				console.log('item in ='+items.length);
				console.log('elements in tables are 10');
				
		});		
	};
	
	this.eneterTextInfilter_IssuerName=function(issuerName)
	{
		element(filter_IssuerName).sendKeys(issuerName);
	};
	
	this.clearTextInfilter_IssuerName=function()
	{
		element(filter_IssuerName).clear();
	};
	
	
	//To read the data of particular column
	this.getDataOfFirstRowParticularColumn=function(columnNo,data){
		
			  element(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).getText().then(function(text){
				  console.log('sjfjgh='+text);
				  expect(text).toBe(data);
				  
			  });

				 // console.log(text);         	
	};
	
	this.dataForParticularColumnIsPresent=function(columnNo){
		
			/*  if(element(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).isPresent()){
				  flag=true;
			  }
				return flag;*/

			element.all(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).then(function(items) {
				var flag=false;
				if(items.length>0){
					flag=true;
				}
				expect(flag).toBe(true);
				console.log('item in ='+items.length);				
		   });	
	};
	
	this.checkEditButtonForIssuer=function(){				 
					
            element.all(editIconForEachIssuer).then(function(items) {				
				expect(items.length).toBe(10);
				console.log('item in ='+items.length);				
		   });

	};

	this.issuerHierarchyIconButtonForEachIssuer=function(){				 
					
            element.all(issuerHierarchyIconForEachIssuer).then(function(items) {				
				expect(items.length>1).toBe(true);
				console.log('item in ='+items.length);				
		   });

	};

	this.verifyNameOfHighlightedIssuer=function(issuer){
         element(highLightedIssuer).getText().then(function (text) {
			 expect(text).toBe(issuer);
			 console.log('issuer='+text);
		 });
	};

    this.clickOnIssuerHierarchyCloseIcon=function(){
           element(issuerHierarchyCloseIcon).click();
	};
	this.clickOnFirstRowsEditButton=function(){
		 element(firstRowEditButton).click();
		 return require('./editIssuerPageObject.js');	
	};

	this.clickOnFirstRowIssuerHierarchyIcon=function(){
		 element(firstRowIssuerHIerarchyIcon).click();			
	};
	
	this.checkMultipleRecordsWithCheckBox=function(){
                           var count=0;		
							for(var i=1;i<4;i++){							  
										 if(element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input[type="checkbox"]')).isPresent()){
											 element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input[type="checkbox"]')).click();
												count++;
												console.log('j='+i);												
										 }										 												
							 } 	
							 
							 if(count>1){
								 flag=true;
								 console.log('Count Of check box='+count);
							 }
		       return flag;
	};
	this.nextSingleArrowOfPaginationIsEnabled= function(){
		if(element(nextSingleArrowOfPagination).isEnabled()){
			flag=true;
		}
		return flag;
	};
	
	this.clickOnNextSingleArrowOfPagination= function(){
		element(nextSingleArrowOfPagination).click();
		
	}; 

	this.clickOnPageSizeSelector=function() {
	 element(pageSizeSelector).click();	
	};
	
	this.selectParticularPageSize=function(){
        element(selectSize).click();
	};

	this.verifyRecordsOnPage=function(){
	
       element(noOfRecordsdisplayed).getText().then(function(text) {
		   expect(text).toContain('11 - 20');
	   });
	};
	
	this.clickOnfirstRowIssuerCode=function(){
		 element(firstRowIssuerCode).click();
		 return require('./detailsIssuerPageObject.js');	
	};

	this.getTextOfFirstRowIssuerCode=function(prodCode){		
		
		 element(firstRowIssuerCode).getText().then(function (text) {
			console.log('firstRowIssuerCode'+text);
			expect(text).toContain(prodCode); 
		 });
	};

	this.verifyLengthOfProdCode=function(){
          element(firstRowIssuerCode).getText().then(function (text) {
			console.log('firstRowIssuerCode'+text);
			expect(text.length<=30).toBe(true); 
		 });
	};
	
	this.getTextOfFirstRowIssuerName=function(issuerName){	

		 element(firstRowIssuerName).getText().then(function (text) {
			console.log('firstRowIssuerName'+text);
			expect(text).toContain(issuerName); 
		 });
	};

	this.getTextOfFirstRowDebitor=function(debitor){	

		 element(firstRowDebitor).getText().then(function (text) {
			console.log('firstRowDebitor'+text);
			expect(text).toContain(debitor); 
		 });
	};

	this.getTextOfFirstRowDisponent=function(disponent){	

		 element(firstRowDisponenet).getText().then(function (text) {
			console.log('firstRowDisponenet'+text);
			expect(text).toContain(disponent); 
		 });
	};


	this.getTextOfFirstRowUpdatedBy=function(){	

		 element(firstRowUpdatedBy).getText().then(function (text) {
			console.log('UpdatedBy='+text);
			expect(text).toBe(''); 
		 });
	};

  	this.verifyTextOfFirstRowUpdatedBy=function(updateBy){	

		 element(firstRowUpdatedBy).getText().then(function (text) {
			console.log('UpdatedBy='+text);
			expect(text).toBe(updateBy.toLowerCase()); 
		 });
	};

	this.getTextOfFirstRowUpdatedOn=function(){	

		 element(firstRowUpdatedOn).getText().then(function (text) {
			console.log('UpdatedOn'+text);
			expect(text).toBe(''); 
		 });
	};
	

	this.selectFirstRecordwithCheckbox=function(){
		element(selectFirstRecordwithCheckbox).click();
		browser.sleep(5000).then(function(){console.log("Selected first record with checkbox")});			
	};

	this.selectAllRecordsWithCheckBox=function () {
	   	element(selectAllRecordsOnPage).click();
		browser.sleep(10000).then(function(){console.log("Selected All record with checkbox")});
	};

	this.selectMultipleRecordsWithCheckBox=function(){
		var count=0;
		for(i=1;i<4;i++){
              element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input')).click();
			  browser.sleep(5000).then(function(){console.log("Selected first 3 record with checkbox")});
			  count++;
		}
		expect(count>1).toBe(true);
	};
	
};
module.exports=new issuer_page();