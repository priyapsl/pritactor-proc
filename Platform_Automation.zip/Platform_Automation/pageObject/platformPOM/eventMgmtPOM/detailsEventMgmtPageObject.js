require('../eventMgmtPOM/eventMgmtPageObject.js');
require('../eventMgmtPOM/editEventMgmtPageObject.js');

var details_EventMgmt_page=function(){
	
            var details_Event_Edit_button=by.buttonText('Edit');
			var details_Event_Back_button=by.buttonText('Back');
			var details_Issuer=by.css('.form-group .row:nth-child(1) .col-sm-3:nth-child(1) .view-page-value');
			var details_Application=by.css('.form-group .row:nth-child(1) .col-sm-3:nth-child(2) .view-page-value');
			var details_EventName=by.css('.form-group .row:nth-child(1) .col-sm-3:nth-child(3) .view-page-value');


            var details_updateOn=by.css('.form-group:nth-child(7) .col-md-2:nth-child(3) .view-page-value');
			var details_Event_updateBy=by.css('.form-group:nth-child(7) .col-md-2:nth-child(4) .view-page-value');
			var details_Branch_createdBy=by.css('.form-group:nth-child(1) .row:nth-child(3) .col-sm-2:nth-child(2) .view-page-value');
			var flag=false;
			
			
			this.clickOnDetailsEditButton=function(){
				element(details_Event_Edit_button).click();
				 return require('./editEventMgmtPageObject.js');
			};
			
			this.clickOnDetailsBackButton=function(){
			    element(details_Event_Back_button).click();
				return require('./eventMgmtPageObject.js');
			};
           
           this.detailsEventEditButtonIsPresent=function(){
			      element.all(details_Event_Edit_button).then(function(items) {
					expect(items.length).toBe(1);				
					console.log('details_Event edit button is present='+items.length);
	            });		
		   }

		    this.detailsEventBackButtonIsPresent=function(){
			      element.all(details_Event_Back_button).then(function(items) {
					expect(items.length).toBe(1);				
					console.log('details_Event back button is present='+items.length);
	            });		
		   }




		   this.verifyTextOfApplication=function(application){
               element(details_Application).getText().then(function (data) {
				   expect(data).toBe(application);
				   console.log('details_Application ='+data);
			   });
		   };


		     this.verifyTextOfEventName=function(eventName){
               element(details_EventName).getText().then(function (data) {
				   expect(data).toBe(eventName);
				   console.log('details_EventName ='+data);
			   });
		   };

		    this.verifyTextOfIssuer=function(issuer){
               element(details_Issuer).getText().then(function (data) {
				   expect(data).toBe(issuer);
				   console.log('details_Issuer ='+data);
			   });
		   };




		   this.verifyTextOfUpdatedOn=function(){
               element(details_updateOn).getText().then(function (data) {
				   expect(data).toBe('');
				   console.log('details_updateOn ='+data);
			   });
		   };

           this.verifyTextOfUpdatedBy=function(){
               element(details_Event_updateBy).getText().then(function (data) {
				   expect(data).toBe('');
				   console.log('details_Event_updateBy ='+data);
			   });
		   };

		   this.verifyTextOfCreatedBy=function(createdBy){
               element(details_Branch_createdBy).getText().then(function (data) {
				   expect(data).toBe(createdBy.toLowerCase());
				   console.log('details_Branch_createdBy ='+data);
			   });
		   };

};
module.exports=new details_EventMgmt_page();
