require('../eventMgmtPOM/editEventMgmtPageObject.js');
require('../eventMgmtPOM/detailsEventMgmtPageObject.js');
require('../eventMgmtPOM/configureEventMgmtPageObject.js');

var eventMgmt_page=function(){
	//Subsidary Page Button
	var eventMgmtText=by.css('.col-md-4.config-title>h5');
	var eventMgmtFilterButton=by.css('#event_filters_button');
    var eventMgmtDeleteButton=by.buttonText('Delete');
	var eventMgmtConfigureButton=by.buttonText('Configure');
	var eventMgmtExoprtOPtion=by.css('#site_export_button');
	var eventMgmtDelete_Yes_button=by.buttonText('Yes');
	var eventMgmtDelete_No_button=by.buttonText('No');
	var eventMgmtDelete_PopupMessage=by.css('.modal-body>p:nth-child(1)');
	var eventMgmtDelete_PopUpCloseIcon=by.css('.modal-dialog .confirm-close-icon');
	
	
	//Event Mgmt Grid table Element
	var checkBoxToSelectAll=by.css('.table-responsive thead tr th:nth-child(1) input');
	var issuer=by.css('event-config .table-responsive thead tr th:nth-child(2)');
	var application=by.css('event-config .table-responsive thead tr th:nth-child(3)');

	var event_Name=by.css('event-config .table-responsive thead tr th:nth-child(4)');
	var event_Type=by.css('event-config .table-responsive thead tr th:nth-child(5)');

	var severity=by.css('event-config .table-responsive thead tr th:nth-child(6)');
	var updatedBy=by.css('event-config .table-responsive thead tr th:nth-child(7)');
	var updatedOn=by.css('event-config .table-responsive thead tr th:nth-child(8)');
	
	
	//filter pane elements
	//var filter_SubsidaryCode_drpdwn=by.css('span.btn.btn-default.btn-secondary.form-control.ui-select-toggle'));
    var filter_Issuer_drpdwn=by.css('.col-sm-3:nth-child(1) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
    var filter_Issuer_inputBox=by.css('input.form-control.ui-select-search');
    var filter_IssuerList=by.css('.dropdown-item>div');

	var applicationDisable=by.css('.col-sm-3 .ui-disabled');
	var application_drpdwn=by.css('.col-sm-3:nth-child(2) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
	var application_inputBox=by.css('input.form-control.ui-select-search');
	var applicationList=by.css('.dropdown-item>div');

	var versionDisable=by.css('.col-sm-2 .ui-disabled');
    var filter_Version_drpdwn=by.css('.col-sm-2 .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
	var filter_Version_inputBox=by.css('input.form-control.ui-select-search');
	var filter_VersionList=by.css('.dropdown-item>div');

    var eventDisable=by.css('.col-sm-4 .ui-disabled');
	var filterEventNameDrpdwn=by.css('.col-sm-4 .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
	var filter_EventInputBox=by.css('input.form-control.ui-select-search');
	var filter_EventList=by.css('.dropdown-item>div');

	
     
	var filter_Clear_Button=by.css('#event_filter_clear_button');
	var filter_Apply_Button=by.buttonText('Apply');
	var filter_CloseIcon=by.css('i.fa.fa-times.close-icon');
	var firstElementFromDropDown=by.css('branch-listing .ui-select-choices li:nth-child(1) a div');

	
	//Table Element
	var firstRowFromTable=by.css('event-config fng-table table tbody tr:nth-child(1)');
	var allRowsFromTable=by.css('event-config fng-table table tbody tr');
	

	var firstRowEditButton= by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(9) button i');

	var firstRowIssuer=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(2) div div');
	var firstRowApplication=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(3) div div');
	var firstRowEventName=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(4) div div');
    var firstRowEventType=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(5) div div');
	
	var firstRowUpdatedBy=By.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(7) div div');
	var firstRowUpdatedOn=By.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(8) div div');
	var selectFirstRecordwithCheckbox=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(1) input');
	var selectAllRecordsOnPage=by.css('thead .table-checkbox input');
 
	//var descrptionList=by.css('.table-responsive>table>tbody>tr td:nth-child(3) div');
	
	var editIconForEachEvent=by.css('.table-responsive>table>tbody>tr>td:nth-child(9) button i');
	
	
	
    //Pagination
	var nextSingleArrowOfPagination=by.css('li:nth-child(7) .page-link');
	var pageSizeSelector=by.css('#pageSizeSelector');
	var selectSize=by.css('select option[value="0"]');
	var noOfRecordsdisplayed=by.css('.col-sm-5.table-footer-text>p');
	var flag=false;
	
	//Subsidary Page Button Present
	this.eventMgmtTextIsPresent=function(){
		 element.all(eventMgmtText).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('eventMgmtText is present');
		});		
		
	};
	
	this.eventMgmtFilterButtonIsPresent=function(){
		element.all(eventMgmtFilterButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('eventMgmtFilterButton  is present');
		});	
	};
	
	this.eventMgmtDeleteButtonIsPresent=function(){
		element.all(eventMgmtDeleteButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('eventMgmt Delete Button is present');
		});
	};
	
	this.eventMgmtDeleteButtonIsEnabled=function(){
		if(element(eventMgmtDeleteButton).isEnabled()){
			console.log('Delete button is enabled');
			flag=true;
		}
		return flag;
	};
	
	this.eventMgmtConfigureButtonIsPresent=function(){
		element.all(eventMgmtConfigureButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('eventMgmt Configure Button is present');
		});
		
	};
	
   	this.eventMgmtExoprtOPtionIsPresent=function(){
		element.all(eventMgmtExoprtOPtion).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('eventMgmt Exoprt OPtion is present');
		});
		
	};

	//Subsidary Grid Element Present or Not
	this.checkBoxToSelectAllIsPresent=function(){		
       element.all(checkBoxToSelectAll).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('checkBox To Select All element on Page is present');				
		});		
	};
	
	this.clickOnCheckBoxToSelectAllProductsOnPage=function(){
		element(checkBoxToSelectAll).click();
				
	};
	
	this.issuerIsPresent=function(){
        element.all(issuer).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('issuer is present');
		});				
	};

	this.applicationIsPresent=function(){
        element.all(application).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('application is present');
		});				
	};
	
	this.eventNameIsPresent=function(){
        element.all(event_Name).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('event_Name  is present');
		});				
	};
	
	this.eventTypeIsPresent=function(){
        element.all(event_Type).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('event_Type is present');
		});				
	};
	
	this.severityIsPresent=function(){
        element.all(severity).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('severity is present');
		});			
	};
	
	this.valid_ToIsPresent=function(){			
        element.all(valid_To).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('valid_To is present');				
		});			
	};
	
	this.updatedByIsPresent=function(){		
        element.all(updatedBy).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('updatedBy is present');				
		});			
	};
	
	this.updatedOnIsPresent=function(){		
        element.all(updatedOn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('updatedOn is present');				
		});			
	};
	
	
	//Click On Filter,Delete,Create Button of Subsidary
	this.clickOnEventMgmtFilterButton=function(){
		element(eventMgmtFilterButton).click();
	};
	
	this.clickOnEventMgmtDeleteButton=function(){
		element(eventMgmtDeleteButton).click();
	};
	
	this.clickOnEventMgmtConfigureButton=function(){
		element(eventMgmtConfigureButton).click();
        return require('./configureEventMgmtPageObject.js');
	};
	
	this.clickOnEventMgmtDeleteYesButton=function(){
		element(eventMgmtDelete_Yes_button).click();
	};
	
	this.clickOnEventMgmtDeleteNoButton=function(){
		element(eventMgmtDelete_No_button).click();
	};
	
    this.closeIconOfPopUpIsPresent=function(){		
        element.all(eventMgmtDelete_PopUpCloseIcon).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('eventMgmtDelete_PopUpCloseIcon is present');
		});      		
	};

    this.clickOnCloseIconOfPopUp=function(){
			element(eventMgmtDelete_PopUpCloseIcon).click();
	};

	this.getTextOfDeletePopup=function(){
		element.all(eventMgmtDelete_PopupMessage).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);					  
						itemList[0].getText().then(function(text) {								         
								console.log('Message='+text);
								expect(text).toBe("Are you sure you want to delete the selected records?");		
							 
						});					
			});	
     }
	 
	 this.getTextOfDeletePopupForEntirePage=function(){
		element.all(eventMgmtDelete_PopupMessage).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);					  
						itemList[1].getText().then(function(text) {								         
								console.log('Message='+text);
								expect(text).toContain("Are you sure you want to delete the selected records");		
							 
						});					
			});	
     }
	 
	//Filter Pane element present verification
    this.filter_ApplicationDisabledIsPresent=function(){
        element.all(applicationDisable).then(function(items) {
            expect(items.length).toBe(1);
            console.log('applicationDisable is present');
        });

    };

	this.filter_Application_drpdwnIsPresent=function(){
        element.all(application_drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('application_drpdwn is present');
		});    	
		
	};

	this.filter_Application_drpdwnIsNotPresent=function(){
        element.all(application_drpdwn).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('application_drpdwn is not present');
		});    	
		
	};

    this.filter_VersionDisabledIsPresent=function(){
        element.all(versionDisable).then(function(items) {
            expect(items.length).toBe(1);
            console.log('versionDisable is present');
        });

    };

    this.filter_EventDisabledIsPresent=function(){
        element.all(eventDisable).then(function(items) {
            expect(items.length).toBe(1);
            console.log('eventDisable is present');
        });

    };

	this.filter_VErsion_drpdwnIsPresent=function(){
        element.all(filter_Version_drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Version_drpdwn is present');
		});    	
		
	};

	this.filter_Version_drpdwnIsNotPresent=function(){
        element.all(filter_Version_drpdwn).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('filter_Version_drpdwn is not present');
		});    	
		
	};


    this.filter_EventName_drpdwnIsPresent=function(){
        element.all(filterEventNameDrpdwn).then(function(items) {
            expect(items.length).toBe(1);
            console.log('filterEventNameDrpdwn is present');
        });

    };

    this.filter_EventName_drpdwnIsNotPresent=function(){
        element.all(filterEventNameDrpdwn).then(function(items) {
            expect(items.length).toBe(0);
            console.log('filterEventNameDrpdwn is not present');
        });

    };

	this.filter_Issuer_drpdwnIsPresent=function(){		
        element.all(filter_Issuer_drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Issuer_drpdwn is present');				
		});    	
		
	};

	this.filter_Issuer_drpdwnIsNotPresent=function(){		
        element.all(filter_Issuer_drpdwn).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('filter_Issuer_drpdwn is not present');				
		});    	
		
	};
	
	

	
	


	
	
	this.filter_Clear_ButtonIsPresent=function() {
        element.all(filter_Clear_Button).then(function (items) {
            expect(items.length).toBe(1);
            console.log('filter_Clear_Button is present');
        });
    };
	
	this.filter_Clear_ButtonIsNotPresent=function(){		
       element.all(filter_Clear_Button).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('filter_Clear_Button is not present');				
		});   		
	};

	this.filter_Apply_ButtonIsPresent=function(){		
       element.all(filter_Apply_Button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Apply_Button is present');			
		});  		
	};
	
	this.filter_Apply_ButtonIsNotPresent=function(){		
       element.all(filter_Apply_Button).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('filter_Apply_Button is not present');				
		});  		
	};
	this.filter_CloseIconIsPresent=function(){		
        element.all(filter_CloseIcon).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_CloseIcon is present');				
		});  		
	};

	this.filter_CloseIconIsNotPresent=function(){		
        element.all(filter_CloseIcon).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('filter_CloseIcon is not present');				
		});  		
	};
	
	
	this.clickfilter_CloseIcon=function(){
			element(filter_CloseIcon).click();	
			console.log('Clicked on close icon of Filter Pane');
	};
	
	
	this.clickOnFilterApplicationDrpdwn=function(){
		element(application_drpdwn).click();
	};

	this.clickOnFilterVersionDrpdwn=function(){
		element(filter_Version_drpdwn).click();
	};


    this.clickOnFilterEventDrpdwn=function(){
        element(filterEventNameDrpdwn).click();
    };


    this.clickOnFilterIssuerDrpdwn=function(){
		element(filter_Issuer_drpdwn).click();
	};



	
	
	this.enterTextInFilterApplicationDrpDown=function(application){
           element(application_inputBox).sendKeys(application);
	};

	this.enterTextInFilterVersionDrpDown=function(version){
           element(filter_Version_inputBox).sendKeys(version);
	};

   this.enterTextInFilterIssuerDrpDown=function(issuer){
           element(filter_Issuer_inputBox).sendKeys(issuer);
	};

    this.enterTextInFilterEventDrpDown=function(event){
        element(filter_EventInputBox).sendKeys(event);
    };






    this.getTextOfFilterApplicationDrpdown=function(){
		element(application_inputBox).getText().then(function (text) {
			expect(text).toBe("");
			console.log('TextOfFilterApplicationDrpdown='+text.length);
		});
	};

	this.getTextOfFilterVersionDrpdown=function(){
		element(filter_Version_inputBox).getText().then(function (text) {
			expect(text).toBe("");
			console.log('filter_Version_inputBox='+text.length);
		});
	};

    this.getTextOfFilterEventDrpdown=function(){
        element(filter_EventInputBox).getText().then(function (text) {
            expect(text).toBe("");
            console.log('filter_EventInputBox='+text.length);
        });
    };
   
   this.verifyTextOfFilterApplicationDrpdown=function(branchCode){
		element(application_inputBox).getText().then(function (text) {
			expect(text).toBe(branchCode);
			console.log('Text Of Filter application_inputBox='+text);
		});
	};
  
   this.selectParticularIssuer=function(issuer){
		console.log('Select particular issuer ='+issuer);       
		 element(by.cssContainingText('.dropdown-item>div', issuer)).click();
       browser.sleep(5000).then(function(){console.log("Selected Particular From Drpdwn")});
	};

    this.selectParticularFromDrpDwn=function(data){
        console.log('Select particular issuer ='+data);
        element(by.cssContainingText('.dropdown-item>div', data)).click();
        browser.sleep(5000).then(function(){console.log("Selected Particular From Drpdwn")});
    };
  

	this.selectParticularBranchode=function(branchCode){
		console.log('Select particular branchCode ='+branchCode);       
		 element(by.cssContainingText('.dropdown-item>div', branchCode)).click();      
	};

	this.selectParticularBranchName=function(branchName){
		console.log('Select particular branchName='+branchName);
		element(by.cssContainingText('.dropdown-item>div', branchName)).click();

			/*element.all(filter_ProductsCodeList).then(function(itemList) {
				      var flag1=false;
					   var count=0;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						//  var count=0;
						itemList[i].getText().then(function(text) {
						  
							  if (text == productCode) {
								count++;
								//expect(text).toEqual(productCode);
								//break;
								//itemList[i].click();
								console.log('text=prodCode='+text);
							  } 
							 
						});
						
					 };
					 itemList[count].click();				
			});*/
	};

	
	
	this.isParticularApplicationPresentInDropDown=function(application){
		
			element.all(applicationList).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						  var count=0;
						itemList[i].getText().then(function(text) {
						  
							  if (text == application) {
								count++;
								expect(text).toEqual(application);
								//break;
							  } 
							 
						});
					 };
				
			});
		
	};


	this.isParticularVersionPresentInDropDown=function(version){
		
			element.all(filter_VersionList).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						  var count=0;
						itemList[i].getText().then(function(text) {
						  
							  if (text == version) {
								count++;
								expect(text).toEqual(version);
								//break;
							  } 
							 
						});
					 };
				
			});
		
	};
   
   
   this.isParticularIssuerPresentInDropDown=function(issuer){
		
			element.all(filter_IssuerList).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						  var count=0;
						itemList[i].getText().then(function(text) {
						  
							  if (text == issuer) {
								count++;
								expect(text).toEqual(issuer);
								//break;
							  } 
							 
						});
					 };
				
			});
		
	};
   


   this.elementsInApplicationDrpDown=function(){
	   element.all(applicationList).then(function(itemList){
		   console.log("Total values in dropdown are: " + itemList.length);
		   expect(itemList.length>0).toBe(true);
	   });
   };

    this.elementsInVersionDrpDown=function(){
	   element.all(filter_VersionList).then(function(itemList){
		   console.log("Total values in dropdown are: " + itemList.length);
		   expect(itemList.length>0).toBe(true);
	   });
   };

    this.elementsInEventDrpDown=function(){
        element.all(filter_EventListt).then(function(itemList){
            console.log("Total values in dropdown are: " + itemList.length);
            expect(itemList.length>0).toBe(true);
        });
    };



    this.elementsInIssuerDrpDown=function(){
	   element.all(filter_IssuerList).then(function(itemList){
		   console.log("Total values in dropdown are: " + itemList.length);
		   expect(itemList.length>0).toBe(true);
	   });
   };

	this.applicationContaingText=function(application){
		//element(by.cssContainingText('.dropdown-item>div', productCode)).click();

			element.all(applicationList).then(function(itemList) {
				     
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						//  var count=0;
						itemList[i].getText().then(function(text) {				  
							 
								expect(text.toLowerCase()).toContain(application);
								console.log('text=application='+text);
						});
						
					 };					 			
			});
	};


	this.versionContaingText=function(version){
		//element(by.cssContainingText('.dropdown-item>div', productCode)).click();

			element.all(filter_VersionList).then(function(itemList) {
				     
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						//  var count=0;
						itemList[i].getText().then(function(text) {				  
							 
								expect(text.toLowerCase()).toContain(version);
								console.log('text=version='+text);
						});
						
					 };					 			
			});
	};
	
   this.issuerContaingText=function(issuer){	
		//element(by.cssContainingText('.dropdown-item>div', productCode)).click();

			element.all(filter_IssuerList).then(function(itemList) {
				     
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						//  var count=0;
						itemList[i].getText().then(function(text) {				  
							 
								expect(text.toLowerCase()).toContain(issuer);								
								console.log('text=issuer='+text);							 
						});
						
					 };					 			
			});
	};


  this.applicationNotPresentInDropDown=function(){
      element.all(applicationList).then(function(itemList) {
          expect(itemList.length).toBe(0);
		  console.log('Elements in list='+itemList.length);
	  });
  };

  this.versionNotPresentInDropDown=function(){
      element.all(filter_VersionList).then(function(itemList) {
          expect(itemList.length).toBe(0);
		  console.log('Elements in list='+itemList.length);
	  });
  };

    this.eventNotPresentInDropDown=function(){
        element.all(filter_EventList).then(function(itemList) {
            expect(itemList.length).toBe(0);
            console.log('Elements in list='+itemList.length);
        });
    };


    this.issuerNotPresentInDropDown=function(){
      element.all(filter_IssuerList).then(function(itemList) {
          expect(itemList.length).toBe(0);
		  console.log('Elements in list='+itemList.length);
	  });
  };


  this.elementsPresentInDropDown=function(){
      element.all(applicationList).then(function(itemList) {
          expect(itemList.length>0).toBe(true);
		  console.log('Elements in list are more than 0='+itemList.length);
	  });
  };

  this.elementsVersionPresentInDropDown=function(){
      element.all(filter_VersionList).then(function(itemList) {
          expect(itemList.length>0).toBe(true);
		  console.log('Elements in list are more than 0='+itemList.length);
	  });
  };

 this.elementsIssuerPresentInDropDown=function(){
      element.all(filter_IssuerList).then(function(itemList) {
          expect(itemList.length>0).toBe(true);
		  console.log('Elements in list are more than 0='+itemList.length);
	  });
  };
	/*issuerCodeDrpdwnContainsAllCode()=function(){
		element.all(filter_ProductsCodeList).then(function(itemList) {			
			expect(itemList.length>0).toBe(true);
		});
	};*/

    this.productDescriptionContaingText=function(description){	
		//element(by.cssContainingText('.dropdown-item>div', productCode)).click();

			element.all(descrptionList).then(function(itemList) {
				      var flag1=false;
					   var count=0;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						//  var count=0;
						itemList[i].getText().then(function(text) {				  
							 
								expect(text).toContain(description);								
								console.log('text=prodCode='+text);							 
						});
						
					 };					 			
			});
	};

	


	this.firstElementFromDropDownIsPresent=function(){		
		 element.all(firstElementFromDropDown).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('firstElementFromDropDown is present');
				
		});		
	};
	
	this.selectFirstElementFromDropDown=function(){		
		element(firstElementFromDropDown).click();
	};
	
	this.clickOnFilterApplyButton=function(){
		element(filter_Apply_Button).click();
	};
	
	this.clickOnFilterClearButton=function(){
		element(filter_Clear_Button).click();
	};
	
	//Table element
	this.firstRowFromTableIsPresent= function(){
	   element.all(firstRowFromTable).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('firstRowFromTable is present');				
		});		
		
	};

	this.firstRowFromTableNotPresent=function(){
		element.all(allRowsFromTable).then(function(items) {
				expect(items.length).toBe(0);
				console.log('item in ='+items.length);
				console.log('elements are not present');
				
		});		
	};

	this.rowCountInTable=function(){
		element.all(allRowsFromTable).then(function(items) {
			     // if(items.length>=1)
				expect(items.length>=1).toBe(true);
				console.log('item in ='+items.length);
				console.log('elements in tables are more than 0');
				
		});		
	};

	this.defaultRecordsInPage=function(){
		element.all(allRowsFromTable).then(function(items) {
			     // if(items.length>=1)
				expect(items.length).toBe(10);
				console.log('item in ='+items.length);
				console.log('elements in tables are 10');
				
		});		
	};
	
	
	
	
	//To read the data of particular column
	this.getDataOfFirstRowParticularColumn=function(columnNo,data){
		
			  element(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).getText().then(function(text){
				  console.log('sjfjgh='+text);
				  expect(text).toBe(data);
				  
			  });

				 // console.log(text);         	
	};
	
	this.dataForParticularColumnIsPresent=function(columnNo){
		
			/*  if(element(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).isPresent()){
				  flag=true;
			  }
				return flag;*/

			element.all(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).then(function(items) {
				var flag=false;
				if(items.length>0){
					flag=true;
				}
				expect(flag).toBe(true);
				console.log('item in ='+items.length);				
		   });	
	};
	
	this.checkEditButtonForEvent=function(){
					
            element.all(editIconForEachEvent).then(function(items) {
				expect(items.length>0).toBe(true);
				console.log('item in ='+items.length);				
		   });

	};





	this.clickOnFirstRowsEditButton=function(){
		 element(firstRowEditButton).click();
		 return require('./editEventMgmtPageObject.js');
	};


	this.checkMultipleRecordsWithCheckBox=function(){
                           var count=0;		
							for(var i=1;i<4;i++){							  
										 if(element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input[type="checkbox"]')).isPresent()){
											 element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input[type="checkbox"]')).click();
												count++;
												console.log('j='+i);												
										 }										 												
							 } 	
							 
							 if(count>1){
								 flag=true;
								 console.log('Count Of check box='+count);
							 }
		       return flag;
	};
	this.nextSingleArrowOfPaginationIsEnabled= function(){
		if(element(nextSingleArrowOfPagination).isEnabled()){
			flag=true;
		}
		return flag;
	};
	
	this.clickOnNextSingleArrowOfPagination= function(){
		element(nextSingleArrowOfPagination).click();
		
	}; 

	this.clickOnPageSizeSelector=function() {
	 element(pageSizeSelector).click();	
	};
	
	this.selectParticularPageSize=function(){
        element(selectSize).click();
	};

	this.verifyRecordsOnPage=function(){
	
       element(noOfRecordsdisplayed).getText().then(function(text) {
		   expect(text).toContain('1 - 10');
	   });
	};
	
	this.clickOnfirstRowIssuer=function(){
		 element(firstRowIssuer).click();
		 return require('./detailsEventMgmtPageObject.js');
	};

	this.getTextOfFirstRowIssuer=function(issuer){
		
		 element(firstRowIssuer).getText().then(function (text) {
			console.log('firstRowIssuer='+text);
			expect(text).toContain(issuer);
		 });
	};

	this.verifyLengthOfIssuer=function(){
          element(firstRowIssuer).getText().then(function (text) {
			console.log('firstRowIssuer='+text);
			expect(text.length<=30).toBe(true); 
		 });
	};
	
	this.getTextOfFirstRowApplication=function(application){

		 element(firstRowApplication).getText().then(function (text) {
			console.log('firstRowApplication='+text);
			expect(text).toContain(application);
		 });
	};

	this.getTextOfFirstRowEventName=function(eventName){

		 element(firstRowEventName).getText().then(function (text) {
			console.log('firstRowEventName='+text);
			expect(text).toContain(eventName);
		 });
	};

    this.getTextOfFirstRowEventType=function(eventType){

        element(firstRowEventType).getText().then(function (text) {
            console.log('firstRowEventType='+text);
            expect(text).toContain(eventType);
        });
    };





    this.getTextOfFirstRowUpdatedBy=function(){

		 element(firstRowUpdatedBy).getText().then(function (text) {
			console.log('UpdatedBy='+text);
			expect(text).toBe(''); 
		 });
	};

  	this.verifyTextOfFirstRowUpdatedBy=function(updateBy){	

		 element(firstRowUpdatedBy).getText().then(function (text) {
			console.log('UpdatedBy='+text);
			expect(text).toBe(updateBy.toLowerCase()); 
		 });
	};

	this.getTextOfFirstRowUpdatedOn=function(){	

		 element(firstRowUpdatedOn).getText().then(function (text) {
			console.log('UpdatedOn'+text);
			expect(text).toBe(''); 
		 });
	};
	

	this.selectFirstRecordwithCheckbox=function(){
		element(selectFirstRecordwithCheckbox).click();
		browser.sleep(5000).then(function(){console.log("Selected first record with checkbox")});			
	};

    this.selectAllRecordwithCheckbox=function(){
        element(selectAllRecordsOnPage).click();
        browser.sleep(5000).then(function(){console.log("Selected first record with checkbox")});
    };

	this.selectMultipleRecordsWithCheckBox=function(){
		var count=0;
		for(i=1;i<4;i++){
              element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input')).click();
			  browser.sleep(3000).then(function(){console.log("Selected first 3 record with checkbox")});
			  count++;
		}
		expect(count>1).toBe(true);
	};
	
};
module.exports=new eventMgmt_page();