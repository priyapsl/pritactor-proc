require('../eventMgmtPOM/eventMgmtPageObject.js');

var edit_EventMgmt_page=function(){
	



			var edit_IssuerDrpDwn=by.css('update-event-config .form-group .row:nth-child(1) .col-sm-3:nth-child(1) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
			var edit_Application=by.css('update-event-config .form-group .row:nth-child(1) .col-sm-3:nth-child(2) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
			var edit_version=by.css('update-event-config .form-group .row:nth-child(1) .col-sm-2:nth-child(3) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
            var edit_EventName=by.css('update-event-config .form-group .row:nth-child(1) .col-sm-4:nth-child(4) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
            

	        var edit_SeverityDrpdwn=by.css('update-event-config .form-group .row:nth-child(3) .col-sm-3:nth-child(1) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
            var edit_ChannelDrpdwn=by.css('update-event-config .form-group .row:nth-child(3) .col-sm-3:nth-child(2) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
            var edit_ReminderFreq=by.css('update-event-config .form-group .row:nth-child(3) .col-sm-3:nth-child(3) .form-control.ng-untouched.ng-pristine.ng-valid');
            var edit_ReminderFreqUnit=by.css('update-event-config .form-group .row:nth-child(3) .col-sm-3:nth-child(4) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
            var edit_EventType=by.css('update-event-config .form-group .row:nth-child(5)  .col-sm-3:nth-child(1) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
            var edit_UsersDrpDwn=by.css('update-event-config .row.user-recipient .col-sm-6.pr-4 .caret.pull-right');
            var edit_GroupsDrpDwn=by.css('update-event-config .row.user-recipient  .col-sm-6.left-border.pl-4 .btn.btn-default.btn-secondary.form-control.ui-select-toggle');

			var edit_ProductCodeErrorMsg=by.css('edit-product .col-sm-3.has-error:nth-child(1) .error-msg>span:nth-child(2)');			
			var edit_DescriptionErrorMsg=by.css('edit-product .col-sm-3.has-error:nth-child(2) .error-msg>span:nth-child(2)');
			
            var save_Button=by.buttonText('Save');
	        var cancel_Button=by.css('#event_edit_cancel_button');
			var flag=false;
            






			
			

			 this.editIssuerDrpdwnIsPresent=function(){
				element.all(edit_IssuerDrpDwn).then(function(items) {
				expect(items.length).toBe(1);
				console.log('edit_IssuerDrpDwn is present');
				});
			};

			this.clickOnIssuerDrpDwn=function(){
				element(edit_IssuerDrpDwn).click();
			};

			this.editApplicationDrpdwnIsPresent=function(){
				element.all(edit_Application).then(function(items) {
					expect(items.length).toBe(1);
					console.log('edit_Application is present');
				});
			};

			this.clickOnApplicationDrpDwn=function(){
				element(edit_Application).click();
			};

			this.editVersionDrpdwnIsPresent=function(){
				element.all(edit_version).then(function(items) {
					expect(items.length).toBe(1);
					console.log('edit_version is present');
				});
			};


			this.clickOnVersionDrpDwn=function(){
				element(edit_version).click();
			};


			this.editEventNameDrpdwnIsPresent=function(){
				element.all(edit_EventName).then(function(items) {
					expect(items.length).toBe(1);
					console.log('edit_EventName is present');
				});
			};


			this.clickOnEventNameDrpDwn=function(){
				element(edit_EventName).click();
			};

			this.editSeverityDrpdwnIsPresent=function(){
				element.all(edit_SeverityDrpdwn).then(function(items) {
					expect(items.length).toBe(1);
					console.log('edit_SeverityDrpdwn is present');
				});
			};

			this.clickOnSeverityDrpDwn=function(){
				element(edit_SeverityDrpdwn).click();
			};

			this.editChannelDrpdwnIsPresent=function(){
				element.all(edit_ChannelDrpdwn).then(function(items) {
					expect(items.length).toBe(1);
					console.log('edit_ChannelDrpdwn is present');
				});
			};

			this.clickOnChannelDrpDwn=function(){
				element(edit_ChannelDrpdwn).click();
			};

			this.editReminderFreqInputIsPresent=function(){
				element.all(edit_ReminderFreq).then(function(items) {
					expect(items.length).toBe(1);
					console.log('edit_ReminderFreq is present');
				});
			};

			this.enterTextInReminderFrequency=function(reminderFreq){
				element(edit_ReminderFreq).sendKeys(reminderFreq);
			};



				this.editRemidnerFreqUnitDrpdwnIsPresent=function(){
					element.all(edit_ReminderFreqUnit).then(function(items) {
						expect(items.length).toBe(1);
						console.log('edit_ReminderFreqUnit is present');
					});
				};

				this.clickOnFreqUnitDrpdwn=function(){
					element(edit_ReminderFreqUnit).click();
				};

				this.editEventTypeDrpdwnIsPresent=function(){
					element.all(edit_EventType).then(function(items) {
						expect(items.length).toBe(1);
						console.log('edit_EventType is present');
					});
				};


				this.clickOnEditEventTypeDrpdwn=function(){
					element(edit_EventType).click();
				};


				this.editUsersDrpdwnIsPresent=function(){
					element.all(edit_UsersDrpDwn).then(function(items) {
						expect(items.length).toBe(1);
						console.log('edit_UsersDrpDwn is present');
					});
				};

				this.clickOnEditUsersDrpdwn=function(){
					element(edit_UsersDrpDwn).click();
				};

				this.editGroupsDrpdwnIsPresent=function(){
					element.all(edit_GroupsDrpDwn).then(function(items) {
						expect(items.length).toBe(1);
						console.log('edit_GroupsDrpDwn is present');
					});
				};

				this.clickOnGroupsDrpdwn=function(){
					element(edit_GroupsDrpDwn).click();
				};

			  this.selectParticularFromDrpdwn=function(data){
							 element(by.cssContainingText('.dropdown-item>div', data)).click();
                  browser.sleep(5000).then(function () {console.log("Selected  Event type from Drpdwn")});

				};


             

			
			



			



				

			
			this.clickOnSave1Button=function(){
				element(save_Button).click();
				return require('./eventMgmtPageObject.js');
			};

            this.clickOnClearSaveButton=function(){
				element(save_Button).click();
				//return require('./produtcsPageObject.js');
			};
			
			
			this.clickOnCancelButton=function(){
			    element(cancel_Button).click();
				return require('./eventMgmtPageObject.js');
			};
            




};
module.exports=new edit_EventMgmt_page();