require('../eventMgmtPOM/eventMgmtPageObject.js');

var create_EventMgmt_page=function(){


			var create_Issuer_DrpDown=by.css('create-event-config .row:nth-child(1) .col-sm-3:nth-child(1) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
			var create_Drpdwn_InputBox=by.css('.form-control.ui-select-search');

			var create_Application_Drpdwn=by.css('create-event-config .row:nth-child(1) .col-sm-3:nth-child(2) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
            var create_Version_Drpdwn=by.css('create-event-config .row:nth-child(1) .col-sm-2 .btn.btn-default.btn-secondary.form-control.ui-select-toggle');

            var create_EventNameDrpdwn=by.css('create-event-config .row:nth-child(1) .col-sm-4 .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
            var create_SeverityDrpdwn=by.css('create-event-config .row:nth-child(3) .col-sm-3:nth-child(1) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
            var create_ChannelDrpdwn=by.css('create-event-config .row:nth-child(3) .col-sm-3:nth-child(2) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');

		    var reminderFrequency=by.css('#event_create_frequency');
		    var reminderFrequencyUnitDrpdwn=By.css('create-event-config .row:nth-child(3) .col-sm-3:nth-child(4) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');


		    var create_EventTypeDrpdwn=by.css('create-event-config .row:nth-child(5) .col-sm-3 .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
            var create_UsersDrpdwn=by.css('.user-recipient .col-sm-6.pr-4 .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
            var create_GroupsDrpdwn=by.css('.user-recipient .left-border.pl-4 .btn.btn-default.btn-secondary.form-control.ui-select-toggle');

            		
			var create_Save_button=by.buttonText('Save');
			var create_Cancel_button=by.css('#event_create_cancel_button');
			  
			 

			 var issuerStar=by.css('.col-md-2:nth-child(3) .required-icon');
           


		   var missingIssuerErrorMsg=by.css('.col-md-2:nth-child(3) .error-msg>span:nth-child(2)');

          
			var create_CancelPopUpOKBtn=by.css('#canceldialog_ok_button');
			var cancelPopUpMessage=by.css('cancel-dialog .modal-body>p');
			var create_CancelPopUpCancelBtn=by.css('#canceldialog_cancel_button');
			var firstElementFromDropDown=by.css('.ui-select-choices li:nth-child(1) a div');
 
    
			var flag=false;



			
   
            
			
			


					 this.createIssuerDrpDwnIsPresent=function(){
						element.all(create_Issuer_DrpDown).then(function(items) {
						expect(items.length).toBe(1);
						console.log('create_Issuer_DrpDown is present');
						});
					};

					this.createApplicationDrpDwnIsPresent=function(){
						element.all(create_Application_Drpdwn).then(function(items) {
							expect(items.length).toBe(1);
							console.log('create_Application_Drpdwn is present');
						});
					};

					this.createVersionDrpDwnIsPresent=function(){
						element.all(create_Version_Drpdwn).then(function(items) {
							expect(items.length).toBe(1);
							console.log('create_Version_Drpdwn is present');
						});
					};

					this.createEventNameDrpDwnIsPresent=function(){
						element.all(create_EventNameDrpdwn).then(function(items) {
							expect(items.length).toBe(1);
							console.log('create_EventNameDrpdwn is present');
						});
					};

					this.createSeverityDrpDwnIsPresent=function(){
						element.all(create_SeverityDrpdwn).then(function(items) {
							expect(items.length).toBe(1);
							console.log('create_SeverityDrpdwn is present');
						});
					};

					this.createChannelDrpDwnIsPresent=function(){
						element.all(create_ChannelDrpdwn).then(function(items) {
							expect(items.length).toBe(1);
							console.log('create_ChannelDrpdwn is present');
						});
					};

					this.createReminderFrequencyIsPresent=function(){
						element.all(reminderFrequency).then(function(items) {
							expect(items.length).toBe(1);
							console.log('reminderFrequency is present');
						});
					};

					this.reminderFrequencyUnitDrpDwnIsPresent=function(){
						element.all(reminderFrequencyUnitDrpdwn).then(function(items) {
							expect(items.length).toBe(1);
							console.log('reminderFrequencyUnitDrpdwn is present');
						});
					};

					this.eventTypDrpDwnIsPresent=function(){
						element.all(create_EventTypeDrpdwn).then(function(items) {
							expect(items.length).toBe(1);
							console.log('create_EventTypeDrpdwn is present');
						});
					};

					this.usersDrpDwnIsPresent=function(){
						element.all(create_UsersDrpdwn).then(function(items) {
							expect(items.length).toBe(1);
							console.log('create_UsersDrpdwn is present');
						});
					};


					this.groupsDrpDwnIsPresent=function(){
						element.all(create_GroupsDrpdwn).then(function(items) {
							expect(items.length).toBe(1);
							console.log('create_GroupsDrpdwn is present');
						});
					};











    this.createCancelButtonIsPresent=function(){
				element.all(create_Cancel_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Cancel_button is present');				
				});  
			};
			
			
			this.creatBranchSaveButtonIsPresent=function(){			
				element.all(create_Save_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Save_button is present');				
				});  
			};



			this.issuerStarIsPresent=function(){			
				element.all(issuerStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('issuerStar is present');				
				});  
			};

			
			this.verifyTextOfErrorMessage=function(actualErrorMessage){
               element(create_ErrorMessageForDuplicateSubCode).getText().then(function (errorMessage) {
				   expect(errorMessage).toContain(actualErrorMessage);
				   console.log('error message='+errorMessage);
			   });
			};

		
			

            this.eneterTextInInputBox=function(enterData)
				{
					element(create_Drpdwn_InputBox).sendKeys(enterData);
				};

			 


            

			
			

					this.clickOnIssuerDrpDwn=function(){

					   element(create_Issuer_DrpDown).click();
					};

					this.clickOnApplicationDrpDwn=function(){

						element(create_Application_Drpdwn).click();
					};

					this.clickOnVersionDrpDwn=function(){

						element(create_Version_Drpdwn).click();
					};

					this.clickOnEventNameDrpDwn=function(){

						element(create_EventNameDrpdwn).click();
					};

					this.clickOnSeverityDrpDwn=function(){

						element(create_SeverityDrpdwn).click();
					};

					this.clickOnChannelDrpDwn=function(){

						element(create_ChannelDrpdwn).click();
					};

					this.enterTextInReminderFrequency=function(remFrequency){

						element(reminderFrequency).sendKeys(remFrequency);
					};

					this.clickOnReminderFreqUnitrDrpDwn=function(){

						element(reminderFrequencyUnitDrpdwn).click();
					};

					this.clickOnEventTypeDrpDwn=function(){

						element(create_EventTypeDrpdwn).click();
					};

					this.clickOnUsersDrpDwn=function(){

						element(create_UsersDrpdwn).click();
					};

					this.clickOnGroupsDrpDwn=function(){

						element(create_GroupsDrpdwn).click();
					};







				this.clickOnSaveButton=function(){
							element(create_Save_button).click();
							return require('./eventMgmtPageObject.js');
				};

				this.clickOnClearSaveButton=function(){
					element(create_Save_button).click();

				};

			this.selectParticularFromDropDown=function(data){
						 element(by.cssContainingText('.dropdown-item>div', data)).click();
                browser.sleep(5000).then(function(){console.log("sLEEP AFTER SELECTING FROM DROPDWN")});
			};

		
				
			
			this.clickOnCancelButton=function(){
			    element(create_Cancel_button).click();
				
			};
			this.clickOnBlankCancelButton=function(){
				element(create_Cancel_button).click();
                return require('./eventMgmtPageObject.js');
			};

			this.clickOnCanacelPopUpOk=function(){
                element(create_CancelPopUpOKBtn).click();
				return require('./eventMgmtPageObject.js');
			};

			this.clickOnCanacelPopUpCancel=function(){
                element(create_CancelPopUpCancelBtn).click();
				return require('./eventMgmtPageObject.js');
			};

			this.selectFirstElementFromDropDown=function(){		
				element(firstElementFromDropDown).click();
			};




		  this.verifyMissingIssuerErrorMessage=function(errorMsg){
              element(missingIssuerErrorMsg).getText().then(function (text) {
				  expect(text).toBe(errorMsg);
			  })
			};
           


		   	


		  
		  
};
module.exports=new create_EventMgmt_page();