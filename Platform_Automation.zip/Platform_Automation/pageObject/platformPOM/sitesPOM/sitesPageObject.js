require('../sitesPOM/createSitesPageObject.js');
require('../sitesPOM/editSitesPageObject.js');	
require('../sitesPOM/detailsSitesPageObject.js');
require('../subsidaryPOM/subsidaryPageObject.js');

var sites_page=function(){
	//Subsidary Page Button
	var sitesText=by.css('.header-title>h5');
	var sitesFilterButton=by.css('#site_filters_button');
	var sitesCloseFilterPane=by.css('.fa.fa-times.close-icon');
	//ar filter_CloseIcon=by.css('i.fa.fa-times.close-icon');
    var sitesDeleteButton=by.css('#site_delete_button');
	var sitescreateButton=by.css('#site_create_button');
	var sitesclearButton=by.css('#site_filter_clear_button');
	var sitesapplyButton=by.css('#site_filter_apply_button');
	var sitesDelete_Yes_button=by.buttonText('Yes');
	var sitesDelete_No_button=by.buttonText('No');
	var sitesDelete_PopupMessage=by.css('.modal-body>p');
	var sitesDelet_PopUpCloseIcon=by.css('.modal-dialog .confirm-close-icon');
	
	
	//Subsidary Grid table Element
	var checkBoxToSelectAll=by.css('.table-responsive thead tr th:nth-child(1) input');
	var product_code=by.css('product-listing .table-responsive thead tr th:nth-child(2)');
	var prod_Description=by.css('product-listing .table-responsive thead tr th:nth-child(3)');
	var prod_Issuer=by.css('product-listing .table-responsive thead tr th:nth-child(4)');
	var valid_from=by.css('product-listing .table-responsive thead tr th:nth-child(5)');	
	var valid_To=by.css('product-listing .table-responsive thead tr th:nth-child(6)');	
	var updatedBy=by.css('product-listing .table-responsive thead tr th:nth-child(7)');
	var updatedOn=by.css('product-listing .table-responsive thead tr th:nth-child(8)');
	var editIconForEachSite=by.css('.table-responsive>table>tbody>tr>td:nth-child(9)');
	var firstRowEditButton= by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(9)');
	var selectFirstRecordwithCheckbox=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(1) input');
	
	//Site Sorting
	var sort_site_header = element(by.cssContainingText('.pull-left.th-tittle', 'Site'));
	var sort_subsidiaryCode_header = element(by.cssContainingText('.pull-left.th-tittle', 'Subsidiary Code'));
	var sort_description_header = element(by.cssContainingText('.pull-left.th-tittle', 'Description'));
	var sort_validFrom_header = element(by.cssContainingText('.pull-left.th-tittle', 'Valid From'));
	var sort_validTo_header = element(by.cssContainingText('.pull-left.th-tittle', 'Valid To'));
	var sort_updatedBy_header = element(by.cssContainingText('.pull-left.th-tittle', 'Updated By'));
	var sort_updatedOn_header = element(by.cssContainingText('.pull-left.th-tittle', 'Updated On'));

	//filter pane elements
	//var filter_SubsidaryCode_drpdwn=by.css('span.btn.btn-default.btn-secondary.form-control.ui-select-toggle'));
	var filter_SubsidiaryCode_drpdwn=by.css('.btn.btn-default.btn-secondary.form-control.ui-select-toggle');
	var filter_SubsidiaryCode_inputBox=by.css('.form-control.ui-select-search');
	var filter_SubsidiaryCodeList=by.css('.dropdown-item>div');
	var filter_ProductsCodeList=by.css('.dropdown-item>div');
	var filter_Site_InputBox=by.css('#site');
	var filter_Description_InputBox=by.css('#description');
	//var filter_Issuer_drpdwn=by.css('.col-sm-3:nth-child(3) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
	var filter_Issuer_inputBox=by.css('input.form-control.ui-select-search');
	var filter_Clear_Button=by.css('#site_filter_clear_button');
	var filter_Apply_Button=by.css('#site_filter_apply_button');
	var filter_CloseIcon=by.css('i.fa.fa-times.close-icon');
	var firstElementFromDropDown=by.css('.ui-select-choices li:nth-child(1)');
	//var secondElementFromDropDown=by.css('.ui-select-choices li:nth-child(2)');
	//Table Element
	var firstRowFromTable=by.css('fng-table table tbody tr:nth-child(1)');
	var allRowsFromTable=by.css('fng-table table tbody tr');
	var nextSingleArrowOfPagination=by.css('[ng-reflect-inner-h-t-m-l="&#8250;"]');
	var firstRowEditButton= by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(9) button i');
	var firstRowSubsidiaryCode=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(2) div');	
	var firstRowDescription=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(4) div');	
	var selectFirstRecordwithCheckbox=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(1) input');
	
	var editIconForEachProduct=by.css('.table-responsive>table>tbody>tr>td:nth-child(9) button');
	var flag=false;
	
	// Sorting based on Site
	this.clickSortingForSite=function(){	
		element(sort_site_header).click();
	};

	// Sorting based on Subsidiary
	this.clickSortingForSubsidiary=function(){	
		element(sort_subsidiaryCode_header).click();
	};

	// Sorting based on Description
	this.clickSortingForDescription=function(){	
		element(sort_description_header).click();
	};

	// Sorting based on Valid From
	this.clickSortingForValidFrom=function(){	
		element(sort_validFrom_header).click();
	};

	// Sorting based on Valid From
	this.clickSortingForValidTo=function(){	
		element(sort_validTo_header).click();
	};

	// Click Close Subsidiary Code List
	this.clickSubsidiaryCodeList=function(){	
		element(filter_SubsidiaryCodeList).click();
	};

	this.checksizeofSubsidiaryCodeList=function(){	
		//element(filter_SubsidiaryCodeList).click();
		element.all(filter_SubsidiaryCodeList).then(function(items) {
		expect(items.length).toBe(111);
		console.log('size of Subsidiary Code List : '+items.length);
				
		});	
	};
	// Click Close Filter Pane
	this.closeFilterPane=function(){	
		element(sitesCloseFilterPane).click();
	};
	//Sites Page Button Disabled
	this.checkSitesClearBtnDisabled=function(){	
			status = true;
		expect(status).toBe(true);
	};
	

	//Sites Page Button Present
	this.sitesTextIsPresent=function(){		
		 /**element.all(sitesText).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('sites Text is present');				
		});		
		**/
		expect(sitesText.isPresent()).toBe(true);
			
	};
	
	this.sitesfilterButtonIsPresent=function(){		
		element.all(sitesFilterButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('Sites Filter Button is present');				
		});	
	};
	
	this.sitesDeleteButtonIsPresent=function(){		
		element.all(sitesDeleteButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('Sites Delete Button is present');				
		});
	};
	
	this.sitesDeleteButtonIsEnabled=function(){
		if(element(sitesDeleteButton).isEnabled()){
			console.log('Sites Delete button is enabled');
			flag=true;
		}
		return flag;
	};
	
	this.sitesCreateButtonIsPresent=function(){		
		element.all(sitescreateButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('Sites Create Button is present');				
		});
		
	};
	
	//Subsidary Grid Element Present or Not
	this.checkBoxToSelectAllIsPresent=function(){		
       element.all(checkBoxToSelectAll).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('checkBox To Select All element on Page is present');				
		});		
	};
	
	this.clickOnCheckBoxToSelectAllSitesOnPage=function(){
		element(checkBoxToSelectAll).click();
				
	};
	
	this.productCodeIsPresent=function(){		
        element.all(product_code).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('product_code is present');				
		});				
	};
	
	
	this.sites_DescriptionIsPresent=function(){		
        element.all(sites_Description).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('sites_Description is present');				
		});			
	};

	this.sites_IssuerIsPresent=function(){		
        element.all(sites_Issuer).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('sites_Issuer is present');				
		});			
	};
	
	this.valid_fromIsPresent=function(){	
        element.all(valid_from).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('valid_from is present');				
		});			
	};
	
	this.valid_ToIsPresent=function(){			
        element.all(valid_To).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('valid_To is present');				
		});			
	};
	
	this.updatedByIsPresent=function(){		
        element.all(updatedBy).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('updatedBy is present');				
		});			
	};
	
	this.updatedOnIsPresent=function(){		
        element.all(updatedOn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('updatedOn is present');				
		});			
	};
	
	
	//Click On Filter,Delete,Create Button of Subsidary
	this.clickOnSitesFilterButton=function(){
		element(sitesFilterButton).click();		
	};
	
	this.clickOnSitesDeleteButton=function(){
		element(sitesDeleteButton).click();		
	};
	
	this.clickOnSitesCreateButton=function(){
		element(sitescreateButton).click();
        return require('../sitesPOM/createSitesPageObject.js');		
	};
	
		this.clickOnSubsidiaryNavLink=function(){
		element(by.cssContainingText('.section>a>h3>span', 'Subsidiaries')).click();
        return require('../subsidaryPOM/subsidaryPageObject.js');		
	};
	

	this.clickOnSitesDeleteYesButton=function(){
		element(sitesDelete_Yes_button).click();
		console.log('Record Deleted Successfully');
	}
	
	this.clickOnSitesDeleteNoButton=function(){
		element(sitesDelete_No_button).click();
	}
	
    this.closeIconOfPopUpIsPresent=function(){		
        element.all(sitesDelet_PopUpCloseIcon).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('delet_PopUpCloseIcon is present');				
		});      		
	};

    this.clickOnCloseIconOfPopUp=function(){
			element(sitesDelet_PopUpCloseIcon).click();
	};

	this.getTextOfDeletePopup=function(){
		element.all(prodDelete_PopupMessage).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);					  
						itemList[0].getText().then(function(text) {								         
								console.log('Message='+text);
								expect(text).toBe("Are you sure you want to delete the selected records?");		
							 
						});					
			});	
     }
	 
	 this.getTextOfDeletePopupForEntirePage=function(){
		element.all(prodDelete_PopupMessage).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);					  
						itemList[1].getText().then(function(text) {								         
								console.log('Message='+text);
								expect(text).toContain("Records selected");		
							 
						});					
			});	
     }
	 
	//Filter Pane element present verification
	this.filter_SubsidiaryCode_drpdwnIsPresent=function(){		
        element.all(filter_SubsidiaryCode_drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_SubsidiaryCode_drpdwn is present');				
		});    	
		
	};
	
	this.filter_DescriptionInputBoxIsPresent=function(){		
        element.all(filter_Description_InputBox).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Description_InputBox is present');				
		});    			
	};
	
	this.filter_SiteInputBoxIsPresent=function(){		
        element.all(filter_Site_InputBox).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Site_InputBox is present');				
		});    	
		
	};
	
	this.filter_Clear_ButtonIsPresent=function(){		
       element.all(filter_Clear_Button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Clear_Button is present');				
		});   		
	};
	
	this.filter_Clear_ButtonIsNotPresent=function(){		
       element(filter_Clear_Button).getText().then(function(items) {
				expect(items).toBe('');				
				console.log('filter_Clear_Button is not present');				
		});   		
	};

	this.filter_Apply_ButtonIsPresent=function(){		
       element.all(filter_Apply_Button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Apply_Button is present');			
		});  		
	};
	
	this.filter_Apply_ButtonIsNotPresent=function(){		
       element(filter_Apply_Button).getText().then(function(items) {
				expect(items).toBe('');				
				console.log('filter_Apply_Button is not present');				
		});  		
	};
	this.filter_CloseIconIsPresent=function(){		
        element.all(filter_CloseIcon).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_CloseIcon is present');				
		});  		
	};
	
	
	this.clickfilter_CloseIcon=function(){
			element(filter_CloseIcon).click();	
			console.log('Clicked on close icon of Filter Pane');
	};
	
	this.clickOnSubsidiaryLink=function(){		
		element(filter_SubsidiaryCode_drpdwn).click();
	};
	
	this.clickOnFilterSubsidiaryCodeDrpdwn=function(){		
		element(filter_SubsidiaryCode_drpdwn).click();
	};

	this.clickOnFilterSubsidiaryInputBox=function(){		
		element(filter_SubsidiaryCode_inputBox).click();
	};

	this.clickOnFilterIssuerCodeDrpdwn=function(){		
		element(filter_Issuer_drpdwn).click();
	};
	
	this.enterTextInFilterSubsidaryCodeInputBox=function(subsidiaryCode){
           element(filter_SubsidiaryCode_inputBox).sendKeys(subsidiaryCode);
	};

	this.enterTextInSiteInputBox=function(site){
           element(filter_Site_InputBox).sendKeys(site);
	};

	this.enterTextInDescriptionInputBox=function(description){
           element(filter_Description_InputBox).sendKeys(description);
	};

	this.getTextOfFilterSubsidaryCodeDrpdown=function(){
		element(filter_SubsidiaryCode_inputBox).getText().then(function (text) {
			expect(text).toBe("");
			console.log('TextOfFilterSubsidaryCodeDrpdown='+text.length);
		});
	};

   this.getTextOfFilterDescription=function(){
      element(filter_Description).getText().then(function (text) {
		  expect(text).toBe("");
		  console.log('filter_Description text length='+text.length);
	  });   
   };
 
   this.getTextOfFilterIssuerCodeDrpdown=function(){
		element(filter_Issuer_inputBox).getText().then(function (text) {
			expect(text).toBe("");
			console.log('TextOfFilterIssuer Drpdown='+text.length);
		});
	};

	this.selectParticularSubCode=function(subsidaryCode){
		element(by.cssContainingText('.dropdown-item>div', subsidaryCode)).click();
	};
	
	this.isParticularSubCodePresentInDropDown=function(subCode){
		
			element.all(filter_SubsidiaryCodeList).then(function(itemList) {
					  var flag1=false;
				browser.sleep(5000).then(function(){console.log("--isParticularSubCodePresentInDropDown--")});	
				console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						  var count=0;
						itemList[i].getText().then(function(text) {
						  
							  if (text == subCode) {
								count++;
								expect(text).toEqual(subCode);
								//break;
							  } 
							 
						});
					 };
				
			});
		
	};
	
	this.isParticularProductCodeNotPresntDropDown=function(subsidiaryCode){
		  element.all(by.cssContainingText('.dropdown-item>div', subsidiaryCode)).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('SubCode is not present='+items.length);				
		});  	
	};

	this.firstElementFromDropDownIsPresent=function(){		
		 element.all(firstElementFromDropDown).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('firstElementFromDropDown is present');
				
		});		
	};
	
	this.selectParticularSubCode=function(subsidaryCode){
		element(by.cssContainingText('.dropdown-item>div', subsidaryCode)).click();
	};
	
	this.isParticularSubCodeNotPresntDropDown=function(subsidaryCode){

		  element.all(by.cssContainingText('.dropdown-item>div', subsidaryCode)).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('SubCode is not present='+items.length);				
		});  	
	};

	this.selectFirstElementFromDropDown=function(){		
		element(firstElementFromDropDown).click();
	};
	
	this.clickOnFilterApplyButton=function(){
		element(filter_Apply_Button).click();
	};
	
	this.clickOnFilterClearButton=function(){
		element(filter_Clear_Button).click();
	};
	
	//Table element
	this.firstRowFromTableIsPresent= function(){
	   element.all(firstRowFromTable).then(function(items) {
		   if(items.length > 0 ){			
				console.log('Checking Table - firstRowFromTable is present');	
		   }
			else
				{
				console.log('Checking Table - firstRowFromTable is NOT present');		
				}	
			expect(items.length).toBe(1);			
		});		
		
	};

	this.firstRowFromTableNotPresent=function(){
		element.all(allRowsFromTable).then(function(items) {
				expect(items.length).toBe(0);
				if(items.length ==0){
				console.log('Checking Data in Table --'+items.length+' elements are not present');
				}
				else{
				console.log('Checking Data in Table --'+items.length+' elements are present');
			}
		});		
	};
	
	this.eneterTextInDescriptionBox=function(descriptionText)
	{
		element(filter_Description).sendKeys(descriptionText);
	};
	
	
	
	//To read the data of particular column
	this.getDataOfFirstRowParticularColumn=function(columnNo,data){
		
			  element(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).getText().then(function(text){
				  console.log('Data of First Row Particular Column='+text);
				  expect(text).toBe(data);
				  
			  });

				 // console.log(text);         	
	};
	
	this.dataForParticularColumnIsPresent=function(columnNo){
		
			/*  if(element(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).isPresent()){
				  flag=true;
			  }
				return flag;*/

			element.all(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).then(function(items) {
				var flag=false;
				if(items.length>0){
					flag=true;
				}
				expect(flag).toBe(true);
				console.log('item in ='+items.length);				
		   });	
	};
	
	this.checkEditButtonForEachProduct=function(){				 
					
            element.all(editIconForEachProduct).then(function(items) {				
				expect(items.length).toBe(10);
				console.log('item in ='+items.length);				
		   });

	};
	
	this.checkMultipleRecordsWithCheckBox=function(){
                           var count=0;		
							for(var i=1;i<4;i++){							  
										 if(element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input[type="checkbox"]')).isPresent()){
											 element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input[type="checkbox"]')).click();
												count++;
												console.log('j='+i);												
										 }										 												
							 } 	
							 
							 if(count>1){
								 flag=true;
								 console.log('Count Of check box='+count);
							 }
		       return flag;
	};
	nextSingleArrowOfPaginationIsEnabled= function(){
		if(element(nextSingleArrowOfPagination).isEnabled()){
			flag=true;
		}
		return flag;
	};
	
	clickOnNextSingleArrowOfPagination= function(){
		element(nextSingleArrowOfPagination).click();
		
	};

	this.clickOnfirstRowSubsidaryCode=function(){
		 element(firstRowSubsidiaryCode).click();
		 return require('./detailsSitesPageObject.js');	
	};

	this.clickOnFirstRowsEditButton=function(){
		 element(firstRowEditButton).click();
		 return require('./editSitesPageObject.js');	
	};
	
	this.clickOnfirstRowProductCode=function(){
		 element(firstRowProductCode).click();
		 return require('./detailsSubsidaryPageObject.js');	
	};

	this.getTextOfFirstRowProductCode=function(prodCode){		
		
		 element(firstRowProductCode).getText().then(function (text) {
			console.log('firstRowProductCode'+text);
			expect(text).toContain(prodCode); 
		 });
	};
	
	this.getTextOfFirstRowDescription=function(description){	

		 element(firstRowDescription).getText().then(function (text) {
			console.log('firstRowDescription'+text);
			expect(text).toContain(description); 
		 });
	};
	

	this.selectFirstRecordwithCheckbox=function(){
		element(selectFirstRecordwithCheckbox).click();
		
	};
	this.SelectSubCodeFromDropDownByEnter=function(){		
			var enter = browser.actions().sendKeys(protractor.Key.ENTER);
			enter.perform();
			};
};
module.exports=new sites_page();