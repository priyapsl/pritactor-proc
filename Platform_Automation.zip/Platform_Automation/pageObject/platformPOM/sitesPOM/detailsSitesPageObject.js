require('../sitesPOM/sitesPageObject.js');
require('../sitesPOM/editSitesPageObject.js');

var details_sites_page=function(){
	
            var details_Subsidary_Edit_button=by.buttonText('Edit');
			var details_Subsidary_Back_button=by.buttonText('Cancel');
			var details_subsidaryCode_data=by.css('.form-group .row:nth-child(1) .col-sm-2:nth-child(1) div');
			var details_Sites_data=by.css('.form-group .row:nth-child(1) .col-sm-2:nth-child(2) div');
			var details_Sites_Description_data=by.css('.form-group .row:nth-child(1) .col-sm-2:nth-child(3) div');
			var flag=false;
			
			
			this.clickOnDetailsEditButton=function(){
				element(details_Subsidary_Edit_button).click();
				 return require('./editSitesPageObject.js');
			};
			
			this.clickOnDetailsBackButton=function(){
			    element(details_Subsidary_Back_button).click();
				return require('./sitesPageObject.js');
			};
           
		   this.verifyTextOfSubsidaryCode=function(subsidaryCode){
               element(details_subsidaryCode_data).getText().then(function (data) {
				   expect(data).toBe(subsidaryCode);
				   console.log('View Details Page subsidary code='+data);
			   });
		   };

		   this.verifyTextOfSitesSites=function(subsidaryCode){
               element(details_Sites_data).getText().then(function (data) {
				   expect(data).toBe(subsidaryCode);
				   console.log('View Details Page Sites Data='+data);
			   });
		   };

           this.verifyTextOfSitesDescription=function(description){
               element(details_Sites_Description_data).getText().then(function (data) {
				   expect(data).toBe(description);
				   console.log('View Details Page Description Data='+data);
			   });
		   };

};
module.exports=new details_sites_page();
