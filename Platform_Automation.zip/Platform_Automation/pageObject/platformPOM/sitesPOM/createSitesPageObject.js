require('../sitesPOM/sitesPageObject.js');


var create_sites_page=function(){
			var create_Subsidiary_code_inputbox=by.css('.form-control.ui-select-search');
			var create_Subsidiary_code_dropdown=by.css('.btn.btn-default.btn-secondary.form-control.ui-select-toggle');
			var create_Site_Site=by.css('#site');
			var create_Site_Description=by.css('#description');
			var create_Site_ValidFrom=by.css('#validfrom');
			var create_Site_ValidTo=by.css('#validto');
			var create_Site_Save_button=by.css('#site_create_save_button');
			var create_Site_Cancel_button=by.css('#site_create_cancel_button');
			var create_ErrorMessageForDuplicateSubCode=by.css('.server-error>span:nth-child(2)');
			var create_CancelPopUpOKBtn=by.css('#canceldialog_ok_button');
			var create_CancelPopUpCancelBtn=by.css('#canceldialog_cancel_button');
			var firstElementFromDropDown=by.css('.ui-select-choices li:nth-child(1) a');
			var mandatoryerrormsg_subcode=by.cssContainingText('.error-msg>span:nth-child(2)','Please provide value for Subsidiary Code');
			var mandatoryerrormsg_site=by.cssContainingText('.error-msg>span:nth-child(2)','Please provide value for Site');
			var mandatoryerrormsg_description=by.cssContainingText('.error-msg>span:nth-child(2)','Please provide value for Description');
			var mandatoryerrormsg_fromDate=by.cssContainingText('.error-msg>span:nth-child(2)','Please provide value for Valid From Date');
			var mandatoryerrormsg_toDate=by.cssContainingText('.error-msg>span:nth-child(2)','Please provide value for Valid To Date');
	
			var flag=false;

			 this.mandatoryerrormsg_subcode_isPresent=function(actualErrorMessage){	

				element(mandatoryerrormsg_subcode).getText().then(function(errmessage) {
				expect(errmessage).toContain(actualErrorMessage);	
				console.log('error message='+errmessage);			
							
				});  
			};
   
			this.mandatoryerrormsg_site_isPresent=function(actualErrorMessage){				
				element(mandatoryerrormsg_site).getText().then(function(errmessage) {
				expect(errmessage).toContain(actualErrorMessage);	
				console.log('error message='+errmessage);			
				});
			};

			this.mandatoryerrormsg_description_isPresent=function(actualErrorMessage){				
				element(mandatoryerrormsg_description).getText().then(function(errmessage) {
				expect(errmessage).toContain(actualErrorMessage);	
				console.log('error message='+errmessage);			
				});
			};

			this.mandatoryerrormsg_fromDate_isPresent=function(actualErrorMessage){				
				element(mandatoryerrormsg_fromDate).getText().then(function(errmessage) {
				expect(errmessage).toContain(actualErrorMessage);	
				console.log('error message='+errmessage);			
				});
			};

			this.mandatoryerrormsg_toDate_isPresent=function(actualErrorMessage){				
			element(mandatoryerrormsg_toDate).getText().then(function(errmessage) {
				expect(errmessage).toContain(actualErrorMessage);	
				console.log('error message='+errmessage);			
				});
			};

            this.createSubsidaryCodeIsPresent=function(){				
				element.all(create_Subsidiary_code_dropdown).then(function(items) {
				expect(items.length).toBe(1);				
				if(items.length > 0 ){
				console.log('create_Subsidiary_code_dropdown is Present');				
				}	
			  else	{
				console.log('create_Subsidiary_code_dropdown is NOT Present');
			   }				
				});  
			};
   
			 this.createSiteIsPresent=function(){				
				element.all(create_Site_Site).then(function(items) {
				expect(items.length).toBe(1);				
				if(items.length > 0 ){
				console.log('create_Site_Site is Present');				
				}	
			  else	{
				console.log('create_Site_Site is NOT Present');
			   }				
				});  
			};
            
			 this.createSiteDescriptionIsPresent=function(){			
				element.all(create_Site_Description).then(function(items) {
				expect(items.length).toBe(1);				
				if(items.length > 0 ){
				console.log('create_Site_Description is Present');				
				}	
			  else	{
				console.log('create_Site_Description is NOT Present');
			   }					
				});  
			};
			
			 this.creatSiteValidFromIsPresent=function(){				
				element.all(create_Site_ValidFrom).then(function(items) {
				expect(items.length).toBe(1);				
				if(items.length > 0 ){
				console.log('create_Site_ValidFrom is Present');				
				}	
			  else	{
				console.log('create_Site_ValidFrom is NOT Present');
			   }				
				});  
			};
			
			 this.creatSiteValidToIsPresent=function(){				
				element.all(create_Site_ValidTo).then(function(items) {
				expect(items.length).toBe(1);				
				if(items.length > 0 ){
				console.log('create_Site_ValidTo is Present');				
				}	
			  else	{
				console.log('create_Site_ValidTo is NOT Present');
			   }				
				});  
			};
			
			this.createSiteCancelButtonIsPresent=function(){				
				element.all(create_Site_Cancel_button).then(function(items) {
				expect(items.length).toBe(1);				
				if(items.length > 0 ){
				console.log('create_Site_Cancel_button is Present');				
				}	
			  else	{
				console.log('create_Site_Cancel_button is NOT Present');
			   }				
				});  
			};
			
			
			this.createSiteSaveButtonIsPresent=function(){			
				element.all(create_Site_Save_button).then(function(items) {
				expect(items.length).toBe(1);	
				if(items.length > 0 ){
				console.log('create_Site_Save_button is Present');				
				}	
			  else	{
				console.log('create_Site_Save_button is NOT Present');
			   }
								
				});  
			};
			
			this.verifyTextOfErrorMessage=function(actualErrorMessage){
               element(create_ErrorMessageForDuplicateSubCode).getText().then(function (errorMessage) {
				   expect(errorMessage).toContain(actualErrorMessage);
				   console.log('error message='+errorMessage);
			   });
			};
			
			this.clickSubsidaryCodeDropdown=function(subsidaryCode)
				{
					element(create_Subsidiary_code_dropdown).click();
				};				
				
			
			this.enterTextInCreateSubsidaryCodeInputBox=function(subsidaryCode)
				{ 
					element(create_Subsidiary_code_inputbox).sendKeys(subsidaryCode);
					 
				};				
				
			this.enterTextInCreateSite=function(sites_site)
				{	var flag=false;
					element(create_Site_Site).sendKeys(sites_site);
					//expect(sites_site.length).not.toBeGreaterThan(30);
					if(sites_site.length<=30){
					console.log('Length of SITES CODE :'+sites_site.length+'-Text is LESS than OR Equal to Acceptable Limit (30)-');
					console.log('Test result : "PASS"');
					flag=true;
					}
				else
					{
					console.log('Length of SITES CODE :'+sites_site.length+'-Text is MORE than Acceptable Limit (30)-');
					console.log('Test result : "FAIL"');
					flag=false;
					}
					expect(flag).toBe(true);
				};				
				

		    this.enterTextInCreateDescription=function(sitesDescription)
				{
					element(create_Site_Description).sendKeys(sitesDescription);
					expect(sitesDescription.length).not.toBeGreaterThan(100);
					if(sitesDescription.length<=100){
					console.log('Length of SITES DESCRIPTION :'+sitesDescription.length+'-Text is LESS than OR Equal to 100-');
					console.log('Test result : "PASS"');
					}
				else
					{
					console.log('Length of SITES DESCRIPTION :'+sitesDescription.length+'-Text is MORE than 100-');
					console.log('Test result : "FAIL"');
					}
		
				};				
				
			this.enterTextInValidDateFrom=function(dateFrom)
				{
					element(create_Site_ValidFrom).sendKeys(dateFrom);
				};	
				
			this.enterTextInValidDateTo=function(dateTo)
				{
					element(create_Site_ValidTo).sendKeys(dateTo);
				};	
			
			this.clickOnSaveButton=function(){
				element(create_Site_Save_button).click();
				return require('./sitesPageObject.js');
			};
			
			this.clickOnCancelButton=function(){
			    element(create_Site_Cancel_button).click();
				return require('./sitesPageObject.js');
			};
			this.clickOnCanacelPopUpOk=function(){
				element(create_CancelPopUpOKBtn).click();
				return require('./sitesPageObject.js');
			};

			this.clickOnCanacelPopUpCancel=function(){
                element(create_CancelPopUpCancelBtn).click();
				//return require('./sitesPageObject.js');
			};
/*
			this.selectFirstElementFromDropDown=function(){		
			element(firstElementFromDropDown).click();
			};
*/
			this.SelectSubCodeFromDropDownByEnter=function(){		
			var enter = browser.actions().sendKeys(protractor.Key.ENTER);
			enter.perform();
			};
};
module.exports=new create_sites_page();