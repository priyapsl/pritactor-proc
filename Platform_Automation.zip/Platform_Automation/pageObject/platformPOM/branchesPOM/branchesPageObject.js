require('../branchesPOM/editBranchesPageObject.js');	
require('../branchesPOM/detailsBranchesPageObject.js');
require('../branchesPOM/createBranchesPageObject.js');

var branches_page=function(){
	//Subsidary Page Button
	var brnachesText=by.css('.col-md-4>h5');
	var brnachesFilterButton=by.buttonText('Filters');
    var branchesDeleteButton=by.buttonText('Delete');
	var branchesCreateButton=by.buttonText('Create');
	var branchesExoprtOPtion=by.css('#site_export_button');
	var branchesDelete_Yes_button=by.buttonText('Yes');
	var branchesDelete_No_button=by.buttonText('No');
	var branchesDelete_PopupMessage=by.css('.modal-body>p:nth-child(1)');
	var branchesDelete_PopUpCloseIcon=by.css('.modal-dialog .confirm-close-icon');
	
	
	//Subsidary Grid table Element
	var checkBoxToSelectAll=by.css('branch-listing .table-responsive thead tr th:nth-child(1) input');
	var branch_code=by.css('branch-listing .table-responsive thead tr th:nth-child(2)');
	var branch_Name=by.css('branch-listing .table-responsive thead tr th:nth-child(3)');

	var branch_Address=by.css('branch-listing .table-responsive thead tr th:nth-child(4)');
	var branch_Issuer=by.css('branch-listing .table-responsive thead tr th:nth-child(5)');

	var valid_from=by.css('branch-listing .table-responsive thead tr th:nth-child(6)');	
	var valid_To=by.css('branch-listing .table-responsive thead tr th:nth-child(7)');	
	var updatedBy=by.css('branch-listing .table-responsive thead tr th:nth-child(8)');
	var updatedOn=by.css('branch-listing .table-responsive thead tr th:nth-child(9)');
	
	
	//filter pane elements
	//var filter_SubsidaryCode_drpdwn=by.css('span.btn.btn-default.btn-secondary.form-control.ui-select-toggle'));
	var filter_BranchCode_drpdwn=by.css('.col-sm-3:nth-child(1) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
	var filter_BranchCode_inputBox=by.css('input.form-control.ui-select-search');	
	var filter_BranchCodeList=by.css('.dropdown-item>div');

    var filter_BranchName_drpdwn=by.css('.col-sm-3:nth-child(2) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
	var filter_BranchName_inputBox=by.css('input.form-control.ui-select-search');
	var filter_BranchNameList=by.css('.dropdown-item>div');

    var filter_Issuer_drpdwn=by.css('.col-sm-3:nth-child(3) .btn.btn-default.btn-secondary.form-control.ui-select-toggle');
	var filter_Issuer_inputBox=by.css('input.form-control.ui-select-search');
	var filter_IssuerList=by.css('.dropdown-item>div');
	
     
	var filter_Clear_Button=by.buttonText('Clear');
	var filter_Apply_Button=by.buttonText('Apply');
	var filter_CloseIcon=by.css('i.fa.fa-times.close-icon');
	var firstElementFromDropDown=by.css('branch-listing .ui-select-choices li:nth-child(1) a div');

	
	//Table Element
	var firstRowFromTable=by.css('branch-listing fng-table table tbody tr:nth-child(1)');
	var allRowsFromTable=by.css('branch-listing fng-table table tbody tr');
	

	var firstRowEditButton= by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(10) button i');

	var firstRowBranchCode=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(2) div div');		
	var firstRowBranchName=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(3) div div');	
	var firstRowAddress=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(4) div div');
    var firstRowIssuer=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(5) div div');
	
	var firstRowUpdatedBy=By.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(8) div div');
	var firstRowUpdatedOn=By.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(9) div div');
	var selectFirstRecordwithCheckbox=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(1) input');
	var selectAllRecordsOnPage=by.css('thead .table-checkbox input');
 
	//var descrptionList=by.css('.table-responsive>table>tbody>tr td:nth-child(3) div');
	
	var editIconForEachIssuer=by.css('.table-responsive>table>tbody>tr>td:nth-child(10) button i');
	
	
	
    //Pagination
	var nextSingleArrowOfPagination=by.css('li:nth-child(7) .page-link');
	var pageSizeSelector=by.css('#pageSizeSelector');
	var selectSize=by.css('select option[value="0"]');
	var noOfRecordsdisplayed=by.css('.col-sm-5.table-footer-text>p');
	var flag=false;
	
	//Subsidary Page Button Present
	this.branchesTextIsPresent=function(){		
		 element.all(brnachesText).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('brnaches Text is present');				
		});		
		
	};
	
	this.brnachesFilterButtonIsPresent=function(){		
		element.all(brnachesFilterButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('brnaches Filter Button is present');				
		});	
	};
	
	this.branchesDeleteButtonIsPresent=function(){		
		element.all(branchesDeleteButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('branches Delete Button is present');				
		});
	};
	
	this.branchesDeleteButtonIsEnabled=function(){
		if(element(branchesDeleteButton).isEnabled()){
			console.log('Delete button is enabled');
			flag=true;
		}
		return flag;
	};
	
	this.branchesCreateButtonIsPresent=function(){		
		element.all(branchesCreateButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('branches Create Button is present');				
		});
		
	};
	
   	this.branchesExoprtOPtionIsPresent=function(){		
		element.all(branchesExoprtOPtion).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('branches Exoprt OPtion is present');				
		});
		
	};

	//Subsidary Grid Element Present or Not
	this.checkBoxToSelectAllIsPresent=function(){		
       element.all(checkBoxToSelectAll).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('checkBox To Select All element on Page is present');				
		});		
	};
	
	this.clickOnCheckBoxToSelectAllProductsOnPage=function(){
		element(checkBoxToSelectAll).click();
				
	};
	
	this.branchCodeIsPresent=function(){		
        element.all(branch_code).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('branch code is present');				
		});				
	};

	this.branchNameIsPresent=function(){		
        element.all(branch_Name).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('branch Name is present');				
		});				
	};
	
	this.branchAddressIsPresent=function(){		
        element.all(branch_Address).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('branch_Address  is present');				
		});				
	};
	
	this.branchIssuerIsPresent=function(){		
        element.all(branch_Issuer).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('branch_Issuer is present');				
		});				
	};
	
	this.valid_fromIsPresent=function(){	
        element.all(valid_from).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('valid_from is present');				
		});			
	};
	
	this.valid_ToIsPresent=function(){			
        element.all(valid_To).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('valid_To is present');				
		});			
	};
	
	this.updatedByIsPresent=function(){		
        element.all(updatedBy).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('updatedBy is present');				
		});			
	};
	
	this.updatedOnIsPresent=function(){		
        element.all(updatedOn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('updatedOn is present');				
		});			
	};
	
	
	//Click On Filter,Delete,Create Button of Subsidary
	this.clickOnBrnachesFilterButton=function(){
		element(brnachesFilterButton).click();		
	};
	
	this.clickOnBranchesDeleteButton=function(){
		element(branchesDeleteButton).click();		
	};
	
	this.clickOnBranchesCreateButton=function(){
		element(branchesCreateButton).click();
        return require('./createBranchesPageObject.js');		
	};
	
	this.clickOnBranchesDeleteYesButton=function(){
		element(branchesDelete_Yes_button).click();
	}
	
	this.clickOnBranchesDeleteNoButton=function(){
		element(branchesDelete_No_button).click();
	}
	
    this.closeIconOfPopUpIsPresent=function(){		
        element.all(branchesDelete_PopUpCloseIcon).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('branchesDelete_PopUpCloseIcon is present');				
		});      		
	};

    this.clickOnCloseIconOfPopUp=function(){
			element(branchesDelete_PopUpCloseIcon).click();
	};

	this.getTextOfDeletePopup=function(){
		element.all(branchesDelete_PopupMessage).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);					  
						itemList[0].getText().then(function(text) {								         
								console.log('Message='+text);
								expect(text).toBe("Are you sure you want to delete the selected records?");		
							 
						});					
			});	
     }
	 
	 this.getTextOfDeletePopupForEntirePage=function(){
		element.all(branchesDelete_PopupMessage).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);					  
						itemList[1].getText().then(function(text) {								         
								console.log('Message='+text);
								expect(text).toContain("Are you sure you want to delete the selected records");		
							 
						});					
			});	
     }
	 
	//Filter Pane element present verification
	this.filter_BranchCode_drpdwnIsPresent=function(){		
        element.all(filter_BranchCode_drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_BranchCode_drpdwn is present');				
		});    	
		
	};

	this.filter_BranchCode_drpdwnIsNotPresent=function(){		
        element.all(filter_BranchCode_drpdwn).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('filter_BranchCode_drpdwn is not present');				
		});    	
		
	};

	this.filter_BranchName_drpdwnIsPresent=function(){		
        element.all(filter_BranchName_drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_BranchName_drpdwn is present');				
		});    	
		
	};

	this.filter_BranchName_drpdwnIsNotPresent=function(){		
        element.all(filter_BranchName_drpdwn).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('filter_BranchName_drpdwn is not present');				
		});    	
		
	};

	this.filter_Issuer_drpdwnIsPresent=function(){		
        element.all(filter_Issuer_drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Issuer_drpdwn is present');				
		});    	
		
	};

	this.filter_Issuer_drpdwnIsNotPresent=function(){		
        element.all(filter_Issuer_drpdwn).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('filter_Issuer_drpdwn is not present');				
		});    	
		
	};
	
	

	
	


	
	
	this.filter_Clear_ButtonIsPresent=function(){		
       element.all(filter_Clear_Button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Clear_Button is present');				
		});   		
	};
	
	this.filter_Clear_ButtonIsNotPresent=function(){		
       element.all(filter_Clear_Button).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('filter_Clear_Button is not present');				
		});   		
	};

	this.filter_Apply_ButtonIsPresent=function(){		
       element.all(filter_Apply_Button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Apply_Button is present');			
		});  		
	};
	
	this.filter_Apply_ButtonIsNotPresent=function(){		
       element.all(filter_Apply_Button).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('filter_Apply_Button is not present');				
		});  		
	};
	this.filter_CloseIconIsPresent=function(){		
        element.all(filter_CloseIcon).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_CloseIcon is present');				
		});  		
	};

	this.filter_CloseIconIsNotPresent=function(){		
        element.all(filter_CloseIcon).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('filter_CloseIcon is not present');				
		});  		
	};
	
	
	this.clickfilter_CloseIcon=function(){
			element(filter_CloseIcon).click();	
			console.log('Clicked on close icon of Filter Pane');
	};
	
	
	this.clickOnFilterBranchCodeDrpdwn=function(){		
		element(filter_BranchCode_drpdwn).click();
	};

	this.clickOnFilterBranchNameDrpdwn=function(){		
		element(filter_BranchName_drpdwn).click();
	};

	this.clickOnFilterIssuerDrpdwn=function(){		
		element(filter_Issuer_drpdwn).click();
	};



	
	
	this.enterTextInFilterBranchCodeDrpDown=function(branchCode){
           element(filter_BranchCode_inputBox).sendKeys(branchCode);
	};

	this.enterTextInFilterBranchNameDrpDown=function(branchCode){
           element(filter_BranchName_inputBox).sendKeys(branchCode);
	};

   this.enterTextInFilterIssuerDrpDown=function(issuer){
           element(filter_Issuer_inputBox).sendKeys(issuer);
	};
	

  


	this.getTextOfFilterBranchCodeDrpdown=function(){
		element(filter_BranchCode_inputBox).getText().then(function (text) {
			expect(text).toBe("");
			console.log('TextOfFilterBranchCodeCodeDrpdown='+text.length);
		});
	};

	this.getTextOfFilterBranchNameDrpdown=function(){
		element(filter_BranchName_inputBox).getText().then(function (text) {
			expect(text).toBe("");
			console.log('TextOfFilterBranchNameDrpdown='+text.length);
		});
	};
   
   this.verifyTextOfFilterBranchCodeDrpdown=function(branchCode){
		element(filter_BranchCode_inputBox).getText().then(function (text) {
			expect(text).toBe(branchCode);
			console.log('TextOfFilterBranchCodeCodeDrpdown='+text);
		});
	};
  
   this.selectParticularIssuer=function(issuer){
		console.log('Select particular issuer ='+issuer);       
		 element(by.cssContainingText('.dropdown-item>div', issuer)).click();      
	};
  

	this.selectParticularBranchode=function(branchCode){
		console.log('Select particular branchCode ='+branchCode);       
		 element(by.cssContainingText('.dropdown-item>div', branchCode)).click();      
	};

	this.selectParticularBranchName=function(branchName){
		console.log('Select particular branchName='+branchName);
		element(by.cssContainingText('.dropdown-item>div', branchName)).click();

			/*element.all(filter_ProductsCodeList).then(function(itemList) {
				      var flag1=false;
					   var count=0;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						//  var count=0;
						itemList[i].getText().then(function(text) {
						  
							  if (text == productCode) {
								count++;
								//expect(text).toEqual(productCode);
								//break;
								//itemList[i].click();
								console.log('text=prodCode='+text);
							  } 
							 
						});
						
					 };
					 itemList[count].click();				
			});*/
	};

	
	
	this.isParticularBranchCodePresentInDropDown=function(branchCode){
		
			element.all(filter_BranchCodeList).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						  var count=0;
						itemList[i].getText().then(function(text) {
						  
							  if (text == branchCode) {
								count++;
								expect(text).toEqual(branchCode);
								//break;
							  } 
							 
						});
					 };
				
			});
		
	};


	this.isParticularBranchNamePresentInDropDown=function(branchName){
		
			element.all(filter_BranchNameList).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						  var count=0;
						itemList[i].getText().then(function(text) {
						  
							  if (text == branchName) {
								count++;
								expect(text).toEqual(branchName);
								//break;
							  } 
							 
						});
					 };
				
			});
		
	};
   
   
   this.isParticularIssuerPresentInDropDown=function(issuer){
		
			element.all(filter_IssuerList).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						  var count=0;
						itemList[i].getText().then(function(text) {
						  
							  if (text == issuer) {
								count++;
								expect(text).toEqual(issuer);
								//break;
							  } 
							 
						});
					 };
				
			});
		
	};
   


   this.elementsInBranchCodeDrpDown=function(){
	   element.all(filter_BranchCodeList).then(function(itemList){
		   console.log("Total values in dropdown are: " + itemList.length);
		   expect(itemList.length>0).toBe(true);
	   });
   };

    this.elementsInBranchNameDrpDown=function(){
	   element.all(filter_BranchNameList).then(function(itemList){
		   console.log("Total values in dropdown are: " + itemList.length);
		   expect(itemList.length>0).toBe(true);
	   });
   };


   this.elementsInIssuerDrpDown=function(){
	   element.all(filter_IssuerList).then(function(itemList){
		   console.log("Total values in dropdown are: " + itemList.length);
		   expect(itemList.length>0).toBe(true);
	   });
   };

	this.branchCodeContaingText=function(branchCode){	
		//element(by.cssContainingText('.dropdown-item>div', productCode)).click();

			element.all(filter_BranchCodeList).then(function(itemList) {
				     
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						//  var count=0;
						itemList[i].getText().then(function(text) {				  
							 
								expect(text.toLowerCase()).toContain(branchCode);								
								console.log('text=branchCode='+text);							 
						});
						
					 };					 			
			});
	};


	this.branchNameContaingText=function(branchName){	
		//element(by.cssContainingText('.dropdown-item>div', productCode)).click();

			element.all(filter_BranchNameList).then(function(itemList) {
				     
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						//  var count=0;
						itemList[i].getText().then(function(text) {				  
							 
								expect(text.toLowerCase()).toContain(branchName);								
								console.log('text=branchName='+text);							 
						});
						
					 };					 			
			});
	};
	
   this.issuerContaingText=function(issuer){	
		//element(by.cssContainingText('.dropdown-item>div', productCode)).click();

			element.all(filter_IssuerList).then(function(itemList) {
				     
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						//  var count=0;
						itemList[i].getText().then(function(text) {				  
							 
								expect(text.toLowerCase()).toContain(issuer);								
								console.log('text=issuer='+text);							 
						});
						
					 };					 			
			});
	};


  this.branchCodeNotPresentInDropDown=function(){
      element.all(filter_BranchCodeList).then(function(itemList) {
          expect(itemList.length).toBe(0);
		  console.log('Elements in list='+itemList.length);
	  });
  };

  this.branchNameNotPresentInDropDown=function(){
      element.all(filter_BranchNameList).then(function(itemList) {
          expect(itemList.length).toBe(0);
		  console.log('Elements in list='+itemList.length);
	  });
  };

  this.issuerNotPresentInDropDown=function(){
      element.all(filter_IssuerList).then(function(itemList) {
          expect(itemList.length).toBe(0);
		  console.log('Elements in list='+itemList.length);
	  });
  };


  this.elementsPresentInDropDown=function(){
      element.all(filter_BranchCodeList).then(function(itemList) {
          expect(itemList.length>0).toBe(true);
		  console.log('Elements in list are more than 0='+itemList.length);
	  });
  };

  this.elementsBranchNamePresentInDropDown=function(){
      element.all(filter_BranchNameList).then(function(itemList) {
          expect(itemList.length>0).toBe(true);
		  console.log('Elements in list are more than 0='+itemList.length);
	  });
  };

 this.elementsIssuerPresentInDropDown=function(){
      element.all(filter_IssuerList).then(function(itemList) {
          expect(itemList.length>0).toBe(true);
		  console.log('Elements in list are more than 0='+itemList.length);
	  });
  };
	/*issuerCodeDrpdwnContainsAllCode()=function(){
		element.all(filter_ProductsCodeList).then(function(itemList) {			
			expect(itemList.length>0).toBe(true);
		});
	};*/

    this.productDescriptionContaingText=function(description){	
		//element(by.cssContainingText('.dropdown-item>div', productCode)).click();

			element.all(descrptionList).then(function(itemList) {
				      var flag1=false;
					   var count=0;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						//  var count=0;
						itemList[i].getText().then(function(text) {				  
							 
								expect(text).toContain(description);								
								console.log('text=prodCode='+text);							 
						});
						
					 };					 			
			});
	};

	


	this.firstElementFromDropDownIsPresent=function(){		
		 element.all(firstElementFromDropDown).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('firstElementFromDropDown is present');
				
		});		
	};
	
	this.selectFirstElementFromDropDown=function(){		
		element(firstElementFromDropDown).click();
	};
	
	this.clickOnFilterApplyButton=function(){
		element(filter_Apply_Button).click();
	};
	
	this.clickOnFilterClearButton=function(){
		element(filter_Clear_Button).click();
	};
	
	//Table element
	this.firstRowFromTableIsPresent= function(){
	   element.all(firstRowFromTable).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('firstRowFromTable is present');				
		});		
		
	};

	this.firstRowFromTableNotPresent=function(){
		element.all(allRowsFromTable).then(function(items) {
				expect(items.length).toBe(0);
				console.log('item in ='+items.length);
				console.log('elements are not present');
				
		});		
	};

	this.rowCountInTable=function(){
		element.all(allRowsFromTable).then(function(items) {
			     // if(items.length>=1)
				expect(items.length>=1).toBe(true);
				console.log('item in ='+items.length);
				console.log('elements in tables are more than 0');
				
		});		
	};

	this.defaultRecordsInPage=function(){
		element.all(allRowsFromTable).then(function(items) {
			     // if(items.length>=1)
				expect(items.length).toBe(10);
				console.log('item in ='+items.length);
				console.log('elements in tables are 10');
				
		});		
	};
	
	
	
	
	//To read the data of particular column
	this.getDataOfFirstRowParticularColumn=function(columnNo,data){
		
			  element(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).getText().then(function(text){
				  console.log('sjfjgh='+text);
				  expect(text).toBe(data);
				  
			  });

				 // console.log(text);         	
	};
	
	this.dataForParticularColumnIsPresent=function(columnNo){
		
			/*  if(element(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).isPresent()){
				  flag=true;
			  }
				return flag;*/

			element.all(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).then(function(items) {
				var flag=false;
				if(items.length>0){
					flag=true;
				}
				expect(flag).toBe(true);
				console.log('item in ='+items.length);				
		   });	
	};
	
	this.checkEditButtonForIssuer=function(){				 
					
            element.all(editIconForEachIssuer).then(function(items) {				
				expect(items.length>0).toBe(true);
				console.log('item in ='+items.length);				
		   });

	};





	this.clickOnFirstRowsEditButton=function(){
		 element(firstRowEditButton).click();
		 return require('./editBranchesPageObject.js');	
	};


	this.checkMultipleRecordsWithCheckBox=function(){
                           var count=0;		
							for(var i=1;i<4;i++){							  
										 if(element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input[type="checkbox"]')).isPresent()){
											 element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input[type="checkbox"]')).click();
												count++;
												console.log('j='+i);												
										 }										 												
							 } 	
							 
							 if(count>1){
								 flag=true;
								 console.log('Count Of check box='+count);
							 }
		       return flag;
	};
	this.nextSingleArrowOfPaginationIsEnabled= function(){
		if(element(nextSingleArrowOfPagination).isEnabled()){
			flag=true;
		}
		return flag;
	};
	
	this.clickOnNextSingleArrowOfPagination= function(){
		element(nextSingleArrowOfPagination).click();
		
	}; 

	this.clickOnPageSizeSelector=function() {
	 element(pageSizeSelector).click();	
	};
	
	this.selectParticularPageSize=function(){
        element(selectSize).click();
	};

	this.verifyRecordsOnPage=function(){
	
       element(noOfRecordsdisplayed).getText().then(function(text) {
		   expect(text).toContain('1 - 10');
	   });
	};
	
	this.clickOnfirstRowBranchCode=function(){
		 element(firstRowBranchCode).click();
		 return require('./detailsBranchesPageObject.js');	
	};

	this.getTextOfFirstRowBranchCode=function(branchCode){		
		
		 element(firstRowBranchCode).getText().then(function (text) {
			console.log('firstRowBranchCode='+text);
			expect(text).toContain(branchCode); 
		 });
	};

	this.verifyLengthOfBranchCode=function(){
          element(firstRowBranchCode).getText().then(function (text) {
			console.log('firstRowBranchCode='+text);
			expect(text.length<=30).toBe(true); 
		 });
	};
	
	this.getTextOfFirstRowBranchName=function(branchName){	

		 element(firstRowBranchName).getText().then(function (text) {
			console.log('firstRowBranchName='+text);
			expect(text).toContain(branchName); 
		 });
	};

	this.getTextOfFirstRowAddress=function(address){	

		 element(firstRowAddress).getText().then(function (text) {
			console.log('firstRowAddress='+text);
			expect(text).toContain(address); 
		 });
	};

	this.getTextOfFirstRowISsuer=function(issuer){	

		 element(firstRowIssuer).getText().then(function (text) {
			console.log('firstRowIssuer='+text);
			expect(text).toContain(issuer); 
		 });
	};


	this.getTextOfFirstRowUpdatedBy=function(){	

		 element(firstRowUpdatedBy).getText().then(function (text) {
			console.log('UpdatedBy='+text);
			expect(text).toBe(''); 
		 });
	};

  	this.verifyTextOfFirstRowUpdatedBy=function(updateBy){	

		 element(firstRowUpdatedBy).getText().then(function (text) {
			console.log('UpdatedBy='+text);
			expect(text).toBe(updateBy.toLowerCase()); 
		 });
	};

	this.getTextOfFirstRowUpdatedOn=function(){	

		 element(firstRowUpdatedOn).getText().then(function (text) {
			console.log('UpdatedOn'+text);
			expect(text).toBe(''); 
		 });
	};
	

	this.selectFirstRecordwithCheckbox=function(){
		element(selectFirstRecordwithCheckbox).click();
		browser.sleep(5000).then(function(){console.log("Selected first record with checkbox")});			
	};

    this.selectAllRecordwithCheckbox=function(){
        element(selectAllRecordsOnPage).click();
        browser.sleep(5000).then(function(){console.log("Selected first record with checkbox")});
    };

	this.selectMultipleRecordsWithCheckBox=function(){
		var count=0;
		for(i=1;i<4;i++){
              element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input')).click();
			  browser.sleep(2000).then(function(){console.log("Selected first 3 record with checkbox")});
			  count++;
		}
		expect(count>1).toBe(true);
	};
	
};
module.exports=new branches_page();