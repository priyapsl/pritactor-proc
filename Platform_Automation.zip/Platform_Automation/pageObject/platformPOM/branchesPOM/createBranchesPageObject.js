require('../branchesPOM/branchesPageObject.js');

var create_branch_page=function(){

			var create_Branch_code=by.css('#branch_create_code');
            var create_Branch_Name=by.css('#branch_create_name');
            var create_address=by.css('#branch_create_address');
           
            var create_Branch_ValidFrom=by.css('.col-md-2.custom-datepicker:nth-child(4) div input');
			var create_Branch_ValidTo=by.css('.col-md-2.custom-datepicker:nth-child(5) div input');	

			var create_Issuer_DrpDown=by.css('.btn.btn-default.btn-secondary.form-control.ui-select-toggle');
			var create_Issuer_InputBox=by.css('.form-control.ui-select-search');
          
		  
            		
			var create_Save_button=by.buttonText('Save');
			var create_Cancel_button=by.css('#branch_create_cancel_button');
           
		   
           
			  
			 
			 var branch_codeStar=by.css('.col-sm-6:nth-child(1) .required-icon');
			 var branch_nameStar=by.css('.col-sm-6:nth-child(2) .required-icon');
			 var addressStar=by.css('.col-sm-3:nth-child(2) .required-icon');

			 var validFromStar=by.css('.custom-datepicker:nth-child(4) .required-icon');
			 var validToStar=by.css('.custom-datepicker:nth-child(5) .required-icon');
			 var issuerStar=by.css('.col-md-2:nth-child(3) .required-icon');
           

			//var missingIssuerErrorMsg=by.css('.col-sm-3:nth-child(3) .error-msg>span:nth-child(2)');
			var missingBranchCodeErrorMsg=by.css('.col-sm-6:nth-child(1) .error-msg>span:nth-child(2)');
			var missingBranchNameErrorMsg=by.css('.col-sm-6:nth-child(2) .error-msg>span:nth-child(2)');
           var missingAddressErrorMsg=by.css('.col-sm-3:nth-child(2) .error-msg>span:nth-child(2)');
		   var missingIssuerErrorMsg=by.css('.col-md-2:nth-child(3) .error-msg>span:nth-child(2)');

          
			var create_CancelPopUpOKBtn=by.css('#canceldialog_ok_button');
			var cancelPopUpMessage=by.css('cancel-dialog .modal-body>p');
			var create_CancelPopUpCancelBtn=by.css('#canceldialog_cancel_button');
			var firstElementFromDropDown=by.css('.ui-select-choices li:nth-child(1) a div');
 
    
			var flag=false;

            this.createBranchCodeIsPresent=function(){				
				element.all(create_Branch_code).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Branch_code is present');				
				});  
			};

			 this.createBranchNameIsPresent=function(){				
				element.all(create_Branch_Name).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Branch_Name is present');				
				});  
			};

			this.createBranchAddressIsPresent=function(){				
				element.all(create_address).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_address is present');				
				});  
			};

			
   
            
			
			
			 this.createBranchValidFromIsPresent=function(){				
				element.all(create_Branch_ValidFrom).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Branch_ValidFrom is present');				
				});  
			};
			
			 this.createBranchValidToIsPresent=function(){				
				element.all(create_Branch_ValidTo).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Branch_ValidTo is present');				
				});  
			};

			 this.createIssuerDrpDwnIsPresent=function(){				
				element.all(create_Issuer_DrpDown).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Issuer_DrpDown is present');				
				});  
			};

          



            this.documentRetentionPeriodInputIsPresent=function(){				
				element.all(documentRetentionPeriod).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('documentRetentionPeriod is present');				
				});  
			};

			this.documentRetentionUnitInputIsPresent=function(){				
				element.all(documentRetentionUnit).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('documentRetentionUnit is present');				
				});  
			};
			

			  this.notificationRetentionPeriodInputIsPresent=function(){				
				element.all(notificationRetentionPeriod).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('notificationRetentionPeriod is present');				
				});  
			};
			
            this.notificationRetentionUnitInputIsPresent=function(){				
				element.all(notificationRetentionUnit).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('notificationRetentionUnit is present');				
				});  
			};

		

			this.createCancelButtonIsPresent=function(){				
				element.all(create_Cancel_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Cancel_button is present');				
				});  
			};
			
			
			this.creatBranchSaveButtonIsPresent=function(){			
				element.all(create_Save_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Save_button is present');				
				});  
			};

			this.branchCodeStarIsPresent=function(){			
				element.all(branch_codeStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('branch_codeStar is present');				
				});  
			};

			this.branchNameStarIsPresent=function(){			
				element.all(branch_nameStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('branch_nameStar is present');				
				});  
			};


            this.addressStarIsPresent=function(){			
				element.all(addressStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('addressStar is present');				
				});  
			};


			this.validFromStarIsPresent=function(){			
				element.all(validFromStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('validFromStar is present');				
				});  
			};

			this.validToStarIsPresent=function(){			
				element.all(validToStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('validToStar is present');				
				});  
			};

			this.issuerStarIsPresent=function(){			
				element.all(issuerStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('issuerStar is present');				
				});  
			};

			
			this.verifyTextOfErrorMessage=function(actualErrorMessage){
               element(create_ErrorMessageForDuplicateSubCode).getText().then(function (errorMessage) {
				   expect(errorMessage).toContain(actualErrorMessage);
				   console.log('error message='+errorMessage);
			   });
			};

		
			
			
			this.eneterTextInCreateBranchCode=function(branchCode)
				{
					element(create_Branch_code).sendKeys(branchCode);
				};	

          this.eneterTextInCreateBranchName=function(branchName)
				{
					element(create_Branch_Name).sendKeys(branchName);
				};

				this.eneterTextInCreateBranchAddress=function(debitor)
				{
					element(create_address).sendKeys(debitor);
				};	

			

			
		  
			this.eneterTextInValidDateFrom=function(dateFrom)
				{
					element(create_Branch_ValidFrom).sendKeys(dateFrom);
				};	
				
			this.eneterTextInValidDateTo=function(dateTo)
				{
					element(create_Branch_ValidTo).sendKeys(dateTo);
				};

            this.eneterTextInIssuerInputBox=function(issuer)
				{
					element(create_Issuer_InputBox).sendKeys(issuer);
				};

			 


            

			
			

			this.clickOnIssuerDrpDwn=function(){
               
			   element(create_Issuer_DrpDown).click();
			};	

			

           
			
			this.clickOnSaveButton=function(){
				element(create_Save_button).click();
				return require('./branchesPageObject.js');
			};

				this.clickOnClearSaveButton=function(){
					element(create_Save_button).click();

				};

			this.selectParticularIssuer=function(parentIssuer){	
						 element(by.cssContainingText('.dropdown-item>div', parentIssuer)).click();
			}	

		
				
			
			this.clickOnCancelButton=function(){
			    element(create_Cancel_button).click();
				
			};
			this.clickOnBlankCancelButton=function(){
				element(create_Cancel_button).click();
                return require('./branchesPageObject.js');
			};

			this.clickOnCanacelPopUpOk=function(){
                element(create_CancelPopUpOKBtn).click();
				return require('./branchesPageObject.js');
			};

			this.clickOnCanacelPopUpCancel=function(){
                element(create_CancelPopUpCancelBtn).click();
				return require('./branchesPageObject.js');
			};

			this.selectFirstElementFromDropDown=function(){		
				element(firstElementFromDropDown).click();
			};

			this.verifyErrorMessage=function(){
              element(missingIssuerErrorMsg).getText().then(function (text) {
				  expect(text).toBe('Please choose an Issuer');
			  })
			};

			this.verifyMissingAddressErrorMessage=function(errorMsg){
              element(missingAddressErrorMsg).getText().then(function (text) {
				  expect(text).toBe(errorMsg);
			  })
			};

			this.verifyMissingBranchCodeErrorMessage=function(errorMsg){
              element(missingBranchCodeErrorMsg).getText().then(function (text) {
				  expect(text).toBe(errorMsg);
			  })
			};

			this.verifyMissingBranchNameErrorMessage=function(errorMsg){
              element(missingBranchNameErrorMsg).getText().then(function (text) {
				  expect(text).toBe(errorMsg);
			  })
			};

		  this.verifyMissingIssuerErrorMessage=function(errorMsg){
              element(missingIssuerErrorMsg).getText().then(function (text) {
				  expect(text).toBe(errorMsg);
			  })
			};
           
		   this.verifyCancelPopUpMessage=function(){
              element(cancelPopUpMessage).getText().then(function (text) {
				 expect(text).toContain('Are you sure you want to cancel the request? You will lose unsaved data'); 
				 console.log('PopUpMessage='+text);
			  });
		   };

		   	


		  
		  
};
module.exports=new create_branch_page();