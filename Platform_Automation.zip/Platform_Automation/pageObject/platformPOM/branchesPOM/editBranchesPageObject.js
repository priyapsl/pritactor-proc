require('../branchesPOM/branchesPageObject.js');

var edit_branch_page=function(){
	
			var edit_branch_code=by.css('#branch_edit_code');
			var edit_branch_Name=by.css('#branch_edit_name');
            var edit_branch_Address=by.css('#branch_edit_address');

		    var edit_issuer_Disponent=by.css('edit-issuer input#issuer_edit_disponent');
			var edit_Branch_ValidFrom=by.css('#branch_edit_validfrom');
			var edit_Branch_ValidTo=by.css('#branch_edit_validto');
			var edit_Branch_Save_button=by.buttonText('Save');
			var edit_Branch_Cancel_button=by.css('#branch_edit_cancel_button');

			var edit_IssuerDrpDwn=by.css('.btn.btn-default.btn-secondary.form-control.ui-select-toggle');
			
            
            

	

			var edit_ProductCodeErrorMsg=by.css('edit-product .col-sm-3.has-error:nth-child(1) .error-msg>span:nth-child(2)');			
			var edit_DescriptionErrorMsg=by.css('edit-product .col-sm-3.has-error:nth-child(2) .error-msg>span:nth-child(2)');
			
            var edit_prodCodeStar=by.css('.col-sm-3:nth-child(1) .required-icon');
			var edit_DescriptionStar=by.css('.col-sm-3:nth-child(2) .required-icon');
            var edit_IssuerStar=by.css('.col-sm-3:nth-child(3) .required-icon');
            var edit_fromDateStar=by.css('.col-md-3:nth-child(1) .required-icon');
             var edit_ToDateStar=by.css('.col-md-3:nth-child(2) .required-icon');
			var flag=false;
            
			 this.editBranchCodeIsPresent=function(){				
				element.all(edit_branch_code).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_branch_code is present');				
				});  
			};

			this.verifyTextOfEditBranchCode=function(branchCode){	
				element(edit_branch_code).getAttribute('value').then(function (text) {
				expect(text).toBe(branchCode);
				console.log('text='+text);
				});
			};
   
            
			 this.editBranchNameIsPresent=function(){				
				element.all(edit_branch_Name).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_branch_Name is present');				
				});  
			};

			this.verifyTextOfEditIssuerName=function(branchName){	
				element(edit_branch_Name).getAttribute('value').then(function (text) {
				expect(text).toBe(branchName);
				console.log('issuerName='+text);
				});
			};

			 this.editIssuerDisponentIsPresent=function(){				
				element.all(edit_issuer_Disponent).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_issuer_Disponent is present');				
				});  
			};

            this.verifyTextOfEditDisponent=function(disponent){	
				element(edit_issuer_Disponent).getAttribute('value').then(function (text) {
				expect(text).toBe(disponent);
				console.log('disponent='+text);
				});
			};
               

			 this.editBranchAddressIsPresent=function(){				
				element.all(edit_branch_Address).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_branch_Address is present');				
				});  
			};

			 this.verifyTextOfEditAddress=function(address){	
				element(edit_branch_Address).getAttribute('value').then(function (text) {
				expect(text).toBe(address);
				console.log('address='+text);
				});
			};
			
			 this.editValidFromIsPresent=function(){				
				element.all(edit_Branch_ValidFrom).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Branch_ValidFrom is present');				
				}); 
			};
			
			 this.editValidToIsPresent=function(){				
				element.all(edit_Branch_ValidTo).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Branch_ValidTo is present');				
				}); 
			};
			
			this.editBranchCancelButtonIsPresent=function(){
				
				element.all(edit_Branch_Cancel_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Branch_Cancel_button is present');				
				}); 
			};

            this.editProductIssuerDrpdwnIsPresent=function(){
				
				element.all(edit_Product_Issuer_Drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Product_Issuer_Drpdwn is present');				
				}); 
			};
			
			
			this.editBranchSaveButtonIsPresent=function(){				
				element.all(edit_Branch_Save_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Branch_Save_button is present');				
				}); 
			};
			
            this.editProductStarIsPresent=function(){				
				element.all(edit_prodCodeStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_prodCodeStar is present');				
				}); 
			};
           
           this.editDescriptionStarIsPresent=function(){				
				element.all(edit_DescriptionStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_DescriptionStar is present');				
				}); 
			};

             this.editIssuerStarIsPresent=function(){				
				element.all(edit_IssuerStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_IssuerStar is present');				
				}); 
			};

             this.editFromDateStarIsPresent=function(){				
				element.all(edit_fromDateStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_fromDateStar is present');				
				}); 
			};
 
            this.editToDateStarIsPresent=function(){				
				element.all(edit_ToDateStar).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_ToDateStar is present');				
				}); 
			};

			 
			 this.editIssuerDrpdwnIsPresent=function(){				
				element.all(edit_IssuerDrpDwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_IssuerDrpDwn is present');				
				}); 
			};

			

		   this.selectParticularLanguage=function(language){	
						 element(by.cssContainingText('.dropdown-item>div', language)).click();
			}	


             

			
			
			this.eneterTextInEditBranchCode=function(branchCode)
				{
					element(edit_branch_code).sendKeys(branchCode);
				};				
				
		    this.clearEditBranchCode=function()
				{
					element(edit_branch_code).clear();
				};
			
		    this.eneterTextInEditBranchName=function(branchName)
				{
					element(edit_branch_Name).sendKeys(branchName);
				};	

            this.clearEditIssuerName=function()
				{
					element(edit_branch_Name).clear();
				};	

			this.eneterTextInEditBranchAddress=function(address)
				{
					element(edit_branch_Address).sendKeys(address);
				};

				 this.clearEditBranchAddress=function()
				{
					element(edit_branch_Address).clear();
				};

			


             this.clearValidFromDate=function()
				{
					element(edit_Branch_ValidFrom).clear();
				};	

				this.clearValidToDate=function()
				{
					element(edit_Branch_ValidTo).clear();
				};	
				
			this.eneterTextInValidDateFrom=function(dateFrom)
				{
					element(edit_Branch_ValidFrom).sendKeys(dateFrom);
				};	
				
			this.eneterTextInValidDateTo=function(dateTo)
				{
					element(edit_Branch_ValidTo).sendKeys(dateTo);
				};	
			
			this.clickOnSaveButton=function(){
				element(edit_Branch_Save_button).click();
				return require('./branchesPageObject.js');
			};

            this.clickOnClearSaveButton=function(){
				element(edit_Branch_Save_button).click();
				//return require('./produtcsPageObject.js');
			};
			
			
			this.clickOnCancelButton=function(){
			    element(edit_Branch_Cancel_button).click();
				return require('./branchesPageObject.js');
			};
            
            this.verifyProductDescriptionErrorMsg=function(errorMsg){
               element(edit_DescriptionErrorMsg).getText().then(function (text) {
                   expect(text).toBe(errorMsg);
                   console.log('Error Message='+errorMsg);
               })
            };

            this.verifyProductMissingErrorMsg=function(errorMsg){
               element(edit_ProductCodeErrorMsg).getText().then(function (text) {
                   expect(text).toBe(errorMsg);
                   console.log('Error Message='+errorMsg);
               })
            };



};
module.exports=new edit_branch_page();