require('../branchesPOM/branchesPageObject.js');
require('../branchesPOM/editBranchesPageObject.js');

var details_Branch_page=function(){
	
            var details_Branch_Edit_button=by.buttonText('Edit');
			var details_Branch_Back_button=by.buttonText('Back');
			var details_BranchCode=by.css('.form-group:nth-child(1) .row:nth-child(1) .col-sm-2:nth-child(1) .view-page-value');
			var details_BranchName=by.css('.form-group:nth-child(1) .row:nth-child(1) .col-sm-2:nth-child(2) .view-page-value');
			var details_Address=by.css('.form-group:nth-child(1) .row:nth-child(1) .col-sm-2:nth-child(3) .view-page-value');
			var details_Issuer=by.css('.form-group:nth-child(1) .row:nth-child(1) .col-sm-2:nth-child(4) .view-page-value');
			var details_ValidFrom=by.css('.form-group:nth-child(1) .row:nth-child(1) .col-md-2:nth-child(5) .view-page-value');
			var details_ValidTo=by.css('.form-group:nth-child(1) .row:nth-child(1) .col-md-2:nth-child(6) .view-page-value');
            var details_Branch_updateOn=by.css('.form-group:nth-child(1) .row:nth-child(3) .col-sm-2:nth-child(3) .view-page-value');
			var details_Branch_updateBy=by.css('.form-group:nth-child(1) .row:nth-child(3) .col-sm-2:nth-child(4) .view-page-value');
			var details_Branch_createdBy=by.css('.form-group:nth-child(1) .row:nth-child(3) .col-sm-2:nth-child(2) .view-page-value');
			var flag=false;
			
			
			this.clickOnDetailsEditButton=function(){
				element(details_Branch_Edit_button).click();
				 return require('./editBranchesPageObject.js');
			};
			
			this.clickOnDetailsBackButton=function(){
			    element(details_Branch_Back_button).click();
				return require('./branchesPageObject.js');
			};
           
           this.detailsBranchEditButtonIsPresent=function(){			  
			      element.all(details_Branch_Edit_button).then(function(items) {
					expect(items.length).toBe(1);				
					console.log('details_Branch edit button is present='+items.length);				
	            });		
		   }

		    this.detailsBranchBackButtonIsPresent=function(){			  
			      element.all(details_Branch_Back_button).then(function(items) {
					expect(items.length).toBe(1);				
					console.log('details_Branch back button is present='+items.length);				
	            });		
		   }


          this.verifyTextOfBranchCode=function(branchCode){
               element(details_BranchCode).getText().then(function (data) {
				   expect(data).toBe(branchCode);
				   console.log('details_branchCode ='+data);
			   });
		   };

		   this.verifyTextOfBranchName=function(branchName){
               element(details_BranchName).getText().then(function (data) {
				   expect(data).toBe(branchName);
				   console.log('details_BranchName ='+data);
			   });
		   };


		     this.verifyTextOfAddress=function(address){
               element(details_Address).getText().then(function (data) {
				   expect(data).toBe(address);
				   console.log('details_Address ='+data);
			   });
		   };

		    this.verifyTextOfIssuer=function(issuer){
               element(details_Issuer).getText().then(function (data) {
				   expect(data).toBe(issuer);
				   console.log('details_Issuer ='+data);
			   });
		   };


		   this.verifyTextOfValidFrom=function(validFrom){
               element(details_ValidFrom).getText().then(function (data) {
				   expect(data).toBe(validFrom);
				   console.log('details_ValidFrom ='+data);
			   });
		   };

		   this.verifyTextOfValidTo=function(validTo){
               element(details_ValidTo).getText().then(function (data) {
				   expect(data).toBe(validTo);
				   console.log('details_ValidTo ='+data);
			   });
		   };

		   this.verifyTextOfUpdatedOn=function(){
               element(details_Branch_updateOn).getText().then(function (data) {
				   expect(data).toBe('');
				   console.log('details_Branch_updateOn ='+data);
			   });
		   };

           this.verifyTextOfUpdatedBy=function(){
               element(details_Branch_updateBy).getText().then(function (data) {
				   expect(data).toBe('');
				   console.log('details_Branch_updateBy ='+data);
			   });
		   };

		   this.verifyTextOfCreatedBy=function(createdBy){
               element(details_Branch_createdBy).getText().then(function (data) {
				   expect(data).toBe(createdBy.toLowerCase());
				   console.log('details_Branch_createdBy ='+data);
			   });
		   };

};
module.exports=new details_Branch_page();
