require('../subsidaryPOM/createSubsidaryPageObject.js');
require('../subsidaryPOM/editSubsidaryPageObject.js');	
require('../subsidaryPOM/detailsSubsidaryPageObject.js');

var subsidary_page=function(){
	//Subsidary Page Button
	var subsidaryText=by.css('h5');
	var filterButton=by.buttonText('Filters');
    var deleteButton=by.buttonText('Delete');
	var createButton=by.buttonText('Create');
	var delete_Yes_button=by.buttonText('Yes');
	var delete_No_button=by.buttonText('No');
	var delete_PopupMessage=by.css('.modal-body>p');
	var delet_PopUpCloseIcon=by.css('.modal-dialog .confirm-close-icon');
	
	
	//Subsidary Grid table Element
	var checkBoxToSelectAll=by.css('.subsidiaries-wrapper .table-responsive thead tr th:nth-child(1) input');
	var subsidary_code=by.css('.subsidiaries-wrapper .table-responsive thead tr th:nth-child(2)');
	var subsidary_Description=by.css('.subsidiaries-wrapper .table-responsive thead tr th:nth-child(3)');
	var valid_from=by.css('.subsidiaries-wrapper .table-responsive thead tr th:nth-child(4)');
	var valid_To=by.css('.subsidiaries-wrapper .table-responsive thead tr th:nth-child(5)');
	var updatedBy=by.css('.subsidiaries-wrapper .table-responsive thead tr th:nth-child(6)');
	var updatedOn=by.css('.subsidiaries-wrapper .table-responsive thead tr th:nth-child(7)');
	
	
	//filter pane elements
	//var filter_SubsidaryCode_drpdwn=by.css('span.btn.btn-default.btn-secondary.form-control.ui-select-toggle'));
	var filter_SubsidaryCode_drpdwn=by.css('.btn.btn-default.btn-secondary.form-control.ui-select-toggle');
	var filter_SubsidaryCode_inputBox=by.css('input.form-control.ui-select-search');
	var filter_SubsidaryCodeList=by.css('.dropdown-item>div');
	var filter_Description=by.css('input#subsidiary_filter_description');
	var filter_Clear_Button=by.buttonText('Clear');
	var filter_Apply_Button=by.buttonText('Apply');
	var filter_CloseIcon=by.css('i.fa.fa-times.close-icon');
	var firstElementFromDropDown=by.css('.subsidiaries-wrapper .ui-select-choices li:nth-child(2)');
	
	//Table Element
	var firstRowFromTable=by.css('.subsidiaries-wrapper fng-table table tbody tr:nth-child(1)');
	var allRowsFromTable=by.css('.subsidiaries-wrapper fng-table table tbody tr');
	var nextSingleArrowOfPagination=by.css('[ng-reflect-inner-h-t-m-l="&#8250;"]');
	var firstRowEditButton= by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(8)');
	var firstRowSubsidaryCode=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(2) div div');
	var firstRowDescription=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(3) div div');
	var selectFirstRecordwithCheckbox=by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child(1) input');
	
	var editIconForEachSubsidary=by.css('.table-responsive>table>tbody>tr>td:nth-child(8)');
	var flag=false;
	
	//Subsidary Page Button Present
	this.subsidaryTextIsPresent=function(){		
		 element.all(subsidaryText).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('subsidary Text is present');				
		});		
		
	};
	
	this.filterButtonIsPresent=function(){		
		element.all(filterButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('Filter Button is present');				
		});	
	};
	
	this.deleteButtonIsPresent=function(){		
		element.all(deleteButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('Delete Button is present');				
		});
	};
	
	this.deleteButtonIsEnabled=function(){
		if(element(deleteButton).isEnabled()){
			console.log('Delete button is enabled');
			flag=true;
		}
		return flag;
	};
	
	this.createButtonIsPresent=function(){		
		element.all(createButton).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('Create Button is present');				
		});
		
	};
	
	//Subsidary Grid Element Present or Not
	this.checkBoxToSelectAllIsPresent=function(){		
       element.all(checkBoxToSelectAll).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('checkBox To Select All element on Page is present');				
		});		
	};
	
	this.clickOnCheckBoxToSelectAllSubsidaryOnPage=function(){
		element(checkBoxToSelectAll).click();
				
	};
	
	this.subsidaryCodeIsPresent=function(){		
        element.all(subsidary_code).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('subsidary_code is present');				
		});				
	};
	
	
	this.subsidary_DescriptionIsPresent=function(){		
        element.all(subsidary_Description).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('subsidary_Description is present');				
		});			
	};
	
	this.valid_fromIsPresent=function(){	
        element.all(valid_from).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('valid_from is present');				
		});			
	};
	
	this.valid_ToIsPresent=function(){			
        element.all(valid_To).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('valid_To is present');				
		});			
	};
	
	this.updatedByIsPresent=function(){		
        element.all(updatedBy).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('updatedBy is present');				
		});			
	};
	
	this.updatedOnIsPresent=function(){		
        element.all(updatedOn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('updatedOn is present');				
		});			
	};
	
	
	//Click On Filter,Delete,Create Button of Subsidary
	this.clickOnFilterButton=function(){
		element(filterButton).click();		
	};
	
	this.clickOnDeleteButton=function(){
		element(deleteButton).click();		
	};
	
	this.clickOnCreateButton=function(){
		element(createButton).click();
        return require('./createSubsidaryPageObject.js');		
	};
	
	this.clickOnDeleteYesButton=function(){
		element(delete_Yes_button).click();
	}
	
	this.clickOnDeleteNoButton=function(){
		element(delete_No_button).click();
	}
	
    this.closeIconOfPopUpIsPresent=function(){		
        element.all(delet_PopUpCloseIcon).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('delet_PopUpCloseIcon is present');				
		});      		
	};

    this.clickOnCloseIconOfPopUp=function(){
			element(delet_PopUpCloseIcon).click();
	};

	this.getTextOfDeletePopup=function(){
		element.all(delete_PopupMessage).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);					  
						itemList[0].getText().then(function(text) {								         
								console.log('Message='+text);
								expect(text).toBe("Are you sure you want to delete the selected records?");		
							 
						});					
			});	
     }
	 
	 this.getTextOfDeletePopupForEntirePage=function(){
		element.all(delete_PopupMessage).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);					  
						itemList[1].getText().then(function(text) {								         
								console.log('Message='+text);
								expect(text).toContain("Records selected");		
							 
						});					
			});	
     }
	 
	//Filter Pane element present verification
	this.filter_SubsidaryCode_drpdwnIsPresent=function(){		
        element.all(filter_SubsidaryCode_drpdwn).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_SubsidaryCode_drpdwn is present');				
		});    	
		
	};
	
	this.filter_DescriptionIsPresent=function(){		
        element.all(filter_Description).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Description is present');				
		});    			
	};
	
	
	this.filter_Clear_ButtonIsPresent=function(){		
       element.all(filter_Clear_Button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Clear_Button is present');				
		});   		
	};
	
	this.filter_Apply_ButtonIsPresent=function(){		
       element.all(filter_Apply_Button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_Apply_Button is present');				
		});  		
	};
	
	this.filter_CloseIconIsPresent=function(){		
        element.all(filter_CloseIcon).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('filter_CloseIcon is present');				
		});  		
	};
	
	
	this.clickfilter_CloseIcon=function(){
			element(filter_CloseIcon).click();	
	};
	
	
	this.clickOnFilterSubsidaryCodeDrpdwn=function(){		
		element(filter_SubsidaryCode_drpdwn).click();
	};
	
	this.enterTextInFilterSubsidaryCodeDrpDown=function(subsidaryCode){
           element(filter_SubsidaryCode_inputBox).sendKeys(subsidaryCode);
	};

	this.getTextOfFilterSubsidaryCodeDrpdown=function(){
		element(filter_SubsidaryCode_inputBox).getText().then(function (text) {
			expect(text).toBe("");
			console.log('TextOfFilterSubsidaryCodeDrpdown='+text.length);
		});
	};

   this.getTextOfFilterDescription=function(){
      element(filter_Description).getText().then(function (text) {
		  expect(text).toBe("");
		  console.log('filter_Description text length='+text.length);
	  });   
   };
	this.selectParticularSubCode=function(subsidaryCode){
		element(by.cssContainingText('.dropdown-item>div', subsidaryCode)).click();
	};
	
	this.isParticularSubCodePresentInDropDown=function(subsidaryCode){
		
			element.all(filter_SubsidaryCodeList).then(function(itemList) {
				      var flag1=false;
					  console.log("Total values in dropdown are: " + itemList.length);
					  for (i = 0; i < itemList.length; i++) {
						  var count=0;
						itemList[i].getText().then(function(text) {
						  
							  if (text == subsidaryCode) {
								count++;
								expect(text).toEqual(subsidaryCode);
								//break;
							  } 
							 
						});
					 };
				
			});
		
	};
	
	this.isParticularSubCodeNotPresntDropDown=function(subsidaryCode){

		  element.all(by.cssContainingText('.dropdown-item>div', subsidaryCode)).then(function(items) {
				expect(items.length).toBe(0);				
				console.log('SubCode is not present='+items.length);				
		});  	
	};

	this.firstElementFromDropDownIsPresent=function(){		
		 element.all(firstElementFromDropDown).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('firstElementFromDropDown is present');
				
		});		
	};
	
	this.selectFirstElementFromDropDown=function(){		
		element(firstElementFromDropDown).click();
	};
	
	this.clickOnFilterApplyButton=function(){
		element(filter_Apply_Button).click();
	};
	
	this.clickOnFilterClearButton=function(){
		element(filter_Clear_Button).click();
	};
	
	//Table element
	this.firstRowFromTableIsPresent= function(){
	   element.all(firstRowFromTable).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('firstRowFromTable is present');				
		});		
		
	};

	this.firstRowFromTableNotPresent=function(){
		element.all(allRowsFromTable).then(function(items) {
				expect(items.length).toBe(0);
				console.log('item in ='+items.length);
				console.log('elements are not present');
				
		});		
	};
	
	this.eneterTextInDescriptionBox=function(descriptionText)
	{
		element(filter_Description).sendKeys(descriptionText);
	};
	
	
	
	//To read the data of particular column
	this.getDataOfFirstRowParticularColumn=function(columnNo,data){
		
			  element(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).getText().then(function(text){
				  console.log('sjfjgh='+text);
				  expect(text).toBe(data);
				  
			  });

				 // console.log(text);         	
	};
	
	this.dataForParticularColumnIsPresent=function(columnNo){
		
			/*  if(element(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).isPresent()){
				  flag=true;
			  }
				return flag;*/

			element.all(by.css('.table-responsive>table>tbody>tr:nth-child(1)>td:nth-child('+columnNo+')')).then(function(items) {
				var flag=false;
				if(items.length>0){
					flag=true;
				}
				expect(flag).toBe(true);
				console.log('item in ='+items.length);				
		   });	
	};
	
	this.checkEditButtonForEachSubsidary=function(){				 
					
            element.all(editIconForEachSubsidary).then(function(items) {				
				expect(items.length).toBe(10);
				console.log('item in ='+items.length);				
		   });

	};
	
	this.checkMultipleRecordsWithCheckBox=function(){
                           var count=0;		
							for(var i=1;i<4;i++){							  
										 if(element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input[type="checkbox"]')).isPresent()){
											 element(by.css('.table-responsive>table>tbody>tr:nth-child('+i+')>td:nth-child(1) input[type="checkbox"]')).click();
												count++;
												console.log('j='+i);												
										 }										 												
							 } 	
							 
				/*			 if(count>1){
								 flag=true;
								 console.log('Count Of check box='+count);
							 }
		       return flag;*/
	};
	nextSingleArrowOfPaginationIsEnabled= function(){
		if(element(nextSingleArrowOfPagination).isEnabled()){
			flag=true;
		}
		return flag;
	};
	
	clickOnNextSingleArrowOfPagination= function(){
		element(nextSingleArrowOfPagination).click();
		
	};
	
	this.clickOnFirstRowsEditButton=function(){
		 element(firstRowEditButton).click();
		 return require('./editSubsidaryPageObject.js');	
	};
	
	this.clickOnfirstRowSubsidaryCode=function(){
		 element(firstRowSubsidaryCode).click();
		 return require('./detailsSubsidaryPageObject.js');	
	};

	this.getTextOfFirstRowSubsidaryCode=function(subCode){		
		
		 element(firstRowSubsidaryCode).getText().then(function (text) {
			console.log('firstRowSubsidaryCode'+text);
			expect(text).toContain(subCode); 
		 });
	};
	
	this.getTextOfFirstRowDescription=function(description){	

		 element(firstRowDescription).getText().then(function (text) {
			console.log('firstRowDescription'+text);
			expect(text).toContain(description); 
		 });
	};
	

	this.selectFirstRecordwithCheckbox=function(){
		element(selectFirstRecordwithCheckbox).click();
		
	};
	
};
module.exports=new subsidary_page();