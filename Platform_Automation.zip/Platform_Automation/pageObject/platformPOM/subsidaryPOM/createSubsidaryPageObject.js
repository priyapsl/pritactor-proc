require('../subsidaryPOM/subsidaryPageObject.js');

var create_subsidary_page=function(){

			var create_Subsidary_code=by.css('create-subsidiary input#subsidiary_create_subcode');
			var create_Subsidary_Description=by.css('create-subsidiary input#subsidiary_create_description');
			var create_Subsidary_ValidFrom=by.css('create-subsidiary input#subsidiary_create_validfrom');
			var create_Subsidary_ValidTo=by.css('create-subsidiary input#subsidiary_create_validto');
			var create_Subsidary_Save_button=by.buttonText('Save');
			var create_Subsidary_Cancel_button=by.css('create-subsidiary #subsidiary_create_cancel_button');
			var create_ErrorMessageForDuplicateSubCode=by.css('.server-error-msg>span:nth-child(2)');
			var create_CancelPopUpOKBtn=by.css('#canceldialog_ok_button');
			var create_CancelPopUpCancelBtn=by.css('#canceldialog_cancel_button');
			var flag=false;

            this.creatSubsidaryCodeIsPresent=function(){				
				element.all(create_Subsidary_code).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Subsidary_code is present');				
				});  
			};
   
            
			 this.creatSubsidaryDescriptionIsPresent=function(){			
				element.all(create_Subsidary_Description).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Subsidary_Description is present');				
				});  
			};
			
			 this.creatSubsidaryValidFromIsPresent=function(){				
				element.all(create_Subsidary_ValidFrom).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Subsidary_ValidFrom is present');				
				});  
			};
			
			 this.creatSubsidaryValidToIsPresent=function(){				
				element.all(create_Subsidary_ValidTo).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Subsidary_ValidTo is present');				
				});  
			};
			
			this.creatSubsidaryCancelButtonIsPresent=function(){				
				element.all(create_Subsidary_Cancel_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Subsidary_Cancel_button is present');				
				});  
			};
			
			
			this.creatSubsidarySaveButtonIsPresent=function(){			
				element.all(create_Subsidary_Save_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('create_Subsidary_Save_button is present');				
				});  
			};
			
			this.verifyTextOfErrorMessage=function(actualErrorMessage){
               element(create_ErrorMessageForDuplicateSubCode).getText().then(function (errorMessage) {
				   expect(errorMessage).toContain(actualErrorMessage);
				   console.log('error message='+errorMessage);
			   });
			};
			
			
			this.eneterTextInCreateSubsidaryCode=function(subsidaryCode)
				{
					element(create_Subsidary_code).sendKeys(subsidaryCode);
				};				
				
		    this.eneterTextInCreateSubsidaryDescription=function(subsidaryDescription)
				{
					element(create_Subsidary_Description).sendKeys(subsidaryDescription);
				};				
				
			this.eneterTextInValidDateFrom=function(dateFrom)
				{
					element(create_Subsidary_ValidFrom).sendKeys(dateFrom);
				};	
				
			this.eneterTextInValidDateTo=function(dateTo)
				{
					element(create_Subsidary_ValidTo).sendKeys(dateTo);
				};	
			
			this.clickOnSaveButton=function(){
				element(create_Subsidary_Save_button).click();
				return require('./subsidaryPageObject.js');
			};
			
			this.clickOnCancelButton=function(){
			    element(create_Subsidary_Cancel_button).click();
				//return require('./subsidaryPageObject.js');
			};
			this.clickOnCanacelPopUpOk=function(){
                element(create_CancelPopUpOKBtn).click();
			};

			this.clickOnCanacelPopUpCancel=function(){
                element(create_CancelPopUpCancelBtn).click();
				return require('./subsidaryPageObject.js');
			};
};
module.exports=new create_subsidary_page();