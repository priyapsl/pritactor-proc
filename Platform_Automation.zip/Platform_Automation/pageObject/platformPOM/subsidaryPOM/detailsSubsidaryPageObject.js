require('../subsidaryPOM/subsidaryPageObject.js');
require('../subsidaryPOM/editSubsidaryPageObject.js');

var details_subsidary_page=function(){
	
            var details_Subsidary_Edit_button=by.buttonText('Edit');
			var details_Subsidary_Back_button=by.buttonText('Cancel');
			var details_subsidaryCode_data=by.css('.form-group .row:nth-child(1) .col-sm-2 div');
			var details_subsidaryDescription_data=by.css('.form-group .row:nth-child(1) .col-sm-4 div');
			var flag=false;
			
			
			this.clickOnDetailsEditButton=function(){
				element(details_Subsidary_Edit_button).click();
				 return require('./editSubsidaryPageObject.js');
			};
			
			this.clickOnDetailsBackButton=function(){
			    element(details_Subsidary_Back_button).click();
				return require('./subsidaryPageObject.js');
			};
           
		   this.verifyTextOfSubsidaryCode=function(subsidaryCode){
               element(details_subsidaryCode_data).getText().then(function (data) {
				   expect(data).toBe(subsidaryCode);
				   console.log('Details Page subsidary code='+data);
			   });
		   };

           this.verifyTextOfSubsidaryDescription=function(description){
               element(details_subsidaryDescription_data).getText().then(function (data) {
				   expect(data).toBe(description);
				   console.log('Details Page Description='+data);
			   });
		   };

};
module.exports=new details_subsidary_page();
