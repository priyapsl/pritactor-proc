require('../subsidaryPOM/subsidaryPageObject.js');

var edit_subsidary_page=function(){
	
			var edit_Subsidary_code=by.css('edit-subsidiary input#subsidiary_edit_subcode');
			var edit_Subsidary_Description=by.css('edit-subsidiary input#subsidiary_edit_description');
			var edit_Subsidary_ValidFrom=by.css('edit-subsidiary input#subsidiary_edit_validfrom');
			var edit_Subsidary_ValidTo=by.css('edit-subsidiary input#subsidiary_edit_validto');
			var edit_Subsidary_Save_button=by.buttonText('Save');
			var edit_Subsidary_Cancel_button=by.css('edit-subsidiary #subsidiary_edit_cancel_button');
			var edit_SubsidaryCodeErrorMsg=by.css('edit-subsidiary .col-sm-2.has-error .error-msg>span:nth-child(2)');			
			var edit_DescriptionErrorMsg=by.css('edit-subsidiary .col-sm-4.has-error .error-msg>span:nth-child(2)');
			
			
			var flag=false;
            
			 this.editSubsidaryCodeIsPresent=function(){				
				element.all(edit_Subsidary_code).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Subsidary_code is present');				
				});  
			};
   
            
			 this.editSubsidaryDescriptionIsPresent=function(){				
				element.all(edit_Subsidary_Description).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Subsidary_Description is present');				
				});  
			};
			
			 this.editSubsidaryValidFromIsPresent=function(){				
				element.all(edit_Subsidary_ValidFrom).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Subsidary_ValidFrom is present');				
				}); 
			};
			
			 this.editSubsidaryValidToIsPresent=function(){				
				element.all(edit_Subsidary_ValidTo).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Subsidary_ValidTo is present');				
				}); 
			};
			
			this.editSubsidaryCancelButtonIsPresent=function(){
				
				element.all(edit_Subsidary_Cancel_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Subsidary_Cancel_button is present');				
				}); 
			};
			
			
			this.editSubsidarySaveButtonIsPresent=function(){				
				element.all(edit_Subsidary_Save_button).then(function(items) {
				expect(items.length).toBe(1);				
				console.log('edit_Subsidary_Save_button is present');				
				}); 
			};
			
			
			
			this.eneterTextInEditSubsidaryCode=function(subsidaryCode)
				{
					element(edit_Subsidary_code).sendKeys(subsidaryCode);
				};				
				
		    this.clearEditSubsidaryCode=function()
				{
					element(edit_Subsidary_code).clear();
				};
			
		    this.eneterTextInEditSubsidaryDescription=function(subsidaryDescription)
				{
					element(edit_Subsidary_Description).sendKeys(subsidaryDescription);
				};				
				
			this.eneterTextInValidDateFrom=function(dateFrom)
				{
					element(edit_Subsidary_ValidFrom).sendKeys(dateFrom);
				};	
				
			this.eneterTextInValidDateTo=function(dateTo)
				{
					element(edit_Subsidary_ValidTo).sendKeys(dateTo);
				};	
			
			this.clickOnSaveButton=function(){
				element(edit_Subsidary_Save_button).click();
				return require('./subsidaryPageObject.js');
			};
			
			this.clickOnCancelButton=function(){
			    element(edit_Subsidary_Cancel_button).click();
				return require('./subsidaryPageObject.js');
			};
};
module.exports=new edit_subsidary_page();