describe('Products page', function() {
	
	                    beforeAll(function() {
								var loginData=require('../../../testData/loginPage.json');
								var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
								browser.ignoreSynchronization = true;
								browser.waitForAngularEnabled(false);
								browser.get(loginData.authentication.login.url);
								browser.sleep(5000).then(function(){console.log("Sleep after url launched")});

								//var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
								console.log('Cloooo--11')
								//***********************************************************************
								/*login_page.login();
                                browser.sleep(5000).then(function(){console.log("Sleep after url launched")});*/

						});
						
	
	
						beforeEach(function(){
						/* browser.get('http://10.51.232.73:3000/platform/master-data/subsidiaries');
						  //protractor.browser.ignoreSynchronization = true;
						  var loginData=require('../../../testData/loginPage.json');
						  var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');*/
						  var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
						  //***************************************************************************************
						  var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
						  login_page.login();
                                browser.sleep(5000).then(function(){console.log("Sleep after url launched")});


						 /* browser.waitForAngularEnabled(false);
					      // var b1=browser.forkNewDriverInstance();
						  
						  browser.get(loginData.authentication.login.url); 
							browser.driver.sleep(5000);
							login_page.enterUserName(loginData.authentication.login.username);
							login_page.enterPassword(loginData.authentication.login.password);
							login_page.clickLoginButton();
							 browser.driver.sleep(5000);*/
							//element(by.css('.sli-large.icon-menu')).click();
							home_page.clickBreadCrum();
							browser.driver.sleep(5000);
							home_page.clickProdDirectlyOrClickMasterDataFirst();
							//browser.driver.navigate().refresh();
							 browser.sleep(20000).then(function(){console.log("clicked on Products option in Master Data")});
							//ement(by.cssContainingText('.section>a>h3>span','Subsidiaries')).click();							
						
												
						});
						
						
					   afterEach(function(){
						 /*  var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
						   home_page.clickBreadCrum();
						   browser.driver.sleep(5000);*/
						   element(by.css('.header-icon-panel .icon-logout')).click();
						   browser.sleep(10000).then(function(){console.log("Clicked on logout Button")});
					   });

				  it('Create Sample data1 For Products:Create Subsidiary',function () {
						  console.log('Product management started execution');
						  var testData=require('../../../testData/productsPageData.json');
						 // var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
                          	 var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
							  var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
							 var status = false;
				        
							/**Sample subsidiary created for this */		 
							 element(by.cssContainingText('.section>a>h3>span', 'Subsidiaries')).click();							
							 browser.sleep(10000).then(function(){console.log("clicked on Subsidiaries option in Master Data")});
							 var subsidary_CreatePage=subsidary_page.clickOnCreateButton();
							 browser.sleep(5000).then(function(){console.log("Create Button Clicked")});							
							 
							 subsidary_CreatePage.eneterTextInCreateSubsidaryCode(testData.Products.SampleIssuer.SubsidiaryCode);
							 subsidary_CreatePage.eneterTextInCreateSubsidaryDescription(testData.Products.SampleIssuer.Description);
							 subsidary_CreatePage.eneterTextInValidDateFrom(testData.Products.SampleIssuer.validFrom);
							 subsidary_CreatePage.eneterTextInValidDateTo(testData.Products.SampleIssuer.validTo);
							 subsidary_page=subsidary_CreatePage.clickOnSaveButton();	
							 browser.sleep(20000).then(function(){console.log("clicked on Save Btn")});
                             console.log('Sample subsidiary created successfully');

					 });


					   it('Create Sample data For Issuers',function () {

						  console.log('Issuer_Managemen sampkle Data2 started execution');
						   var testData=require('../../../testData/productsPageData.json');	
						 // var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
                          	 var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
							 var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
							 var status = false;
				        
					
							 element(by.cssContainingText('.section>a>h3>span', 'Issuers')).click();							
							 browser.sleep(15000).then(function(){console.log("clicked on Issuer option in Master Data")});                            
                           

                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                              var create_Issuer= issuer_page.clickOnIssuerCreateButton();
							 browser.sleep(5000).then(function(){console.log("Clicked on Issuer create button")});
                             create_Issuer.eneterTextInCreateIssuerCode(testData.Products.SampleIssuer.issuerCode);
							 create_Issuer.eneterTextInCreateIssuerName(testData.Products.SampleIssuer.issuerName);							
							 create_Issuer.eneterTextInValidDateFrom(testData.Products.SampleIssuer.validFrom);
							 create_Issuer.eneterTextInValidDateTo(testData.Products.SampleIssuer.validTo);
                             create_Issuer.clickOnIssuerSubsidiaryDrpDwn();
							  browser.sleep(5000).then(function(){console.log("Issuer Subisdiary Drp Dwn")});
							 create_Issuer.selectParticularIssuerSubsidiaryCode(testData.Products.SampleIssuer.SubsidiaryCode);

                             create_Issuer.clickOnDefaultLanguageDrpDwn();
							  browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
                              create_Issuer.selectParticularLanguage(testData.Products.SampleIssuer.language);
                             create_Issuer.eneterTextInNotificationRetentionPeriod(testData.Products.SampleIssuer.notificationRetentionPeriod);
                        
                             create_Issuer.clickOnSaveButton();
							  browser.sleep(25000).then(function(){console.log("Click On save btn")});
						



					 });
  

					 it('Sample Data Creation for testing ',function () {
						  console.log('sample data creation');
						  var testData=require('../../../testData/productsPageData.json');	
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');

						  for (var i in testData.Products.SampleTestData) {   							

								var create_ProdPage= products_page.clickOnProdCreateButton();
								browser.sleep(5000).then(function(){console.log("Clicked on Create button")});
								create_ProdPage.eneterTextInCreateProductCode(testData.Products.SampleTestData[i].ProductCode);
								create_ProdPage.eneterTextInCreateProductDescription(testData.Products.SampleTestData[i].description);
								create_ProdPage.eneterTextInValidDateFrom(testData.Products.SampleTestData[i].validFrom);
								create_ProdPage.eneterTextInValidDateTo(testData.Products.SampleTestData[i].validTo);
								create_ProdPage.clickOnIssuerDrpDwn();
								browser.sleep(5000).then(function(){console.log("Clicked on Issuer DropDwn")}); 
								// create_ProdPage.eneterTextInIssuerInputBox(testData.Products.Platform_Search_Product_69.issuerCode);
								//  browser.sleep(5000).then(function(){console.log("Text entered in Issuer DropDwn")})
								create_ProdPage.selectParticularIssuerCode(testData.Products.SampleTestData[i].issuerCode);
								browser.sleep(5000).then(function(){console.log("select particular issuer")}); 
								var products_page= create_ProdPage.clickOnSaveButton();
								browser.sleep(25000).then(function(){console.log("Clicked on Save Button ")});
						}
					 });
					  
					
			      it('Platform_Search_Product_05:Verify that the user navigated to search or landing page of the Manage G&D Products', function() {
						 console.log('Platform_Search_Product_05 started execution');
						  var testData=require('../../../testData/productsPageData.json');	
						// expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);	
						 //console.log('Url='+browser.getCurrentUrl());	

								browser.getCurrentUrl().then(function(url) {
										console.log("URL= "+ url);
										expect(url).toContain(testData.Products.Platform_Search_Product_05.expected);	
									});

					});

				   it('Platform_Search_Product_06:Verify the options for managing Products on Master Data Page', function() {
						 console.log('Platform_Search_Product_06 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');	
						  products_page.prodfilterButtonIsPresent();
						  products_page.prodExportOptionIsPresent();
						  products_page.prodCreateButtonIsPresent();
						  console.log('Vaerify the element on Product screen');	  
									
					  });

					   it('Platform_Search_Product_08:Verify that by default Filter Pane is Collapsed.', function() {
						 console.log('Platform_Search_Product_08 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');	

						
						  products_page.filter_Apply_ButtonIsNotPresent();
						  products_page.filter_Clear_ButtonIsNotPresent();						 
						  console.log('Vaerify by default Filter Pane is Collapsed');	  
									
					  });

					  it('Platform_Search_Product_09:Verify elements of  Filter Pane ', function() {
						 console.log('Platform_Search_Product_08 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');	

						  products_page.clickOnProdFilterButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});
						  products_page.filter_Apply_ButtonIsPresent();
						  products_page.filter_Clear_ButtonIsPresent();
						  products_page.filter_Products_drpdwnIsPresent();
						  products_page.filter_DescriptionIsPresent();
						  products_page.filter_Issuer_drpdwnIsPresent();

						  console.log('Verify elements of  Filter Pane ');	  
									
					  });

					 it('Platform_Search_Product_10:Verify the Search or Filter Button functionality', function() {
						 console.log('Platform_Search_Product_10 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');						
						  products_page.clickOnProdFilterButton();
						   browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});
						  products_page.filter_Clear_ButtonIsPresent();
						  products_page.filter_Apply_ButtonIsPresent();
						  products_page.filter_Products_drpdwnIsPresent();
						  products_page.filter_DescriptionIsPresent();
						  products_page.filter_Issuer_drpdwnIsPresent();


					  }); 

					   it('Platform_Search_Product_11:Verify the default page for managing Products on Master Data Page', function() {
						 console.log('Platform_Search_Product_11 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');

						  products_page.checkBoxToSelectAllIsPresent();
						  products_page.productCodeIsPresent();
						  products_page.prod_DescriptionIsPresent();
						  products_page.prod_IssuerIsPresent();
						  products_page.valid_fromIsPresent();
						  products_page.valid_ToIsPresent();
						  products_page.updatedByIsPresent();
						  products_page.updatedOnIsPresent();		 


					  });

                    it('Platform_Search_Product_13:Verify the user clear selected search/filter criteria', function() {
						 console.log('Platform_Search_Product_13 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
                          var testData=require('../../../testData/productsPageData.json');

						   products_page.clickOnProdFilterButton();
						   browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						   products_page.eneterTextInDescriptionBox(testData.Products.Platform_Search_Product_13.description);
						   products_page.clickOnFilterProductsCodeDrpdwn();
						   browser.sleep(5000).then(function(){console.log("Clicked on Filter product code dropdown")});						   
						   products_page.enterTextInFilterProductCodeDrpDown(testData.Products.Platform_Search_Product_13.productCode);
						   
						  
						  products_page.clickOnFilterClearButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter clear Btn")});
						  products_page.clickOnFilterProductsCodeDrpdwn();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter product code dropdown")});	
						  products_page.getTextOfFilterSubsidaryCodeDrpdown();	
						  products_page.getTextOfFilterDescription();


					  });

					   


					  
					  it('Platform_Search_Product_15:Verify that user closes Filter pane for Products', function() {
						 console.log('Platform_Search_Product_15 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						    var testData=require('../../../testData/productsPageData.json');
						  products_page.clickOnProdFilterButton();
						   browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						  products_page.filter_Clear_ButtonIsPresent();
						  products_page.filter_Apply_ButtonIsPresent();
						  products_page.filter_Products_drpdwnIsPresent();
						  products_page.filter_DescriptionIsPresent();
						  products_page.filter_Issuer_drpdwnIsPresent();

						  products_page.clickfilter_CloseIcon();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter close ICon")});
                          products_page.filter_Apply_ButtonIsNotPresent();
						  products_page.filter_Clear_ButtonIsNotPresent();
						  console.log('Filter close icon closed properly');
					  }); 

					it('Platform_Search_Product_16:Verify the selection of search criteria option for managing Products on Master Data Page', function() {
						 console.log('Platform_Search_Product_16 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						    var testData=require('../../../testData/productsPageData.json');
						  products_page.clickOnProdFilterButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});						 
						  products_page.filter_Products_drpdwnIsPresent();
						  products_page.filter_DescriptionIsPresent();
						  products_page.filter_Issuer_drpdwnIsPresent();
						  
					  }); 

					   it('Platform_Search_Product_17:Verify that Product Code dropdown displays all  Product Codes available in the system.', function() {
						 console.log('Platform_Search_Product_17 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						    var testData=require('../../../testData/productsPageData.json');
						  products_page.clickOnProdFilterButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						   products_page.clickOnFilterProductsCodeDrpdwn();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});						 
						   products_page.elementsInProdCodeDrpDown();
						  
					  }); 



                      
					   
					it('Platform_Search_Product_19:Verify search functionality by selecting a Product Code ', function() {
						 console.log('Platform_Search_Product_15 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						    var testData=require('../../../testData/productsPageData.json');
						  products_page.clickOnProdFilterButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						  products_page.clickOnFilterProductsCodeDrpdwn();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter product code dropdown")});
						  products_page.selectFirstElementFromDropDown();
						  browser.sleep(5000).then(function(){console.log("Select 1st element from dropdown")});
						  products_page.clickOnFilterApplyButton();
						  browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
						  products_page.rowCountInTable();

					  });     

					 it('Platform_Search_Product_20:Verify search functionality for partial Product Code ', function() {
						 console.log('Platform_Search_Product_20 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						  var testData=require('../../../testData/productsPageData.json');
						  products_page.clickOnProdFilterButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						  products_page.clickOnFilterProductsCodeDrpdwn();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter product code dropdown")});
						  console.log('Partial='+testData.Products.Platform_Search_Product_20.partial_ProductCode);
						  console.log('Full='+testData.Products.Platform_Search_Product_20.product_code);
						  products_page.enterTextInFilterProductCodeDrpDown(testData.Products.Platform_Search_Product_20.partial_ProductCode);
						 browser.sleep(5000).then(function(){console.log("entern text in Prodcut code input box")});
						  products_page.selectParticularProdCode(testData.Products.Platform_Search_Product_20.product_code);
						//  products_page.selectFirstElementFromDropDown();
						  browser.sleep(5000).then(function(){console.log("Select 1st element from dropdown")});
						  products_page.clickOnFilterApplyButton();
						  browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
						  products_page.rowCountInTable();

					  });    
					  

					   it('Platform_Search_Product_22:Verify Suggest Word functionality for Product Code field.', function() {
						 console.log('Platform_Search_Product_22 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						  var testData=require('../../../testData/productsPageData.json');
						  products_page.clickOnProdFilterButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						  products_page.clickOnFilterProductsCodeDrpdwn();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter product code dropdown")});
						  console.log('Partial='+testData.Products.Platform_Search_Product_22.partial_ProductCode);						 
						  products_page.enterTextInFilterProductCodeDrpDown(testData.Products.Platform_Search_Product_22.partial_ProductCode);
						  browser.sleep(5000).then(function(){console.log("entern text in Prodcut code input box")});
						  products_page.productCodeContaingText(testData.Products.Platform_Search_Product_22.partial_ProductCode);
						 // products_page.selectFirstElementFromDropDown();
						  browser.sleep(5000).then(function(){console.log("Select 1st element from dropdown")}); 
						 
					  }); 

					it('Platform_Search_Product_23:Suggest Word functionality when entered Issuer Product Code is not available in the system..', function() {
						 console.log('Platform_Search_Product_23 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						  var testData=require('../../../testData/productsPageData.json');
						  products_page.clickOnProdFilterButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						  products_page.clickOnFilterProductsCodeDrpdwn();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter product code dropdown")});
						  console.log('Partial='+testData.Products.Platform_Search_Product_22.partial_ProductCode);						 
						  products_page.enterTextInFilterProductCodeDrpDown(testData.Products.Platform_Search_Product_23.invalid_ProductCode);
						  browser.sleep(5000).then(function(){console.log("entern text in Prodcut code input box")});						  
						  products_page.productCodeNotPresentInDropDown();

						 // browser.sleep(5000).then(function(){console.log("Select 1st element from dropdown")}); 
						 
					  }); 


					  it('Platform_Search_Product_24:Verify Search Functionality using Description', function() {
						 console.log('Platform_Search_Product_24 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						  var testData=require('../../../testData/productsPageData.json');
						  products_page.clickOnProdFilterButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						  products_page.eneterTextInDescriptionBox(testData.Products.Platform_Search_Product_24.validProduct_Description);
						   browser.sleep(5000).then(function(){console.log("text entered in Description box")});						
						  console.log('Description='+testData.Products.Platform_Search_Product_24.validProduct_Description);						 
						  products_page.clickOnFilterApplyButton();
						  browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
						  products_page.productDescriptionContaingText(testData.Products.Platform_Search_Product_24.validProduct_Description);					 
					  });   

					
					it('Platform_Search_Product_25:Verify search functionality using Description that do not belong to any Issuer.', function() {
						 console.log('Platform_Search_Product_24 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						  var testData=require('../../../testData/productsPageData.json');
						  products_page.clickOnProdFilterButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						  products_page.eneterTextInDescriptionBox(testData.Products.Platform_Search_Product_25.InValidProduct_Description);
						   browser.sleep(5000).then(function(){console.log("text entered in Description box")});						
						  console.log('Description='+testData.Products.Platform_Search_Product_24.validProduct_Description);						 
						  products_page.clickOnFilterApplyButton();
						  browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
						  products_page.firstRowFromTableNotPresent();					 
					  });     

					  it('Platform_Search_Product_26:Verify Search Functionality using Description for which valid issuer doesnot exist', function() {
						 console.log('Platform_Search_Product_26 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						  var testData=require('../../../testData/productsPageData.json');
						  products_page.clickOnProdFilterButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						  products_page.eneterTextInDescriptionBox(testData.Products.Platform_Search_Product_26.validProduct_Description);
						  browser.sleep(5000).then(function(){console.log("text entered in Description box")});
						  products_page.clickOnFilterIssuerCodeDrpdwn();
                          browser.sleep(5000).then(function(){console.log("clicked on issuer drpDwn")});
                          products_page.selectParticularIssuer(testData.Products.Platform_Search_Product_26.invalidAssociateIssuer);

						  console.log('Description='+testData.Products.Platform_Search_Product_24.validProduct_Description);						 
						  products_page.clickOnFilterApplyButton();
						  browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
						  products_page.firstRowFromTableNotPresent();

					  });  
                    

					


					   it('Platform_Search_Product_32:Verify that products dropdown displays all products available in the system.', function() {
						 console.log('Platform_Search_Product_32 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						  var testData=require('../../../testData/productsPageData.json');
						  products_page.clickOnProdFilterButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						  products_page.clickOnFilterIssuerCodeDrpdwn();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Issuer dropdown")});
						 				 
						  products_page.elementsPresentInDropDown();	  
						 
					  });  

					  it('Platform_Search_Product_33:Verify that user is able to select a issuer Code from issuer dropdown..', function() {
						 console.log('Platform_Search_Product_33 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						  var testData=require('../../../testData/productsPageData.json');
						  products_page.clickOnProdFilterButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						  products_page.clickOnFilterIssuerCodeDrpdwn();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Issuer dropdown")});
						  products_page.selectParticularIssuer(testData.Products.Platform_Search_Product_33.validIssuerCode);
						  browser.sleep(5000).then(function(){console.log("Sel;ected 1st Issuer from dropdown")});
                          products_page.clickOnFilterApplyButton();
						  browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
						  products_page.rowCountInTable();						 
					  });  


					  it('Platform_Search_Product_34:Verify search functionality by selecting a issuer Code from Issuer dropdown..', function() {
						 console.log('Platform_Search_Product_34 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						  var testData=require('../../../testData/productsPageData.json');
						  products_page.clickOnProdFilterButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						  products_page.clickOnFilterIssuerCodeDrpdwn();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Issuer dropdown")});
						  products_page.selectParticularIssuer(testData.Products.Platform_Search_Product_34.validIssuerCode);
						  browser.sleep(5000).then(function(){console.log("Selected  Issuer from dropdown")});
                          products_page.clickOnFilterApplyButton();
						  browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
						  products_page.rowCountInTable();				  
						 
					  });  

					  it('Platform_Search_Product_35:Verify partial search for Issuer.', function() {
						 console.log('Platform_Search_Product_35 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						  var testData=require('../../../testData/productsPageData.json');
						  products_page.clickOnProdFilterButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						  products_page.clickOnFilterIssuerCodeDrpdwn();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter product code dropdown")});
						  console.log('Partial='+testData.Products.Platform_Search_Product_35.partialIssuerCode);	
						  products_page.enterTextInFilterIssuerDrpDown(testData.Products.Platform_Search_Product_35.partialIssuerCode);					 
						  //products_page.enterTextInFilterProductCodeDrpDown(testData.Products.Platform_Search_Product_22.partial_ProductCode);
						  browser.sleep(5000).then(function(){console.log("entern text in Prodcut code input box")});
						  products_page.productCodeContaingText(testData.Products.Platform_Search_Product_35.partialIssuerCode);
						 // products_page.selectFirstElementFromDropDown();
						  browser.sleep(5000).then(function(){console.log("Select 1st element from dropdown")}); 						 
					  }); 

					it('Platform_Search_Product_36:Verify search functionality using issuer that do not belong to any Issuer.', function() {
						 console.log('Platform_Search_Product_36 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						  var testData=require('../../../testData/productsPageData.json');
						  products_page.clickOnProdFilterButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						  products_page.clickOnFilterIssuerCodeDrpdwn();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter product code dropdown")});
						  console.log('Partial='+testData.Products.Platform_Search_Product_36.inValidIssuerCode);	
						  products_page.enterTextInFilterIssuerDrpDown(testData.Products.Platform_Search_Product_36.inValidIssuerCode);					 
						  //products_page.enterTextInFilterProductCodeDrpDown(testData.Products.Platform_Search_Product_22.partial_ProductCode);
						  browser.sleep(5000).then(function(){console.log("entern text in Prodcut code input box")});
						   products_page.productCodeNotPresentInDropDown();
						  browser.sleep(5000).then(function(){console.log("No issuer present in Drop down")}); 						 
					  }); 


                    it('Platform_Search_Product_66:Verify the details of creation of new Product', function() {

                          console.log('Platform_Search_Product_66 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						  var testData=require('../../../testData/productsPageData.json');
						  var create_ProdPage= products_page.clickOnProdCreateButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						  create_ProdPage.createProductCodeIsPresent();
						  create_ProdPage.creatProductDescriptionIsPresent();
						  create_ProdPage.creatProductValidFromIsPresent();
						  create_ProdPage.creatProductValidToIsPresent();
						  create_ProdPage.creatProductCancelButtonIsPresent();
						  create_ProdPage.creatProductSaveButtonIsPresent();						  
					  });

					  xit('Platform_Search_Product_68: if any mandatory field/s is/are missing, system should display user friendly message', function() {

                          console.log('Platform_Search_Product_68 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						  var testData=require('../../../testData/productsPageData.json');
						  var create_ProdPage= products_page.clickOnProdCreateButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						  create_ProdPage.eneterTextInCreateProductCode(testData.Products.Platform_Search_Product_69.ProductCode);
						  create_ProdPage.eneterTextInCreateProductDescription(testData.Products.Platform_Search_Product_69.description);
						  create_ProdPage.eneterTextInValidDateFrom(testData.Products.Platform_Search_Product_69.validFrom);
						  create_ProdPage.eneterTextInValidDateTo(testData.Products.Platform_Search_Product_69.validTo);						  
						   create_ProdPage.clickOnSaveButton();
						 browser.sleep(25000).then(function(){console.log("Clicked on Save Button ")});
						

					  });

					  it('Platform_Search_Product_69,70,73:Verify the users provision to submit the creation request and Newly created Product record should be displayed in Product Management grid ', function() {

                          console.log('Platform_Search_Product_69,70,73 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						  var testData=require('../../../testData/productsPageData.json');
						  var create_ProdPage= products_page.clickOnProdCreateButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						  create_ProdPage.eneterTextInCreateProductCode(testData.Products.Platform_Search_Product_69.ProductCode);
						  create_ProdPage.eneterTextInCreateProductDescription(testData.Products.Platform_Search_Product_69.description);
						  create_ProdPage.eneterTextInValidDateFrom(testData.Products.Platform_Search_Product_69.validFrom);
						  create_ProdPage.eneterTextInValidDateTo(testData.Products.Platform_Search_Product_69.validTo);
						  create_ProdPage.clickOnIssuerDrpDwn();
						  browser.sleep(5000).then(function(){console.log("Clicked on Issuer DropDwn")}); 
						 // create_ProdPage.eneterTextInIssuerInputBox(testData.Products.Platform_Search_Product_69.issuerCode);
						//  browser.sleep(5000).then(function(){console.log("Text entered in Issuer DropDwn")})
						  create_ProdPage.selectParticularIssuerCode(testData.Products.Platform_Search_Product_69.issuerCode);
						  browser.sleep(5000).then(function(){console.log("select particular issuer")}); 
						 var products_page= create_ProdPage.clickOnSaveButton();
						browser.sleep(25000).then(function(){console.log("Clicked on Save Button ")});
						products_page.clickOnProdFilterButton();	
						 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button ")});
						 products_page.clickOnFilterProductsCodeDrpdwn();
						 browser.sleep(10000).then(function(){console.log("Clicked on Productcode Button ")});
						products_page.selectParticularProdCode(testData.Products.Platform_Search_Product_69.ProductCode);
						browser.sleep(5000).then(function(){console.log("Selected particular Productcode ")});	
						products_page.clickOnFilterApplyButton();
						 browser.sleep(10000).then(function(){console.log("Clicked on Filter Apply Button ")});
						products_page.rowCountInTable();
						products_page.getTextOfFirstRowUpdatedBy();
						products_page.getTextOfFirstRowUpdatedOn();

					  });

					  it('Platform_Search_Product_78,80:Verify the user cancel the create request', function() {

                          console.log('Platform_Search_Product_78 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						  var testData=require('../../../testData/productsPageData.json');
						  var create_ProdPage= products_page.clickOnProdCreateButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						  create_ProdPage.eneterTextInCreateProductCode(testData.Products.Platform_Search_Product_78.ProductCode);
						  create_ProdPage.eneterTextInCreateProductDescription(testData.Products.Platform_Search_Product_78.description);
						  create_ProdPage.eneterTextInValidDateFrom(testData.Products.Platform_Search_Product_78.validFrom);
						  create_ProdPage.eneterTextInValidDateTo(testData.Products.Platform_Search_Product_78.validTo);
						  create_ProdPage.clickOnIssuerDrpDwn();
						  browser.sleep(5000).then(function(){console.log("Clicked on Issuer DropDwn")}); 
						 // create_ProdPage.eneterTextInIssuerInputBox(testData.Products.Platform_Search_Product_69.issuerCode);
						//  browser.sleep(5000).then(function(){console.log("Text entered in Issuer DropDwn")})
						  create_ProdPage.selectParticularIssuerCode(testData.Products.Platform_Search_Product_78.issuerCode);
						  browser.sleep(5000).then(function(){console.log("select particular issuer")}); 
						create_ProdPage.clickOnCancelButton();
						create_ProdPage.verifyCancelPopUpMessage();
						browser.sleep(5000).then(function(){console.log("Clicked on Save Button ")});	
						var products_page=create_ProdPage.clickOnCanacelPopUpOk();
						browser.sleep(3000).then(function(){console.log("Clicked on Popuo OK Button ")});	
						products_page.clickOnProdFilterButton();	
						 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button ")});
						 products_page.clickOnFilterProductsCodeDrpdwn();
						 browser.sleep(5000).then(function(){console.log("Clicked on Productcode Button ")});
						products_page.enterTextInFilterProductCodeDrpDown(testData.Products.Platform_Search_Product_78.ProductCode);
						browser.sleep(5000).then(function(){console.log("Selected particular Productcode ")});	
						products_page.productCodeNotPresentInDropDown();					
					  });


					  it('Platform_Search_Product_84:Verify length of Product code 30 chars is accpetable while creation of product code', function() {

                          console.log('Platform_Search_Product_84 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						  var testData=require('../../../testData/productsPageData.json');
						  var create_ProdPage= products_page.clickOnProdCreateButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						  var prodCode=testData.Products.Platform_Search_Product_84.ProductCode;
						  var length=prodCode.length;
						  console.log('Length of string='+length);
						  expect(length).toBe(30);
						  create_ProdPage.eneterTextInCreateProductCode(testData.Products.Platform_Search_Product_84.ProductCode);
						  create_ProdPage.eneterTextInCreateProductDescription(testData.Products.Platform_Search_Product_84.description);
						  create_ProdPage.eneterTextInValidDateFrom(testData.Products.Platform_Search_Product_84.validFrom);
						  create_ProdPage.eneterTextInValidDateTo(testData.Products.Platform_Search_Product_84.validTo);
						  create_ProdPage.clickOnIssuerDrpDwn();
						  browser.sleep(5000).then(function(){console.log("Clicked on Issuer DropDwn")}); 
						 // create_ProdPage.eneterTextInIssuerInputBox(testData.Products.Platform_Search_Product_69.issuerCode);
						//  browser.sleep(5000).then(function(){console.log("Text entered in Issuer DropDwn")})

						  create_ProdPage.selectParticularIssuerCode(testData.Products.Platform_Search_Product_84.issuerCode);
						  browser.sleep(5000).then(function(){console.log("select particular issuer")}); 
						 var products_page= create_ProdPage.clickOnSaveButton();
						 browser.sleep(25000).then(function(){console.log("Clicked on Save Button ")});
						 products_page.clickOnProdFilterButton();	
						 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button ")});
						 products_page.clickOnFilterProductsCodeDrpdwn();
						 browser.sleep(5000).then(function(){console.log("Clicked on Productcode Button ")});
						 products_page.selectParticularProdCode(testData.Products.Platform_Search_Product_84.ProductCode);
						 browser.sleep(5000).then(function(){console.log("Selected particular Productcode ")});	
						 products_page.clickOnFilterApplyButton();
						 browser.sleep(10000).then(function(){console.log("Clicked on Filter Apply Button ")});
						 products_page.getTextOfFirstRowProductCode(testData.Products.Platform_Search_Product_84.ProductCode);					

					  });

                     
					  it('Platform_Search_Product_85:Verify length of Product code greter than 30 chars is not accpetable while creation of product code', function() {

                          console.log('Platform_Search_Product_84 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						  var testData=require('../../../testData/productsPageData.json');
						  var create_ProdPage= products_page.clickOnProdCreateButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						  var prodCode=testData.Products.Platform_Search_Product_85.ProductCode;
						  var length=prodCode.length;
						  console.log('Length of string='+length);
						  expect(length>30).toBe(true);
						  create_ProdPage.eneterTextInCreateProductCode(testData.Products.Platform_Search_Product_85.ProductCode);
						  create_ProdPage.eneterTextInCreateProductDescription(testData.Products.Platform_Search_Product_85.description);
						  create_ProdPage.eneterTextInValidDateFrom(testData.Products.Platform_Search_Product_85.validFrom);
						  create_ProdPage.eneterTextInValidDateTo(testData.Products.Platform_Search_Product_85.validTo);
						  create_ProdPage.clickOnIssuerDrpDwn();
						  browser.sleep(5000).then(function(){console.log("Clicked on Issuer DropDwn")}); 
						 // create_ProdPage.eneterTextInIssuerInputBox(testData.Products.Platform_Search_Product_69.issuerCode);
						//  browser.sleep(5000).then(function(){console.log("Text entered in Issuer DropDwn")})

						  create_ProdPage.selectParticularIssuerCode(testData.Products.Platform_Search_Product_84.issuerCode);
						  browser.sleep(5000).then(function(){console.log("select particular issuer")}); 
						 var products_page= create_ProdPage.clickOnSaveButton();
						 browser.sleep(25000).then(function(){console.log("Clicked on Save Button ")});
						 products_page.clickOnProdFilterButton();	
						 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button ")});						 
						 products_page.eneterTextInDescriptionBox(testData.Products.Platform_Search_Product_85.description);
						 browser.sleep(5000).then(function(){console.log("Selected particular Productcode ")});	
						 products_page.clickOnFilterApplyButton();
						 browser.sleep(10000).then(function(){console.log("Clicked on Filter Apply Button ")});
						 products_page.verifyLengthOfProdCode();					

					  });


					  

					  it('Platform_Search_Product_109:Verify that Edit icon is available for each Product record.', function() {

                          console.log('Platform_Search_Product_109 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');	
						  var testData=require('../../../testData/productsPageData.json');					 
						 products_page.checkEditButtonForEachProduct();
						  		

					  });

					  it('Platform_Search_Product_110:Verify the user with appropriate permission (Manage G&D Products), able to update new Product ', function() {

                          console.log('Platform_Search_Product_110 started execution');
						  var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
						  var testData=require('../../../testData/productsPageData.json');										 
						 products_page.clickOnFirstRowsEditButton();
						 browser.sleep(5000).then(function(){console.log("Click on first edit Button ")});			


							  	browser.getCurrentUrl().then(function(url) {
										console.log("URL= "+ url);
										expect(url).toContain(testData.Products.Platform_Search_Product_110.urlContain);	
									});	

					  });

					it('Platform_Search_Product_111:Verify fields of update screen', function() {

							console.log('Platform_Search_Product_111 started execution');
							var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
							var testData=require('../../../testData/productsPageData.json');		
													 
							var edit_page=products_page.clickOnFirstRowsEditButton();
							browser.sleep(5000).then(function(){console.log("Click on first edit Button ")});
						    edit_page.editProductCodeIsPresent();
							edit_page.editProductDescriptionIsPresent();
							edit_page.editProductIssuerDrpdwnIsPresent();
							edit_page.editProductValidFromIsPresent();
							edit_page.editProductValidToIsPresent();
							edit_page.editProductCancelButtonIsPresent();
							edit_page.editProductSaveButtonIsPresent();
							console.log('Verify elements of Edit product page');		
                          
						});

                      

					  xit('Platform_Search_Product_113:Verify if any mandatory field missing, system should display user friendly message', function() {

							console.log('Platform_Search_Product_113 started execution');
							var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
							var testData=require('../../../testData/productsPageData.json');	

							products_page.clickOnProdFilterButton();
					    	browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						    products_page.clickOnFilterProductsCodeDrpdwn();
							browser.sleep(5000).then(function(){console.log("Click on filter code dropdwn")});
							products_page.selectParticularProdCode(testData.Products.Platform_Search_Product_113.OriginalProductCode);
							browser.sleep(5000).then(function(){console.log("Select particular prod code from drop down ")});
							products_page.clickOnFilterApplyButton();
							browser.sleep(10000).then(function(){console.log("click on filter Apply Button ")});
							var edit_page=products_page.clickOnFirstRowsEditButton();
							browser.sleep(5000).then(function(){console.log("Click on first edit Button ")});
						    edit_page.clearEditProductDescription();
							browser.sleep(5000).then(function(){console.log("Click clear prod Description ")});
							edit_page.clickOnClearSaveButton();
							browser.sleep(5000).then(function(){console.log("Click on Save  Button ")});
							edit_page.verifyProductDescriptionErrorMsg(testData.Products.Platform_Search_Product_113.ErrorMessage);
							expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_113.urlContain);
						})  ;
					

 

                        it('Platform_Search_Product_114,115,116:Verify the user friendly message after submitted the updated request successfully', function() {

							console.log('Platform_Search_Product_114 started execution');
							var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
							var testData=require('../../../testData/productsPageData.json');	

							products_page.clickOnProdFilterButton();
					    	browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						    products_page.clickOnFilterProductsCodeDrpdwn();
							browser.sleep(5000).then(function(){console.log("Click on filter code dropdwn")});
							products_page.selectParticularProdCode(testData.Products.Platform_Search_Product_114.OriginalProductCode);
							browser.sleep(5000).then(function(){console.log("Select particular prod code from drop down ")});
							products_page.clickOnFilterApplyButton();
							browser.sleep(10000).then(function(){console.log("click on filter Apply Button ")});
							var edit_page=products_page.clickOnFirstRowsEditButton();
							browser.sleep(5000).then(function(){console.log("Click on first edit Button ")});
						    edit_page.clearEditProductCode();
							browser.sleep(5000).then(function(){console.log("Click clear prod Description ")});
							edit_page.eneterTextInEditProductCode(testData.Products.Platform_Search_Product_114.NewProductCode);
							var products_page=edit_page.clickOnSaveButton();
							browser.sleep(25000).then(function(){console.log("Click on Save  Button ")});
							  products_page.clickOnFilterClearButton();
							browser.sleep(5000).then(function(){console.log("Click On Clear Button")});
							 products_page.clickOnFilterProductsCodeDrpdwn();
							browser.sleep(5000).then(function(){console.log("Click on filter code dropdwn")});
							products_page.selectParticularProdCode(testData.Products.Platform_Search_Product_114.NewProductCode);
							browser.sleep(5000).then(function(){console.log("Select new  prod code from drop down ")});
							products_page.clickOnFilterApplyButton();
							browser.sleep(10000).then(function(){console.log("Click On Filter Apply Button")});
							products_page.rowCountInTable();
                            products_page.clickOnFilterClearButton();
							browser.sleep(5000).then(function(){console.log("Click On Clear Button")});
                            products_page.clickOnFilterProductsCodeDrpdwn();
							browser.sleep(5000).then(function(){console.log("Click on filter code dropdwn")});
							products_page.isParticularProductCodeNotPresntDropDown(testData.Products.Platform_Search_Product_114.OriginalProductCode);
						
						});


                   it('Platform_Search_Product_119:Verify updating of text pattern of Product Code(30 chars)', function() {

							console.log('Platform_Search_Product_119 started execution');
							var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
							var testData=require('../../../testData/productsPageData.json');	

							products_page.clickOnProdFilterButton();
					    	browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						    products_page.clickOnFilterProductsCodeDrpdwn();
							browser.sleep(5000).then(function(){console.log("Click on filter code dropdwn")});
							products_page.selectParticularProdCode(testData.Products.Platform_Search_Product_119.OriginalProductCode);
							browser.sleep(5000).then(function(){console.log("Select particular prod code from drop down ")});
							products_page.clickOnFilterApplyButton();
							browser.sleep(10000).then(function(){console.log("click on filter Apply Button ")});
							var edit_page=products_page.clickOnFirstRowsEditButton();
							browser.sleep(5000).then(function(){console.log("Click on first edit Button ")});
						    edit_page.clearEditProductCode();
							browser.sleep(5000).then(function(){console.log("Click clear prod Description ")});
							edit_page.eneterTextInEditProductCode(testData.Products.Platform_Search_Product_119.NewProductCode);
							var products_page=edit_page.clickOnSaveButton();
							browser.sleep(25000).then(function(){console.log("Click on Save  Button ")});
							 products_page.clickOnFilterProductsCodeDrpdwn();
							browser.sleep(5000).then(function(){console.log("Click on filter code dropdwn")});
							products_page.selectParticularProdCode(testData.Products.Platform_Search_Product_119.NewProductCode);
							browser.sleep(5000).then(function(){console.log("Select new  prod code from drop down ")});
							products_page.clickOnFilterApplyButton();
							browser.sleep(10000).then(function(){console.log("Click On Filter Apply Button")});
							products_page.verifyLengthOfProdCode();                         
						
						});
                   
				        it('Platform_Search_Product_120:Verify updating of text pattern of Product Code greter than (30 chars)', function() {

							console.log('Platform_Search_Product_120 started execution');
							var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
							var testData=require('../../../testData/productsPageData.json');	

							products_page.clickOnProdFilterButton();
					    	browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						    products_page.clickOnFilterProductsCodeDrpdwn();
							browser.sleep(5000).then(function(){console.log("Click on filter code dropdwn")});
							products_page.selectParticularProdCode(testData.Products.Platform_Search_Product_120.OriginalProductCode);
							browser.sleep(5000).then(function(){console.log("Select particular prod code from drop down ")});
							products_page.clickOnFilterApplyButton();
							browser.sleep(10000).then(function(){console.log("click on filter Apply Button ")});
							var edit_page=products_page.clickOnFirstRowsEditButton();
							browser.sleep(5000).then(function(){console.log("Click on first edit Button ")});
						    edit_page.clearEditProductCode();
							browser.sleep(5000).then(function(){console.log("Click clear prod Description ")});
							edit_page.eneterTextInEditProductCode(testData.Products.Platform_Search_Product_120.NewProductCode);
							var products_page=edit_page.clickOnSaveButton();
							browser.sleep(25000).then(function(){console.log("Click on Save  Button ")});
							products_page.clickOnFilterClearButton();
							browser.sleep(5000).then(function(){console.log("Click on Clear  Button ")});
							 products_page.eneterTextInDescriptionBox(testData.Products.Platform_Search_Product_120.Description);						
							browser.sleep(5000).then(function(){console.log("Description enter")});
							products_page.clickOnFilterApplyButton();
							browser.sleep(10000).then(function(){console.log("Click On Filter Apply Button")});
							products_page.verifyLengthOfProdCode();                         
						
						});

					it('Platform_Search_Product_124:Verify that * mark is present before each mandatory field of update screen', function() {

							console.log('Platform_Search_Product_124 started execution');
							var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
							var testData=require('../../../testData/productsPageData.json');		
													 
							var edit_page=products_page.clickOnFirstRowsEditButton();
							browser.sleep(5000).then(function(){console.log("Click on first edit Button ")});
						    edit_page.editProductStarIsPresent();
							edit_page.editDescriptionStarIsPresent();
							edit_page.editIssuerStarIsPresent();
							edit_page.editFromDateStarIsPresent();
							edit_page.editToDateStarIsPresent();
						
							console.log('Verify * for mandatory fields of Edit product page');		
                          
						});
					   
					    it('Platform_Search_Product_147:Verify the Delete Button functionality', function() {
                               console.log('Platform_Search_Product_147 started execution');
						       var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
                               products_page.selectFirstRecordwithCheckbox();
							   products_page.clickOnProdDeleteButton();
							   browser.sleep(5000).then(function(){console.log("Clicked on Delte Button ")});	
                               products_page.getTextOfDeletePopup();
							   products_page.clickOnProdDeleteNoButton();
							   browser.sleep(5000).then(function(){console.log("Clicked on Delte popup NO Button ")});


						});

					  it('Platform_Search_Product_148:Verify that user is able to select one or more Product records.', function() {
                               console.log('Platform_Search_Product_148 started execution');
						       var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
                               products_page.selectMultipleRecordsWithCheckBox();
					  }); 

					 it('Platform_Search_Product_151:Verify that user is able to Delete multiple Product record.', function() {
                               console.log('Platform_Search_Product_148 started execution');
						       var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
                               
							   var testData=require('../../../testData/productsPageData.json');	

							products_page.clickOnProdFilterButton();
					    	browser.sleep(5000).then(function(){console.log("Clicked on Filter Button and Navigate to Filter Pane")});
						    products_page.clickOnFilterIssuerCodeDrpdwn();
							browser.sleep(5000).then(function(){console.log("Click on filter issuer dropdwn")});
							products_page.selectParticularIssuer(testData.Products.Platform_Search_Product_151.validIssuerCode);
							browser.sleep(5000).then(function(){console.log("Select particular issuer code from drop down ")});
							products_page.clickOnFilterApplyButton();
							browser.sleep(10000).then(function(){console.log("click on filter Apply Button ")});
							products_page.clickOnCheckBoxToSelectAllProductsOnPage();
							browser.sleep(5000).then(function(){console.log("Selected Products ")});
							products_page.clickOnProdDeleteButton();
							browser.sleep(5000).then(function(){console.log("click on Delete Button ")});
							products_page.clickOnProdDeleteYesButton();
							browser.sleep(5000).then(function(){console.log("click on Yes Button of popup")});
							products_page.clickOnFilterIssuerCodeDrpdwn();
							browser.sleep(5000).then(function(){console.log("click on issuerdrpdwn ")});
                            products_page.selectParticularIssuer(testData.Products.Platform_Search_Product_151.validIssuerCode);
							browser.sleep(5000).then(function(){console.log("select particular issuer ")});
							products_page.clickOnFilterApplyButton();
							browser.sleep(10000).then(function(){console.log("click on filterApply btn ")});
							products_page.firstRowFromTableNotPresent();
					  }); 


					   it('Product_Management:Delete single Issuer record.',function () {
								
                             						
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
							    var testData=require('../../../testData/productsPageData.json');	
							  
							   element(by.cssContainingText('.section>a>h3>span', 'Issuers')).click();							
							   browser.sleep(15000).then(function(){console.log("clicked on Issuer option in Master Data")});                            
                            
								issuer_page.clickOnissuerFilterButton();
								browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});
							    issuer_page.eneterTextInfilter_IssuerName(testData.Products.SampleIssuer.issuerName);								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
								issuer_page.selectFirstRecordwithCheckbox();
								issuer_page.clickOnIssuerDeleteButton();
								browser.sleep(5000).then(function(){console.log("Click on Delete Btn")});
								issuer_page.clickOnIssuerDeleteYesButton();
					      		browser.sleep(5000).then(function(){console.log("Click on Delete Yes Btn")});
					 			issuer_page.clickOnFilterApplyButton();
                      			browser.sleep(10000).then(function(){console.log("Click on Filter Apply Btn")});
								issuer_page.firstRowFromTableNotPresent();						


			   });	 


			   it('Delete Subsidiary:Verify that user is able to Delete single Subsidiary record.',function(){
								console.log('Delete Subsidiary');
								var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
							  var testData=require('../../../testData/productsPageData.json');	

								 element(by.cssContainingText('.section>a>h3>span', 'Subsidiaries')).click();							
							     browser.sleep(15000).then(function(){console.log("clicked on Subsidiaries option in Master Data")});												
								 
								 subsidary_page.clickOnFilterButton();
								 subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
								 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});	
								 subsidary_page.selectParticularSubCode(testData.Products.SampleIssuer.SubsidiaryCode);
								 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});								  
								 subsidary_page.clickOnFilterApplyButton();
						         browser.sleep(10000).then(function(){console.log("Clicked on subsidary code dropdown")});

								 subsidary_page.selectFirstRecordwithCheckbox();
								 subsidary_page.clickOnDeleteButton();	
							     browser.sleep(5000).then(function(){console.log("Clicked on Delete Button")});	
                                 subsidary_page.clickOnDeleteYesButton();
							     browser.sleep(25000).then(function(){console.log("Clicked on Delete Yes Button")});
							
					    });

				 
					
   
	
});  
