describe('EventMgmt page', function() {
	
	                    beforeAll(function() {
								var loginData=require('../../../testData/loginPage.json');
								var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
								browser.ignoreSynchronization = true;
								browser.waitForAngularEnabled(false);
								browser.get(loginData.authentication.login.url);
								browser.sleep(5000).then(function(){console.log("Sleep after url launched")});

								//var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
								console.log('Cloooo--11')
								//***********************************************************************
								/*login_page.login();
                                browser.sleep(5000).then(function(){console.log("Sleep after url launched")});*/

						});
						
	
	
						beforeEach(function(){
								/* browser.get('http://10.51.232.73:3000/platform/master-data/subsidiaries');
								//protractor.browser.ignoreSynchronization = true;
								var loginData=require('../../../testData/loginPage.json');
								var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');*/
								var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
								//***************************************************************************************
								var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
								login_page.login();
								browser.sleep(5000).then(function(){console.log("Sleep after url launched")});


						
									home_page.clickBreadCrum();
									browser.driver.sleep(5000);
									element(by.cssContainingText('.section>a>h3>span', 'Event Management')).click();
									//browser.driver.navigate().refresh();
									browser.sleep(25000).then(function(){console.log("clicked on Products option in Master Data")});
									//ement(by.cssContainingText('.section>a>h3>span','Subsidiaries')).click();							
						
												
						});
						
						
					   afterEach(function(){
						 /*  var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
						   home_page.clickBreadCrum();
						   browser.driver.sleep(5000);*/
						   element(by.css('.header-icon-panel .icon-logout')).click();
						   browser.sleep(10000).then(function(){console.log("Clicked on logout Button")});
					   });

                      it('Create Sample data for issuer:Create Subsidiary',function () {
                                console.log('Sample subsidiary for Branches');
                                var testData=require('../../../testData/eventMgmtData.json');
                               // var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
                                     var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
                                    var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
                                   var status = false;

                                   element(by.cssContainingText('.section>a>h3>span', 'Subsidiaries')).click();
                                   browser.sleep(15000).then(function(){console.log("clicked on Issuer option in Master Data")});

                                   var subsidary_CreatePage=subsidary_page.clickOnCreateButton();
                                   browser.sleep(5000).then(function(){console.log("Create Button Clicked")});

                                   subsidary_CreatePage.eneterTextInCreateSubsidaryCode(testData.eventMgmt.SampleEventMgmtSubsidiary.SubsidiaryCode);
                                   subsidary_CreatePage.eneterTextInCreateSubsidaryDescription(testData.eventMgmt.SampleEventMgmtSubsidiary.Description);
                                   subsidary_CreatePage.eneterTextInValidDateFrom(testData.eventMgmt.SampleEventMgmtSubsidiary.validFrom);
                                   subsidary_CreatePage.eneterTextInValidDateTo(testData.eventMgmt.SampleEventMgmtSubsidiary.validTo);
                                   subsidary_page=subsidary_CreatePage.clickOnSaveButton();
                                   browser.sleep(10000).then(function(){console.log("clicked on Save Btn")});
                                   console.log('Sample subsidiary created successfully');

                           });

                              it('Create Sample Branches data For Issuers',function () {

                                console.log('Sample Issuer for Branches');
                                var testData=require('../../../testData/eventMgmtData.json');


                                   element(by.cssContainingText('.section>a>h3>span', 'Issuers')).click();
                                   browser.sleep(20000).then(function(){console.log("clicked on Issuer option in Master Data")});

                                   var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                                    var create_Issuer= issuer_page.clickOnIssuerCreateButton();
                                   browser.sleep(10000).then(function(){console.log("Clicked on Issuer create button")});
                                   create_Issuer.eneterTextInCreateIssuerCode(testData.eventMgmt.SampleEventMgmtIssuerData.issuerCode);
                                   create_Issuer.eneterTextInCreateIssuerName(testData.eventMgmt.SampleEventMgmtIssuerData.issuerName);
                                   create_Issuer.eneterTextInValidDateFrom(testData.eventMgmt.SampleEventMgmtIssuerData.validFrom);
                                   create_Issuer.eneterTextInValidDateTo(testData.eventMgmt.SampleEventMgmtIssuerData.validTo);
                                   create_Issuer.clickOnIssuerSubsidiaryDrpDwn();
                                    browser.sleep(5000).then(function(){console.log("Issuer Subisdiary Drp Dwn")});
                                   create_Issuer.selectParticularIssuerSubsidiaryCode(testData.eventMgmt.SampleEventMgmtIssuerData.SubsidiaryCode);

                                   create_Issuer.clickOnDefaultLanguageDrpDwn();
                                    browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
                                    create_Issuer.selectParticularLanguage(testData.eventMgmt.SampleEventMgmtIssuerData.language);
                                   create_Issuer.eneterTextInNotificationRetentionPeriod(testData.eventMgmt.SampleEventMgmtIssuerData.notificationRetentionPeriod);

                                   create_Issuer.clickOnSaveButton();
                                    browser.sleep(15000).then(function(){console.log("Click On save btn")});

                           });



                            it('sample Event creation ',function () {
                                console.log('Sample Event Creation');
                                var testData=require('../../../testData/eventMgmtData.json');
                                var eventMgmt_page=require('../../../pageObject/platformPOM/eventMgmtPOM/eventMgmtPageObject.js');
                                // expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);
                                //console.log('Url='+browser.getCurrentUrl());
                                var configure_event= eventMgmt_page.clickOnEventMgmtConfigureButton();
                                browser.sleep(10000).then(function(){console.log("Clicked on Configure  Btn")});
                                configure_event.clickOnIssuerDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnIssuerDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.issuer);


                                configure_event.clickOnApplicationDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnApplicationDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.application);

                                configure_event.clickOnVersionDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnVersionDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.version);

                                configure_event.clickOnEventNameDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnEventNameDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.eventName);

                                configure_event.clickOnSeverityDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnSeverityDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.severity);

                                configure_event.clickOnChannelDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnChannelDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.channel);


                                configure_event.enterTextInReminderFrequency(testData.eventMgmt.event_Management_051.reminderFrequency);

                                configure_event.clickOnReminderFreqUnitrDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnReminderFreqUnitrDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.reminderFrequencyUnit);

                                configure_event.clickOnEventTypeDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnEventTypeDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.eventType);

                                configure_event.clickOnUsersDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnUsersDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.users);

                                configure_event.clickOnGroupsDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnGroupsDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.groups);

                                eventMgmt_page=configure_event.clickOnSaveButton();
                                browser.sleep(15000).then(function(){console.log("Clicked on Save  Btn")});



                            });


                            it('Rapid_Notification_005:Verify default fields / buttons available on \'Event Management\'  screen. .', function() {
                                console.log('Rapid_Notification_005 started execution');
                                var testData=require('../../../testData/eventMgmtData.json');
                                var eventMgmt_page=require('../../../pageObject/platformPOM/eventMgmtPOM/eventMgmtPageObject.js');
                                // expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);
                                //console.log('Url='+browser.getCurrentUrl());

                                     eventMgmt_page.eventMgmtFilterButtonIsPresent();
                                     eventMgmt_page.eventMgmtDeleteButtonIsPresent();
                                     eventMgmt_page.eventMgmtConfigureButtonIsPresent();
                                     eventMgmt_page.eventMgmtTextIsPresent();
                                     eventMgmt_page.eventMgmtExoprtOPtionIsPresent();

                            });


                            it('Rapid_Notification_006:Verify the elements of \'Event Management\' grid.', function() {
                                console.log('Rapid_Notification_006 started execution');
                                var testData=require('../../../testData/eventMgmtData.json');
                                var eventMgmt_page=require('../../../pageObject/platformPOM/eventMgmtPOM/eventMgmtPageObject.js');
                                // expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);
                                //console.log('Url='+browser.getCurrentUrl());

                                eventMgmt_page.checkBoxToSelectAllIsPresent();
                                eventMgmt_page.issuerIsPresent();
                                eventMgmt_page.applicationIsPresent();
                                eventMgmt_page.eventNameIsPresent();
                                eventMgmt_page.eventTypeIsPresent();
                                eventMgmt_page.severityIsPresent();
                                eventMgmt_page.updatedByIsPresent();
                                eventMgmt_page.updatedOnIsPresent();

                            });

                            it('Rapid_Notification_009:Verify \'default elements\' of Filter Pane', function() {
                                console.log('Rapid_Notification_009 started execution');
                                var testData=require('../../../testData/eventMgmtData.json');
                                var eventMgmt_page=require('../../../pageObject/platformPOM/eventMgmtPOM/eventMgmtPageObject.js');
                                // expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);
                                //console.log('Url='+browser.getCurrentUrl());
                                 eventMgmt_page.clickOnEventMgmtFilterButton();
                                browser.sleep(5000).then(function(){console.log("Clicked on filter  Btn")});
                                eventMgmt_page.filter_Issuer_drpdwnIsPresent();
                                eventMgmt_page.filter_Application_drpdwnIsPresent();

                                eventMgmt_page.filter_VErsion_drpdwnIsPresent();
                                eventMgmt_page.filter_EventName_drpdwnIsPresent();
                                eventMgmt_page.filter_Clear_ButtonIsPresent();
                                eventMgmt_page.filter_Apply_ButtonIsPresent();
                                eventMgmt_page.filter_CloseIconIsPresent();

                            });

                            it('Rapid_Notification_049:Verify that authorized user is able to navigate to "Configure Business Events\' screen', function() {
                                console.log('Rapid_Notification_049 started execution');
                                var testData=require('../../../testData/eventMgmtData.json');
                                var eventMgmt_page=require('../../../pageObject/platformPOM/eventMgmtPOM/eventMgmtPageObject.js');
                                // expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);
                                //console.log('Url='+browser.getCurrentUrl());
                                eventMgmt_page.clickOnEventMgmtConfigureButton();
                                browser.sleep(10000).then(function(){console.log("Clicked on Configure  Btn")});

                                browser.getCurrentUrl().then(function(url) {
                                    console.log("URL= "+ url);
                                    expect(url).toContain(testData.eventMgmt.event_Management_049.urlContain);
                                });
                            });


                            it('Rapid_Notification_050:Verify default elements of \'Configure Business Event\'  screen. ', function() {
                                console.log('Rapid_Notification_050 started execution');
                                var testData=require('../../../testData/eventMgmtData.json');
                                var eventMgmt_page=require('../../../pageObject/platformPOM/eventMgmtPOM/eventMgmtPageObject.js');
                                // expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);
                                //console.log('Url='+browser.getCurrentUrl());
                                var configure_event= eventMgmt_page.clickOnEventMgmtConfigureButton();
                                browser.sleep(10000).then(function(){console.log("Clicked on Configure  Btn")});
                                  configure_event.createIssuerDrpDwnIsPresent();
                                  configure_event.createApplicationDrpDwnIsPresent();
                                  configure_event.createVersionDrpDwnIsPresent();
                                  configure_event.createEventNameDrpDwnIsPresent();
                                  configure_event.createSeverityDrpDwnIsPresent();
                                  configure_event.createChannelDrpDwnIsPresent();
                                  configure_event.createReminderFrequencyIsPresent();
                                  configure_event.reminderFrequencyUnitDrpDwnIsPresent();
                                  configure_event.eventTypDrpDwnIsPresent();
                                  configure_event.groupsDrpDwnIsPresent();
                                  configure_event.usersDrpDwnIsPresent();


                            });





                            it('Rapid_Notification_051,052,053,054:Verify that superadmin user is able to configure the business Events for any available application. ', function() {
                                console.log('Rapid_Notification_051,052,053,054 started execution');
                                var testData=require('../../../testData/eventMgmtData.json');
                                var eventMgmt_page=require('../../../pageObject/platformPOM/eventMgmtPOM/eventMgmtPageObject.js');
                                // expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);
                                //console.log('Url='+browser.getCurrentUrl());
                                var configure_event= eventMgmt_page.clickOnEventMgmtConfigureButton();
                                browser.sleep(10000).then(function(){console.log("Clicked on Configure  Btn")});
                                configure_event.clickOnIssuerDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnIssuerDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.issuer);


                                configure_event.clickOnApplicationDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnApplicationDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.application);

                                configure_event.clickOnVersionDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnVersionDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.version);

                                configure_event.clickOnEventNameDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnEventNameDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.eventName);

                                configure_event.clickOnSeverityDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnSeverityDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.severity);

                                configure_event.clickOnChannelDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnChannelDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.channel);


                                configure_event.enterTextInReminderFrequency(testData.eventMgmt.event_Management_051.reminderFrequency);

                                configure_event.clickOnReminderFreqUnitrDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnReminderFreqUnitrDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.reminderFrequencyUnit);

                                configure_event.clickOnEventTypeDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnEventTypeDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.eventType);

                                configure_event.clickOnUsersDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnUsersDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.users);

                                configure_event.clickOnGroupsDrpDwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on clickOnGroupsDrpDwn  Btn")});
                                configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_051.groups);

                                eventMgmt_page=configure_event.clickOnSaveButton();
                                browser.sleep(30000).then(function(){console.log("Clicked on Save  Btn")});

                                browser.getCurrentUrl().then(function(url) {
                                    console.log("URL= "+ url);
                                    expect(url).toContain(testData.eventMgmt.event_Management_051.urlContain);
                                });

                                eventMgmt_page.clickOnEventMgmtFilterButton();
                                browser.sleep(5000).then(function(){console.log("Clicked on Filter  Btn")});
                                eventMgmt_page.clickOnFilterIssuerDrpdwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on Filter Issuer Drpdwn")});
                                eventMgmt_page.selectParticularIssuer(testData.eventMgmt.event_Management_051.issuer);


                                eventMgmt_page.clickOnFilterApplicationDrpdwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on Filter Application Drpdwn")});
                                eventMgmt_page.selectParticularFromDrpDwn(testData.eventMgmt.event_Management_051.application);

                                eventMgmt_page.clickOnFilterVersionDrpdwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on Filter Version Drpdwn")});
                                eventMgmt_page.selectParticularFromDrpDwn(testData.eventMgmt.event_Management_051.version);

                                eventMgmt_page.clickOnFilterEventDrpdwn();
                                browser.sleep(5000).then(function(){console.log("Clicked on Filter EventName Drpdwn")});
                                eventMgmt_page.selectParticularFromDrpDwn(testData.eventMgmt.event_Management_051.eventName);

                                eventMgmt_page.clickOnFilterApplyButton();
                                browser.sleep(15000).then(function(){console.log("Clicked on Filter Apply BTn ")});

                                eventMgmt_page.rowCountInTable();
                                eventMgmt_page.getTextOfFirstRowIssuer(testData.eventMgmt.event_Management_051.issuer);
                                eventMgmt_page.getTextOfFirstRowUpdatedBy();
                                eventMgmt_page.getTextOfFirstRowUpdatedOn();


                                var details_Page=eventMgmt_page.clickOnfirstRowIssuer();
                                browser.sleep(5000).then(function(){console.log("Clicked on 1st Row Issuer ")});

                                details_Page.verifyTextOfUpdatedOn();
                                details_Page.verifyTextOfUpdatedBy();


                            });



                     it('Rapid_Notification_087:Verify that user can \'Cancel\' the Configure request. ', function() {
                            console.log('Rapid_Notification_087 started execution');
                            var testData=require('../../../testData/eventMgmtData.json');
                            var eventMgmt_page=require('../../../pageObject/platformPOM/eventMgmtPOM/eventMgmtPageObject.js');
                            // expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);
                            //console.log('Url='+browser.getCurrentUrl());
                            var configure_event= eventMgmt_page.clickOnEventMgmtConfigureButton();
                            browser.sleep(10000).then(function(){console.log("Clicked on Configure  Btn")});
                            configure_event.clickOnIssuerDrpDwn();
                            browser.sleep(5000).then(function(){console.log("Clicked on clickOnIssuerDrpDwn  Btn")});
                            configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_087.issuer);


                            configure_event.clickOnApplicationDrpDwn();
                            browser.sleep(5000).then(function(){console.log("Clicked on clickOnApplicationDrpDwn  Btn")});
                            configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_087.application);

                            configure_event.clickOnVersionDrpDwn();
                            browser.sleep(5000).then(function(){console.log("Clicked on clickOnVersionDrpDwn  Btn")});
                            configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_087.version);

                            configure_event.clickOnEventNameDrpDwn();
                            browser.sleep(5000).then(function(){console.log("Clicked on clickOnEventNameDrpDwn  Btn")});
                            configure_event.selectParticularFromDropDown(testData.eventMgmt.event_Management_087.eventName);


                            configure_event.clickOnCancelButton();
                            browser.sleep(5000).then(function(){console.log("Clicked on Save  Btn")});

                            eventMgmt_page=configure_event.clickOnCanacelPopUpOk();
                            browser.sleep(15000).then(function(){console.log("Clicked on Cancel Popup OK  Btn")});

                            browser.getCurrentUrl().then(function(url) {
                                console.log("URL= "+ url);
                                expect(url).toContain(testData.eventMgmt.event_Management_087.urlContain);
                            });

                            eventMgmt_page.clickOnEventMgmtFilterButton();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter  Btn")});
                            eventMgmt_page.clickOnFilterIssuerDrpdwn();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter Issuer Drpdwn")});
                            eventMgmt_page.selectParticularIssuer(testData.eventMgmt.event_Management_087.issuer);


                            eventMgmt_page.clickOnFilterApplicationDrpdwn();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter Application Drpdwn")});
                            eventMgmt_page.selectParticularFromDrpDwn(testData.eventMgmt.event_Management_087.application);

                            eventMgmt_page.clickOnFilterVersionDrpdwn();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter Version Drpdwn")});
                            eventMgmt_page.selectParticularFromDrpDwn(testData.eventMgmt.event_Management_087.version);

                            eventMgmt_page.clickOnFilterEventDrpdwn();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter EventName Drpdwn")});
                            eventMgmt_page.selectParticularFromDrpDwn(testData.eventMgmt.event_Management_087.eventName);

                            eventMgmt_page.clickOnFilterApplyButton();
                            browser.sleep(15000).then(function(){console.log("Clicked on Filter Apply BTn ")});

                            eventMgmt_page.firstRowFromTableNotPresent();


                        });


                        it('Rapid_Notification_089:Verify that authorized user is able to navigate to "Update Events\' screen when clicked on pencil icon.. ', function() {
                            console.log('Rapid_Notification_089 started execution');
                            var testData=require('../../../testData/eventMgmtData.json');
                            var eventMgmt_page=require('../../../pageObject/platformPOM/eventMgmtPOM/eventMgmtPageObject.js');
                            // expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);
                            //console.log('Url='+browser.getCurrentUrl());
                            eventMgmt_page.clickOnFirstRowsEditButton();
                            browser.sleep(10000).then(function(){console.log("Clicked on Configure  Btn")});

                            browser.getCurrentUrl().then(function(url) {
                                console.log("URL= "+ url);
                                expect(url).toContain(testData.eventMgmt.event_Management_089.urlContain);
                            });


                        });



                        it('Rapid_Notification_090:Verify that authorized user is able to navigate to "Update Events\' screen through view details screen. ', function() {
                            console.log('Rapid_Notification_090 started execution');
                            var testData=require('../../../testData/eventMgmtData.json');
                            var eventMgmt_page=require('../../../pageObject/platformPOM/eventMgmtPOM/eventMgmtPageObject.js');
                            // expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);
                            //console.log('Url='+browser.getCurrentUrl());
                            eventMgmt_page.clickOnEventMgmtFilterButton();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter  Btn")});
                            eventMgmt_page.clickOnFilterIssuerDrpdwn();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter Issuer Drpdwn")});
                            eventMgmt_page.selectParticularIssuer(testData.eventMgmt.event_Management_090.issuer);


                            eventMgmt_page.clickOnFilterApplicationDrpdwn();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter Application Drpdwn")});
                            eventMgmt_page.selectParticularFromDrpDwn(testData.eventMgmt.event_Management_090.application);

                            eventMgmt_page.clickOnFilterVersionDrpdwn();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter Version Drpdwn")});
                            eventMgmt_page.selectParticularFromDrpDwn(testData.eventMgmt.event_Management_090.version);

                            eventMgmt_page.clickOnFilterEventDrpdwn();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter EventName Drpdwn")});
                            eventMgmt_page.selectParticularFromDrpDwn(testData.eventMgmt.event_Management_090.eventName);

                            eventMgmt_page.clickOnFilterApplyButton();
                            browser.sleep(15000).then(function(){console.log("Clicked on Filter Apply BTn ")});


                            var details_page=eventMgmt_page.clickOnfirstRowIssuer();
                            browser.sleep(10000).then(function(){console.log("Clicked on Configure  Btn")});

                            details_page.clickOnDetailsEditButton();
                            browser.sleep(10000).then(function(){console.log("Clicked on Edit  Btn")});

                            browser.getCurrentUrl().then(function(url) {
                                console.log("URL= "+ url);
                                expect(url).toContain(testData.eventMgmt.event_Management_090.urlContain);
                            });


                        });

                      it('Rapid_Notification_091:Verify default elements of \'Update Event\'  screen. ', function() {
                            console.log('Rapid_Notification_091 started execution');
                            var testData=require('../../../testData/eventMgmtData.json');
                            var eventMgmt_page=require('../../../pageObject/platformPOM/eventMgmtPOM/eventMgmtPageObject.js');
                            // expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);
                            //console.log('Url='+browser.getCurrentUrl());


                            eventMgmt_page.clickOnEventMgmtFilterButton();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter  Btn")});
                            eventMgmt_page.clickOnFilterIssuerDrpdwn();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter Issuer Drpdwn")});
                            eventMgmt_page.selectParticularIssuer(testData.eventMgmt.event_Management_091.issuer);


                            eventMgmt_page.clickOnFilterApplicationDrpdwn();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter Application Drpdwn")});
                            eventMgmt_page.selectParticularFromDrpDwn(testData.eventMgmt.event_Management_091.application);

                            eventMgmt_page.clickOnFilterVersionDrpdwn();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter Version Drpdwn")});
                            eventMgmt_page.selectParticularFromDrpDwn(testData.eventMgmt.event_Management_091.version);

                            eventMgmt_page.clickOnFilterEventDrpdwn();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter EventName Drpdwn")});
                            eventMgmt_page.selectParticularFromDrpDwn(testData.eventMgmt.event_Management_091.eventName);

                            eventMgmt_page.clickOnFilterApplyButton();
                            browser.sleep(15000).then(function(){console.log("Clicked on Filter Apply BTn ")});


                            var edit_page=eventMgmt_page.clickOnFirstRowsEditButton();
                            browser.sleep(10000).then(function(){console.log("Clicked on Configure  Btn")});

                            edit_page.editIssuerDrpdwnIsPresent();
                            edit_page.editApplicationDrpdwnIsPresent();
                            edit_page.editVersionDrpdwnIsPresent();
                            edit_page.editEventNameDrpdwnIsPresent();
                            edit_page.editSeverityDrpdwnIsPresent();
                            edit_page.editChannelDrpdwnIsPresent();
                            edit_page.editChannelDrpdwnIsPresent();
                            edit_page.editReminderFreqInputIsPresent();
                            edit_page.editRemidnerFreqUnitDrpdwnIsPresent();
                            edit_page.editEventTypeDrpdwnIsPresent();
                            edit_page.editUsersDrpdwnIsPresent();
                            edit_page.editGroupsDrpdwnIsPresent();



                        });



                    it('Rapid_Notification_092:Verify default elements of \'Update Event\'  screen. ', function() {
                        console.log('Rapid_Notification_091 started execution');
                        var testData = require('../../../testData/eventMgmtData.json');
                        var eventMgmt_page = require('../../../pageObject/platformPOM/eventMgmtPOM/eventMgmtPageObject.js');
                        // expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);
                        //console.log('Url='+browser.getCurrentUrl());


                        eventMgmt_page.clickOnEventMgmtFilterButton();
                        browser.sleep(5000).then(function () {
                            console.log("Clicked on Filter  Btn")
                        });
                        eventMgmt_page.clickOnFilterIssuerDrpdwn();
                        browser.sleep(5000).then(function () {
                            console.log("Clicked on Filter Issuer Drpdwn")
                        });
                        eventMgmt_page.selectParticularIssuer(testData.eventMgmt.event_Management_092.issuer);


                        eventMgmt_page.clickOnFilterApplicationDrpdwn();
                        browser.sleep(5000).then(function () {
                            console.log("Clicked on Filter Application Drpdwn")
                        });
                        eventMgmt_page.selectParticularFromDrpDwn(testData.eventMgmt.event_Management_092.application);

                        eventMgmt_page.clickOnFilterVersionDrpdwn();
                        browser.sleep(5000).then(function () {
                            console.log("Clicked on Filter Version Drpdwn")
                        });
                        eventMgmt_page.selectParticularFromDrpDwn(testData.eventMgmt.event_Management_092.version);

                        eventMgmt_page.clickOnFilterEventDrpdwn();
                        browser.sleep(5000).then(function () {console.log("Clicked on Filter EventName Drpdwn")});
                        eventMgmt_page.selectParticularFromDrpDwn(testData.eventMgmt.event_Management_092.eventName);

                        eventMgmt_page.clickOnFilterApplyButton();
                        browser.sleep(15000).then(function () {console.log("Clicked on Filter Apply BTn ")});

                        var edit_Page=eventMgmt_page.clickOnFirstRowsEditButton();
                        browser.sleep(15000).then(function () {console.log("Clicked on 1st Row edit BTn ")});

                        edit_Page.clickOnEditEventTypeDrpdwn();
                        browser.sleep(5000).then(function () {console.log("Clicked on Event type Drpdwn")});

                        edit_Page.selectParticularFromDrpdwn(testData.eventMgmt.event_Management_092.eventType);

                        eventMgmt_page= edit_Page.clickOnSave1Button();
                        browser.sleep(20000).then(function () {console.log("Clicked on Save BTn ")});

                        eventMgmt_page.clickOnFilterApplyButton();
                        browser.sleep(15000).then(function () {console.log("Clicked on Filter Apply BTn ")});

                        eventMgmt_page.getTextOfFirstRowEventType(testData.eventMgmt.event_Management_092.eventType);




                    });


                    it('Rapid_Notification_0133:Verify that user is able to select one or more Events.',function () {
                        console.log('Rapid_Notification_0133 started execution ');
                        var testData = require('../../../testData/eventMgmtData.json');
                        var eventMgmt_page = require('../../../pageObject/platformPOM/eventMgmtPOM/eventMgmtPageObject.js');


                        eventMgmt_page.selectMultipleRecordsWithCheckBox();

                        eventMgmt_page.clickOnEventMgmtDeleteButton();
                        browser.sleep(5000).then(function () {console.log("Clicked on Delete Btn")});
                        eventMgmt_page.getTextOfDeletePopup();

                        eventMgmt_page.clickOnCloseIconOfPopUp();
                        browser.sleep(5000).then(function () {console.log("Clicked on Close ICon Of Popup Btn")});

                    });


                it('Rapid_Notification_135:Verify that user is able to Delete single Event record.', function() {
                    console.log('Rapid_Notification_135 started execution');
                    var testData = require('../../../testData/eventMgmtData.json');
                    var eventMgmt_page = require('../../../pageObject/platformPOM/eventMgmtPOM/eventMgmtPageObject.js');
                    // expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);
                    //console.log('Url='+browser.getCurrentUrl());


                    eventMgmt_page.clickOnEventMgmtFilterButton();
                    browser.sleep(5000).then(function () {
                        console.log("Clicked on Filter  Btn")
                    });
                    eventMgmt_page.clickOnFilterIssuerDrpdwn();
                    browser.sleep(5000).then(function () {
                        console.log("Clicked on Filter Issuer Drpdwn")
                    });
                    eventMgmt_page.selectParticularIssuer(testData.eventMgmt.event_Management_135.issuer);


                    eventMgmt_page.clickOnFilterApplicationDrpdwn();
                    browser.sleep(5000).then(function () {
                        console.log("Clicked on Filter Application Drpdwn")
                    });
                    eventMgmt_page.selectParticularFromDrpDwn(testData.eventMgmt.event_Management_135.application);

                    eventMgmt_page.clickOnFilterVersionDrpdwn();
                    browser.sleep(5000).then(function () {
                        console.log("Clicked on Filter Version Drpdwn")
                    });
                    eventMgmt_page.selectParticularFromDrpDwn(testData.eventMgmt.event_Management_135.version);

                    eventMgmt_page.clickOnFilterEventDrpdwn();
                    browser.sleep(5000).then(function () {console.log("Clicked on Filter EventName Drpdwn")});
                    eventMgmt_page.selectParticularFromDrpDwn(testData.eventMgmt.event_Management_135.eventName);

                    eventMgmt_page.clickOnFilterApplyButton();
                    browser.sleep(15000).then(function () {console.log("Clicked on Filter Apply BTn ")});

                    eventMgmt_page.selectFirstRecordwithCheckbox();
                    eventMgmt_page.clickOnEventMgmtDeleteButton();
                    browser.sleep(5000).then(function () {console.log("Clicked on EventMgmt Delete Button")});

                    eventMgmt_page.clickOnEventMgmtDeleteYesButton();
                    browser.sleep(20000).then(function () {console.log("Clicked on Delete Yes Button")});

                    eventMgmt_page.clickOnFilterApplyButton();
                    browser.sleep(15000).then(function () {console.log("Clicked on Filter Apply BTn ")});

                    eventMgmt_page.firstRowFromTableNotPresent();


                });













});  
