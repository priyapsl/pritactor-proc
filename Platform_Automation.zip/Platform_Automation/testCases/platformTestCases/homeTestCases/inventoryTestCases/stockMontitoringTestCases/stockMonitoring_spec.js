

describe('stock Montitoring Page', function() {
	
				    beforeEach(function(){
								  browser.get('http://10.51.232.73:3001/inventory/stock-monitoring');
								  browser.waitForAngular();
								});
						
						
	
					xit('Stock Monitoring_Display Structure_02:Verify that internal users having appropriate permission can navigate to Stock monitoring page for different issuers', function() {
							var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
							console.log('Navigate to subsidary Page');
							var status = false;
							
							if(subsidary_page.subsidaryTextIsPresent() && subsidary_page.filterButtonIsPresent() && subsidary_page.deleteButtonIsPresent() && subsidary_page.createButtonIsPresent()){
								status=true;
								console.log('All element/Buttons are present ');
							}		
							expect(status).toBe(true);
						  });
						  
};
