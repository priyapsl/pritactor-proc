describe('Issuer page', function() {
	
	                    beforeAll(function() {
								var loginData=require('../../../testData/loginPage.json');
								var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
								browser.ignoreSynchronization = true;
								browser.waitForAngularEnabled(false);
								browser.get(loginData.authentication.login.url);
								browser.sleep(5000).then(function(){console.log("Sleep after url launched")});

								//var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
								console.log('Cloooo--11')
								//***********************************************************************
								/*login_page.login();
                                browser.sleep(5000).then(function(){console.log("Sleep after url launched")});*/

						});
						
	
	
						beforeEach(function(){
						/* browser.get('http://10.51.232.73:3000/platform/master-data/subsidiaries');
						  //protractor.browser.ignoreSynchronization = true;
						  var loginData=require('../../../testData/loginPage.json');
						  var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');*/
						  var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
						  //***************************************************************************************
						  var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
						  login_page.login();
                                browser.sleep(10000).then(function(){console.log("Sleep after url launched")});


						 /* browser.waitForAngularEnabled(false);
					      // var b1=browser.forkNewDriverInstance();
						  
						  browser.get(loginData.authentication.login.url); 
							browser.driver.sleep(5000);
							login_page.enterUserName(loginData.authentication.login.username);
							login_page.enterPassword(loginData.authentication.login.password);
							login_page.clickLoginButton();
							 browser.driver.sleep(5000);*/
							//element(by.css('.sli-large.icon-menu')).click();
							home_page.clickBreadCrum();
							browser.driver.sleep(5000);
							//home_page.clickIssuerDirectlyOrClickMasterDataFirst();
							element(by.cssContainingText('.section>a>h3>span', 'Issuers')).click();
							//browser.driver.navigate().refresh();
							 browser.sleep(40000).then(function(){console.log("clicked on Issuer option in Master Data")});
							//ement(by.cssContainingText('.section>a>h3>span','Subsidiaries')).click();			
												
						});
						
						
					   afterEach(function(){
						 /*  var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
						   home_page.clickBreadCrum();
						   browser.driver.sleep(5000);*/
						   element(by.css('.header-icon-panel .icon-logout')).click();
						   browser.sleep(10000).then(function(){console.log("Clicked on logout Button")});
					   });

                   it('Create Sample data1 For Issuers:Create Subsidiary',function () {
						  console.log('Issuer_Management_SampleData1 started execution');
						  var testData=require('../../../testData/issuerPageData.json');	
						 // var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
                          	 var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
							  var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
							 var status = false;
				        
							///Sample subsidiary created for this
							 element(by.cssContainingText('.section>a>h3>span', 'Subsidiaries')).click();							
							 browser.sleep(25000).then(function(){console.log("clicked on Subsidiaries option in Master Data")});
							 var subsidary_CreatePage=subsidary_page.clickOnCreateButton();
							 browser.sleep(5000).then(function(){console.log("Create Button Clicked")});							
							 
							 subsidary_CreatePage.eneterTextInCreateSubsidaryCode(testData.issuer.sampleData.SubsidiaryCode);
							 subsidary_CreatePage.eneterTextInCreateSubsidaryDescription(testData.issuer.sampleData.Description);
							 subsidary_CreatePage.eneterTextInValidDateFrom(testData.issuer.sampleData.ValidFrom);
							 subsidary_CreatePage.eneterTextInValidDateTo(testData.issuer.sampleData.ValidTo);
							 subsidary_page=subsidary_CreatePage.clickOnSaveButton();	
							 browser.sleep(20000).then(function(){console.log("clicked on Save Btn")});
                             console.log('Sample subsidiary created successfully');

					 });

					  it('Create Sample data2 For Issuers',function () {

						  console.log('Issuer_Managemen sampkle Data2 started execution');
						  var testData=require('../../../testData/issuerPageData.json');	
						 // var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
                          	 var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
							 var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
							 var status = false;
				        
					

                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                              var create_Issuer= issuer_page.clickOnIssuerCreateButton();
							 browser.sleep(20000).then(function(){console.log("Clicked on Issuer create button")});
                             create_Issuer.eneterTextInCreateIssuerCode(testData.issuer.sampleData.issuerCode1);
							 create_Issuer.eneterTextInCreateIssuerName(testData.issuer.sampleData.issuerName1);							
							 create_Issuer.eneterTextInValidDateFrom(testData.issuer.sampleData.validFrom1);
							 create_Issuer.eneterTextInValidDateTo(testData.issuer.sampleData.validTo1);
                             create_Issuer.clickOnIssuerSubsidiaryDrpDwn();
							  browser.sleep(5000).then(function(){console.log("Issuer Subisdiary Drp Dwn")});
							 create_Issuer.selectParticularIssuerSubsidiaryCode(testData.issuer.sampleData.SubsidiaryCode);

                             create_Issuer.clickOnDefaultLanguageDrpDwn();
							  browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
                              create_Issuer.selectParticularLanguage(testData.issuer.sampleData.language);
                             create_Issuer.eneterTextInNotificationRetentionPeriod(testData.issuer.sampleData.notificationRetentionPeriod);

                             create_Issuer.clickOnSaveButton();
							  browser.sleep(20000).then(function(){console.log("Click On save btn")});
					        
							
							
							
							



					 });

					 it('Sample Data3',function(){
                            console.log('Sample Data 3 started');
                             var testData=require('../../../testData/issuerPageData.json');
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                              var create_Issuer= issuer_page.clickOnIssuerCreateButton();
							 browser.sleep(20000).then(function(){console.log("Clicked on Issuer create button")});
                             create_Issuer.eneterTextInCreateIssuerCode(testData.issuer.sampleData.issuerCode);
							 create_Issuer.eneterTextInCreateIssuerName(testData.issuer.sampleData.issuerName);
							 create_Issuer.eneterTextInCreateIssuerDebitor(testData.issuer.sampleData.debitor);
							 create_Issuer.eneterTextInCreateIssuerDisponent(testData.issuer.sampleData.disponent);
							 create_Issuer.eneterTextInValidDateFrom(testData.issuer.sampleData.validFrom);
							 create_Issuer.eneterTextInValidDateTo(testData.issuer.sampleData.validTo);
 
							 create_Issuer.clickOnIssuerSubsidiaryDrpDwn();
							  browser.sleep(5000).then(function(){console.log("Issuer Subisdiary Drp Dwn")});

							 create_Issuer.selectParticularIssuerSubsidiaryCode(testData.issuer.sampleData.SubsidiaryCode);


                             create_Issuer.clickOnParentIssuerDrpDwn();
							  browser.sleep(10000).then(function(){console.log("Click on Paren Issuer Drpdwn")});
							  create_Issuer.selectParticularParentIssuer(testData.issuer.sampleData.issuerName1);
							 create_Issuer.clickOnDefaultLanguageDrpDwn();
							  browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
                              create_Issuer.selectParticularLanguage(testData.issuer.sampleData.language);

							 create_Issuer.eneterTextInDocumentRetentionPeriod(testData.issuer.sampleData.documentRetentionPeriod);
						     


							 create_Issuer.eneterTextInNotificationRetentionPeriod(testData.issuer.sampleData.notificationRetentionPeriod);


							 create_Issuer.clickOnSaveButton();
							  browser.sleep(20000).then(function(){console.log("clicked on Save Btn")});


					 });

					 it('Issuer_Management_004: Verify that user is able to Navigate landing page of  Issuers',function () {
						  console.log('Issuer_Management_004 started execution');
						  var testData=require('../../../testData/issuerPageData.json');	
						 // var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');

						 	//expect(browser.getCurrentUrl()).toContain(testData.issuer.IssuerManagement004.urlContain);

							 browser.getCurrentUrl().then(function(url) {
										console.log("URL= "+ url);
										expect(url).toContain(testData.issuer.IssuerManagement004.urlContain);	
									});	
						
					 });

					 it('Issuer_Management_005: Verify default fields / buttons available on Issuers  screen. ',function () {
						  console.log('Issuer_Management_005 started execution');
						  var testData=require('../../../testData/issuerPageData.json');	
						  var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

                           issuer_page.issuerFilterButtonIsPresent();
						  issuer_page.issuerExportOptionIsPresent();
						  issuer_page.issuerCreateButtonIsPresent();
						  issuer_page.issuerDeleteButtonIsPresent();
						  console.log('Vaerify the element on Issuer screen');	  
						 	
						
					 });
					  
					it('Issuer_Management_006: Verify the elements of Issuers grid. ',function () {
						  console.log('Issuer_Management_006 started execution');
						  var testData=require('../../../testData/issuerPageData.json');	
						  var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

                        
						  issuer_page.checkBoxToSelectAllIsPresent();
						  issuer_page.issuerCodeIsPresent();
						  issuer_page.issuerNameIsPresent();
						  issuer_page.issuerDebitorIsPresent();
						  issuer_page.issuerDisponentIsPresent();
						  issuer_page.valid_fromIsPresent();
						  issuer_page.valid_ToIsPresent();
						  issuer_page.updatedByIsPresent();
						  issuer_page.updatedOnIsPresent();	
						  console.log('Elements of issuer Grids are verified '); 	
						
					 });

					  it('Issuer_Management_008: Verify that by default Filter Pane is Collapsed. ',function () {
						  console.log('Issuer_Management_005 started execution');
						  var testData=require('../../../testData/issuerPageData.json');	
						  var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

                         
						  issuer_page.filter_Apply_ButtonIsNotPresent();
						  issuer_page.filter_Clear_ButtonIsNotPresent();						 
						  console.log('Vaerify by default Filter Pane is Collapsed');	  
						 	
						
					 });
					  
					   it('Issuer_Management_009,010: Verify that Filter Pane is expandable and Elements of filter Pane',function () {
						  console.log('Issuer_Management_009,010 started execution');
						  var testData=require('../../../testData/issuerPageData.json');	
						  var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

                         
						   issuer_page.clickOnissuerFilterButton();
						  browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
						  issuer_page.filter_Apply_ButtonIsPresent();
						  issuer_page.filter_Clear_ButtonIsPresent();
						  issuer_page.filter_IssuerCode_drpdwnIsPresent();
						  issuer_page.filter_IssuerNameIsPresent();
						  issuer_page.filter_Issuer_DebitorIsPresent();
						  issuer_page.filter_Issuer_DisponentIsPresent();		
						  issuer_page.filter_CloseIconIsPresent();
						  console.log('Verify that Filter Pane is expandable and Elements of filter Pane');	  
						 	
						
					 });
					  
					
					  it('Issuer_Management_011: Verify that there is a provision Close/Collapse the Filter Pane.',function () {
						  console.log('Issuer_Management_009,010 started execution');
						  var testData=require('../../../testData/issuerPageData.json');	
						  var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

                         
						   issuer_page.clickOnissuerFilterButton();
						   browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
						   issuer_page.filter_Apply_ButtonIsPresent();
						   issuer_page.filter_Clear_ButtonIsPresent();
						   issuer_page.clickfilter_CloseIcon();
						   browser.sleep(5000).then(function(){console.log("Clicked on Filter close ICon")});
						   issuer_page.filter_Apply_ButtonIsNotPresent();
						   issuer_page.filter_Clear_ButtonIsNotPresent();						 
						   console.log('Vaerified provision for Close/Collapse the Filter Pane');	  
					  });	 


					   it('Issuer_Management_012: Verify search functionality by issuer Code',function () {
						  console.log('Issuer_Management_012 started execution');
						  var testData=require('../../../testData/issuerPageData.json');	
						  var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

                         
						   issuer_page.clickOnissuerFilterButton();
						   browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
						    issuer_page.clickOnFilterIssuerCodeDrpdwn();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});
						  issuer_page.selectFirstElementFromDropDown();
						  browser.sleep(5000).then(function(){console.log("Select 1st element from dropdown")});
						  issuer_page.clickOnFilterApplyButton();
						  browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
						  issuer_page.rowCountInTable();
					  });	   

					it('Issuer_Management_013,15: Verify search functionality by partial issuer Code',function () {
								console.log('Issuer_Management_013,15 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								
								issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								issuer_page.clickOnFilterIssuerCodeDrpdwn();
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});
								 console.log('Partial='+testData.issuer.IssuerManagement013.partialIssuerCode);
								console.log('Full='+testData.issuer.IssuerManagement013.issuerCode);
								issuer_page.enterTextInFilterIssuerCodeDrpDown(testData.issuer.IssuerManagement013.partialIssuerCode);
								browser.sleep(5000).then(function(){console.log("entern text in issuer code input box")});
								issuer_page.selectParticularIssuer(testData.issuer.IssuerManagement013.issuerCode);
								//  products_page.selectFirstElementFromDropDown();
								browser.sleep(5000).then(function(){console.log("Select 1st element from dropdown")});
								issuer_page.clickOnFilterApplyButton();
								browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
								issuer_page.rowCountInTable();
							});	 

                     it('Issuer_Management_014,016:Verify search functionality using Code that do not belong to any Issuer.',function () {
								console.log('Issuer_Management_014,16 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								
								issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								issuer_page.clickOnFilterIssuerCodeDrpdwn();
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});
							
								issuer_page.enterTextInFilterIssuerCodeDrpDown(testData.issuer.IssuerManagement014.invalidIssuerCode);
								browser.sleep(5000).then(function(){console.log("entern text in issuer code input box")});
						 		issuer_page.issuerCodeNotPresentInDropDown();
							
						});	 

					it('Issuer_Management_019:Verify that user is able to search Issuer using Name',function () {
								console.log('Issuer_Management_019 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								
								issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement019.issuerName);
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});							
								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
								issuer_page.rowCountInTable();
							    issuer_page.getTextOfFirstRowIssuerName(testData.issuer.IssuerManagement019.issuerName);
								console.log('Verified search functionality using vlaid issuer Name');
						});	 	
						  
					it('Issuer_Management_020:Verify search functionality using Name that do not belong to any Issuer',function () {
								console.log('Issuer_Management_020 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								
								issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement020.invalidIssuerName);
								browser.sleep(5000).then(function(){console.log("enter text in Issuer name box")});							
								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
								issuer_page.firstRowFromTableNotPresent();
								console.log('Verified search functionality using invlaid issuer Name');	
					});	

					it('Issuer_Management_021:Verify search functionality using Name  Filter',function () {
								console.log('Issuer_Management_021 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								
								issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement021.invalidIssuerName);
								browser.sleep(5000).then(function(){console.log("enter text in Issuer name box")});							
								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
								issuer_page.firstRowFromTableNotPresent();
								console.log('Verified search functionality using invlaid issuer Name');	
								issuer_page.clearTextInfilter_IssuerName();
								issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement021.validIssuerName);
								issuer_page.clickOnFilterApplyButton();
								browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
								issuer_page.rowCountInTable();
					});			

		       it('Issuer_Management_022:Verify search using issuer code which belong to a Issuer but not present in Name of any Issuer',function () {
								console.log('Issuer_Management_022 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								
								issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement022.issuerCodeAsIssuerName);
								browser.sleep(5000).then(function(){console.log("enter text in Issuer name box")});							
								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
								issuer_page.firstRowFromTableNotPresent();
								console.log('Verify search using issuer code which belong to a Issuer but not present in Name of any Issuer');	
					});				    
						  

				it('Issuer_Management_025:Verify that user is able to search Issuer using Debitor',function () {
								console.log('Issuer_Management_025 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								
								issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								issuer_page.enterTextInFilterIssuerDebitor(testData.issuer.IssuerManagement025.debitor);
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});							
								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
								issuer_page.rowCountInTable();
							    issuer_page.getTextOfFirstRowDebitor(testData.issuer.IssuerManagement025.debitor);
								console.log('Verified search functionality using vlaid debitor');
						});	 	 
					
				it('Issuer_Management_026:Verify search functionality using Debitor that do not belong to any Issuer.',function () {
								console.log('Issuer_Management_026 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								
								issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								issuer_page.enterTextInFilterIssuerDebitor(testData.issuer.IssuerManagement026.invalidDebitor);
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});							
								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
								issuer_page.firstRowFromTableNotPresent();
								
					});	

					it('Issuer_Management_028:Verify search a code/Disponent/Name which belong to a Issuer but not present in Debitor of any Issuer.',function () {
								console.log('Issuer_Management_028 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								
								issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								issuer_page.enterTextInFilterIssuerDebitor(testData.issuer.IssuerManagement028.issuerCodeAsDebitor);
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});							
								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
								issuer_page.firstRowFromTableNotPresent();
								
					});	

					it('Issuer_Management_031:Verify that user is able to search Issuer using Disponent',function () {
								console.log('Issuer_Management_031 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								
								issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								issuer_page.enterTextInFilterIssuerDisponent(testData.issuer.IssuerManagement031.disponent);
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});							
								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
								issuer_page.rowCountInTable();
							    issuer_page.getTextOfFirstRowDisponent(testData.issuer.IssuerManagement031.disponent);
								console.log('Verified search functionality using vlaid disponent');
						});	 			
   

                it('Issuer_Management_032:Verify search functionality using Disponent that do not belong to any Issuer.',function () {
								console.log('Issuer_Management_032 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								
								issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								issuer_page.enterTextInFilterIssuerDisponent(testData.issuer.IssuerManagement032.invalidDisponent);
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});							
								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
								issuer_page.firstRowFromTableNotPresent();
							    
				 });

				it('Issuer_Management_034:Verify search a code/Disponent/Name which belong to a Issuer but not present in Disponent of any Issuer.',function () {
								console.log('Issuer_Management_034 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								
								issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								issuer_page.enterTextInFilterIssuerDisponent(testData.issuer.IssuerManagement034.issuerCodeAsDisponent);
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});							
								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
								issuer_page.firstRowFromTableNotPresent();
							    
						});	 	

				 it('Issuer_Management_037:Verify that user is able to search Issuer using all search filters.',function () {
								console.log('Issuer_Management_037 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								
                               issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								
								 
								//issuer_page.enterTextInFilterIssuerCodeDrpDown(testData.issuer.IssuerManagement037.issuerCode);
								//browser.sleep(5000).then(function(){console.log("entern text in issuer code input box")});
                                //issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement019.issuerName);
								issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement037.issuerName);
								issuer_page.clickOnFilterIssuerCodeDrpdwn();
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});
								issuer_page.selectParticularIssuer(testData.issuer.IssuerManagement037.issuerCode);    
                                browser.sleep(5000).then(function(){console.log("selected particular issuer from drop down")});
								
								// browser.sleep(3000).then(function(){console.log("enter text in issuer name")});
                                issuer_page.enterTextInFilterIssuerDebitor(testData.issuer.IssuerManagement037.debitor);
								issuer_page.enterTextInFilterIssuerDisponent(testData.issuer.IssuerManagement037.disponent);
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});							
								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
								issuer_page.rowCountInTable();
							    
					});	 

					 it('Issuer_Management_038:Verify that user is able to search Issuer using issuer code and Name ',function () {
								console.log('Issuer_Management_038 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								
                               issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								
								 
								//issuer_page.enterTextInFilterIssuerCodeDrpDown(testData.issuer.IssuerManagement037.issuerCode);
								//browser.sleep(5000).then(function(){console.log("entern text in issuer code input box")});
                                //issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement019.issuerName);
								issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement037.issuerName);
								issuer_page.clickOnFilterIssuerCodeDrpdwn();
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});
								issuer_page.selectParticularIssuer(testData.issuer.IssuerManagement037.issuerCode);    
                                browser.sleep(5000).then(function(){console.log("selected particular issuer from drop down")});		
							
                              							
								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
								issuer_page.rowCountInTable();
							    
					});	 
 
                    it('Issuer_Management_039:Verify that user is able to search debitor and disponent filters.',function () {
								console.log('Issuer_Management_039 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');								
                                issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								
								
								// browser.sleep(3000).then(function(){console.log("enter text in issuer name")});
                                issuer_page.enterTextInFilterIssuerDebitor(testData.issuer.IssuerManagement039.debitor);
								issuer_page.enterTextInFilterIssuerDisponent(testData.issuer.IssuerManagement039.disponent);
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});							
								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
								issuer_page.rowCountInTable();
							    
					});	 

   	 
               it('Issuer_Management_043:Verify that user is able to search Issuer using Name ,Debitor ,Disponent',function () {
								console.log('Issuer_Management_043 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								
                               issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								
								 
								//issuer_page.enterTextInFilterIssuerCodeDrpDown(testData.issuer.IssuerManagement037.issuerCode);
								//browser.sleep(5000).then(function(){console.log("entern text in issuer code input box")});
                                //issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement019.issuerName);
								issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement043.issuerName);
								
								
								// browser.sleep(3000).then(function(){console.log("enter text in issuer name")});
                                issuer_page.enterTextInFilterIssuerDebitor(testData.issuer.IssuerManagement043.debitor);
								issuer_page.enterTextInFilterIssuerDisponent(testData.issuer.IssuerManagement043.disponent);
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});							
								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
								issuer_page.rowCountInTable();
							    
					});	 

					 it('Issuer_Management_046:Verify the elements of Issuer Details screen.',function () {
								console.log('Issuer_Management_046 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								
                               issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								
								 
								issuer_page.clickOnFilterIssuerCodeDrpdwn();
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});
								issuer_page.selectParticularIssuer(testData.issuer.IssuerManagement046.issuerCode);    
                                browser.sleep(5000).then(function(){console.log("selected particular issuer from drop down")});									
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
							    var details_Issuer=	issuer_page.clickOnfirstRowIssuerCode();
								browser.sleep(20000).then(function(){console.log("Click on 1st record")});
							    details_Issuer.detailsIssuerEditButtonIsPresent();
								details_Issuer.detailsIssuerBackButtonIsPresent();
					});	

                   it('Issuer_Management_047:Verify the elements of Issuer Details screen.',function () {
								console.log('Issuer_Management_047 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								
                               issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement047.issuerName);							
                                issuer_page.enterTextInFilterIssuerDebitor(testData.issuer.IssuerManagement047.debitor);
								issuer_page.enterTextInFilterIssuerDisponent(testData.issuer.IssuerManagement047.disponent);
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});							
								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(10000).then(function(){console.log("Click on filter Apply Btn")});
							    var details_Issuer=	issuer_page.clickOnfirstRowIssuerCode();
								browser.sleep(20000).then(function(){console.log("Click on 1st record")});

								 browser.getCurrentUrl().then(function(url) {
										console.log("URL= "+ url);
										expect(url).toContain('details');	
									});	
							   // expect(browser.getCurrentUrl()).toContain('details');
								issuer_page=details_Issuer.clickOnDetailsBackButton();
								browser.sleep(20000).then(function(){console.log("Clicked on Back Button")});

								 browser.getCurrentUrl().then(function(url) {
										console.log("URL= "+ url);
										expect(url).toContain('issuers');	
									});	
								//expect(browser.getCurrentUrl()).toContain('issuers');

								issuer_page.rowCountInTable();
					});	

					 it('Issuer_Management_048:Verify that user is able to search Issuer using all search filters.',function () {
								console.log('Issuer_Management_048 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								
                               issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
							
								issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement048.issuerName);
								issuer_page.clickOnFilterIssuerCodeDrpdwn();
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});
								issuer_page.selectParticularIssuer(testData.issuer.IssuerManagement048.issuerCode);    
                                browser.sleep(5000).then(function(){console.log("selected particular issuer from drop down")});
								
								// browser.sleep(3000).then(function(){console.log("enter text in issuer name")});
                                issuer_page.enterTextInFilterIssuerDebitor(testData.issuer.IssuerManagement048.debitor);
								issuer_page.enterTextInFilterIssuerDisponent(testData.issuer.IssuerManagement048.disponent);
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});							
								
						 		issuer_page.clickOnFilterClearButton();
								browser.sleep(20000).then(function(){console.log("Click on filter Clear Btn")});
								issuer_page.clickOnFilterIssuerCodeDrpdwn();
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});
								issuer_page.getTextOfFilterIssuerCodeDrpdown();
								issuer_page.getTextOfFilterIssuerName();
								issuer_page.getTextOfFilterIssuerDebitor();
								issuer_page.getTextOfFilterIssuerDisponent();
							    
					});	 

					 it('Issuer_Management_049:Verify that upon clear, Filters and Search results are set to default.',function () {
								console.log('Issuer_Management_049 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								
                                issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
							
								issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement048.issuerName);
								issuer_page.clickOnFilterIssuerCodeDrpdwn();
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});
								issuer_page.selectParticularIssuer(testData.issuer.IssuerManagement048.issuerCode);    
                                browser.sleep(5000).then(function(){console.log("selected particular issuer from drop down")});
								
								// browser.sleep(3000).then(function(){console.log("enter text in issuer name")});
                                issuer_page.enterTextInFilterIssuerDebitor(testData.issuer.IssuerManagement048.debitor);
								issuer_page.enterTextInFilterIssuerDisponent(testData.issuer.IssuerManagement048.disponent);
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});							
								issuer_page.clickOnFilterApplyButton();
								browser.sleep(20000).then(function(){console.log("Clicked on Filter Filter Apply Button")});
						 		issuer_page.clickOnFilterClearButton();
								browser.sleep(20000).then(function(){console.log("Click on filter Clear Btn")});
								issuer_page.clickOnFilterIssuerCodeDrpdwn();
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});
								issuer_page.getTextOfFilterIssuerCodeDrpdown();
								issuer_page.getTextOfFilterIssuerName();
								issuer_page.getTextOfFilterIssuerDebitor();
								issuer_page.getTextOfFilterIssuerDisponent();	
								issuer_page.defaultRecordsInPage();						    
					});	 


                     it('Issuer_Management_058:Verify Pagination for default Issuer list.',function () {
								console.log('Issuer_Management_058 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								issuer_page.clickOnPageSizeSelector();
								browser.sleep(5000).then(function(){console.log("click page selector")});
							    issuer_page.selectParticularPageSize();
								browser.sleep(5000).then(function(){console.log("selectParticularPageSize =10")});
							
								issuer_page.clickOnNextSingleArrowOfPagination();
								browser.sleep(25000).then(function(){console.log("click on pagination arrow next")});
								issuer_page.verifyRecordsOnPage();
                              				    
					});	 


                  it('Issuer_Management_059:Verify Pagination for default Issuer list.',function () {
								console.log('Issuer_Management_059 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');


                                issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
							
								issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement059.issuerName);
								issuer_page.clickOnFilterApplyButton();
								browser.sleep(20000).then(function(){console.log("Clicked on Filter Filter Apply Button")});
    
								issuer_page.clickOnPageSizeSelector();
								browser.sleep(5000).then(function(){console.log("click page selector")});
							    issuer_page.selectParticularPageSize();
								browser.sleep(5000).then(function(){console.log("selectParticularPageSize =10")});
							
								issuer_page.clickOnNextSingleArrowOfPagination();
								browser.sleep(25000).then(function(){console.log("click on pagination arrow next")});
								issuer_page.verifyRecordsOnPage();
                              				    
					});	 

					 it('Issuer_Management_060:Verify that user has a provision to view Issuer hierarchy',function () {
								console.log('Issuer_Management_060 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
								issuer_page.issuerHierarchyIconButtonForEachIssuer();
								console.log('issuer hierarchy icon verified for each issuer on page');                               
                              				    
					});	 

                it('Issuer_Management_061:Verify that user is able to view Issuer hierarchy.',function () {
								console.log('Issuer_Management_061 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
							
							    issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
							
								issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement061.issuerName);
								issuer_page.clickOnFilterApplyButton();
								browser.sleep(20000).then(function(){console.log("Clicked on Filter Apply Button")});
								issuer_page.clickOnFirstRowIssuerHierarchyIcon();   
								browser.sleep(5000).then(function(){console.log("Clicked on Issuer hierarchy Icon")}); 
								issuer_page.verifyNameOfHighlightedIssuer(testData.issuer.IssuerManagement061.issuerName);
								issuer_page.clickOnIssuerHierarchyCloseIcon();              
                              	browser.sleep(5000).then(function(){console.log("Clicked on Issuer hierarchy close Icon")}); 			    
					});	 

					it('Issuer_Management_062:Verify that user is able to view Issuer hierarchy.',function () {
								console.log('Issuer_Management_062 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

								issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
                               
								issuer_page.clickOnFilterIssuerCodeDrpdwn();
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});
								issuer_page.selectParticularIssuer(testData.issuer.IssuerManagement062.issuerCode);    
                                browser.sleep(5000).then(function(){console.log("selected particular issuer from drop down")});
								
								// browser.sleep(3000).then(function(){console.log("enter text in issuer name")});
                                issuer_page.enterTextInFilterIssuerDebitor(testData.issuer.IssuerManagement062.debitor);
								issuer_page.enterTextInFilterIssuerDisponent(testData.issuer.IssuerManagement062.disponent);
								browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});  			 
							
							
								issuer_page.clickOnFilterApplyButton();
								browser.sleep(20000).then(function(){console.log("Clicked on Filter Apply Button")});
								issuer_page.clickOnFirstRowIssuerHierarchyIcon();   
								browser.sleep(5000).then(function(){console.log("Clicked on Issuer hierarchy Icon")}); 
								issuer_page.verifyNameOfHighlightedIssuer(testData.issuer.IssuerManagement062.issuerName);
								issuer_page.clickOnIssuerHierarchyCloseIcon();              
                              	browser.sleep(5000).then(function(){console.log("Clicked on Issuer hierarchy close Icon")}); 			    
					});	 

                   	it('Issuer_Management_063:Verify that user is able to Navigate Create Issuer screen.',function () {
								console.log('Issuer_Management_063 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                     
					          issuer_page.clickOnIssuerCreateButton();
							   	browser.sleep(5000).then(function(){console.log("Clicked on Issuer create button")}); 
                                 // expect(browser.getCurrentUrl()).toContain(testData.issuer.IssuerManagement063.urlContain);

								   browser.getCurrentUrl().then(function(url) {
										console.log("URL= "+ url);
										expect(url).toContain(testData.issuer.IssuerManagement063.urlContain);	
									});	
					   });


				it('Issuer_Management_064:Verify default elements of Create Issuer screen.',function () {
								console.log('Issuer_Management_064 started execution');
								var testData=require('../../../testData/issuerPageData.json');	
								var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                     
					        var create_Issuer= issuer_page.clickOnIssuerCreateButton();
							 browser.sleep(10000).then(function(){console.log("Clicked on Issuer create button")});

							 create_Issuer.createIssuerCodeIsPresent();
							 create_Issuer.createIssuerNameIsPresent();
							 create_Issuer.createIssuerDebitorIsPresent();
							 create_Issuer.createIssuerDisponentIsPresent();
							 create_Issuer.createIssuerValidFromIsPresent();
							 create_Issuer.createIssuerValidToIsPresent();
							 create_Issuer.createIssuerSubisidiaryDrpDwnIsPresent();
							 create_Issuer.createParentIssuerDrpDwnIsPresent();
							 create_Issuer.defaultLanguageDrpDwnIsPresent();
							 create_Issuer.documentRetentionPeriodInputIsPresent();
							 create_Issuer.documentRetentionUnitInputIsPresent();
							 create_Issuer.notificationRetentionPeriodInputIsPresent();
							 create_Issuer.notificationRetentionUnitInputIsPresent();
							 create_Issuer.uploadLogoBtnIsPresent();
							 create_Issuer.shipmentProviderAddIconIsPresent();

							 create_Issuer.clickOnShipmentProviderAddIcon();
                              browser.sleep(5000).then(function(){console.log("Clicked on Shipment provider add icon")});
                            create_Issuer.shipmentProviderCodeDrpwnIsPresent();
							create_Issuer.shipmentDescriptionIsPresent();
							create_Issuer.shipmentDescriptionIsPresent();
							create_Issuer.shipmentValidToIsPresent();
							create_Issuer.selectShipmentMethodsDrpwnIsPresent();
							create_Issuer.shipmentDeleteIconIsPresent();

					   });	   

                   	it('Issuer_Management_065:Verify that user is able to create new Issuer with Mandatory fields only',function () {
								console.log('Issuer_Management_065 started execution');

                             var testData=require('../../../testData/issuerPageData.json');	
							 var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                             var create_Issuer= issuer_page.clickOnIssuerCreateButton();
							 browser.sleep(5000).then(function(){console.log("Clicked on Issuer create button")});
                             create_Issuer.eneterTextInCreateIssuerCode(testData.issuer.IssuerManagement065.issuerCode);
							 create_Issuer.eneterTextInCreateIssuerName(testData.issuer.IssuerManagement065.issuerName);							
							 create_Issuer.eneterTextInValidDateFrom(testData.issuer.IssuerManagement065.validFrom);
							 create_Issuer.eneterTextInValidDateTo(testData.issuer.IssuerManagement065.validTo);
                             create_Issuer.clickOnIssuerSubsidiaryDrpDwn();
							  browser.sleep(5000).then(function(){console.log("Issuer Subisdiary Drp Dwn")});
							 create_Issuer.selectParticularIssuerSubsidiaryCode(testData.issuer.IssuerManagement065.SubsidiaryCode);

                             create_Issuer.clickOnDefaultLanguageDrpDwn();
							  browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
                              create_Issuer.selectParticularLanguage(testData.issuer.IssuerManagement065.language);
                             create_Issuer.eneterTextInNotificationRetentionPeriod(testData.issuer.IssuerManagement065.notificationRetentionPeriod);
						
                             issuer_page=create_Issuer.clickOnSaveButton();
							  browser.sleep(30000).then(function(){console.log("Click On save btn")});

							  issuer_page.clickOnissuerFilterButton();
							  browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
							
							  issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement065.issuerName);
							  issuer_page.clickOnFilterIssuerCodeDrpdwn();
							  browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});
							  issuer_page.selectParticularIssuer(testData.issuer.IssuerManagement065.issuerCode);    
                              browser.sleep(5000).then(function(){console.log("selected particular issuer from drop down")});
                              issuer_page.clickOnFilterApplyButton();
                              browser.sleep(20000).then(function(){console.log("Clicked on Filter Apply Btn")});
							  issuer_page.rowCountInTable();

					});		


                  	it('Issuer_Management_069,70,71,72:Verify that user is able to create new Issuer with All fields ',function () {
								console.log('Issuer_Management_069 started execution');

                             var testData=require('../../../testData/issuerPageData.json');
							 var testData1=require('../../../testData/loginPage.json');
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                              var create_Issuer= issuer_page.clickOnIssuerCreateButton();
							 browser.sleep(5000).then(function(){console.log("Clicked on Issuer create button")});
                             create_Issuer.eneterTextInCreateIssuerCode(testData.issuer.IssuerManagement069.issuerCode);
							 create_Issuer.eneterTextInCreateIssuerName(testData.issuer.IssuerManagement069.issuerName);
							 create_Issuer.eneterTextInCreateIssuerDebitor(testData.issuer.IssuerManagement069.debitor);
							 create_Issuer.eneterTextInCreateIssuerDisponent(testData.issuer.IssuerManagement069.disponent);
							 create_Issuer.eneterTextInValidDateFrom(testData.issuer.IssuerManagement069.validFrom);
							 create_Issuer.eneterTextInValidDateTo(testData.issuer.IssuerManagement069.validTo);
 
							 create_Issuer.clickOnIssuerSubsidiaryDrpDwn();
							  browser.sleep(5000).then(function(){console.log("Issuer Subisdiary Drp Dwn")});

							 create_Issuer.selectParticularIssuerSubsidiaryCode(testData.issuer.IssuerManagement069.SubsidiaryCode);


                             create_Issuer.clickOnParentIssuerDrpDwn();
							  browser.sleep(5000).then(function(){console.log("Click on Paren Issuer Drpdwn")});
							  create_Issuer.selectParticularParentIssuer(testData.issuer.IssuerManagement069.parentIssuer);
							 create_Issuer.clickOnDefaultLanguageDrpDwn();
							  browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
                              create_Issuer.selectParticularLanguage(testData.issuer.IssuerManagement069.language);

							 create_Issuer.eneterTextInDocumentRetentionPeriod(testData.issuer.IssuerManagement069.documentRetentionPeriod);
						     
						

							 create_Issuer.eneterTextInNotificationRetentionPeriod(testData.issuer.IssuerManagement069.notificationRetentionPeriod);
						

							 create_Issuer.clickOnSaveButton();
							  browser.sleep(30000).then(function(){console.log("clicked on Save Btn")});



							  issuer_page.clickOnissuerFilterButton();
							  browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
							
							  issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement069.issuerName);
							  issuer_page.clickOnFilterIssuerCodeDrpdwn();
							  browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});
							  issuer_page.selectParticularIssuer(testData.issuer.IssuerManagement069.issuerCode);    
                              browser.sleep(5000).then(function(){console.log("selected particular issuer from drop down")});
							    issuer_page.clickOnFilterApplyButton();
                              browser.sleep(20000).then(function(){console.log("Clicked on Filter Apply Btn")});
							  issuer_page.getTextOfFirstRowUpdatedBy();
							  issuer_page.getTextOfFirstRowUpdatedOn();
							  issuer_page.rowCountInTable();

							  var detailsIssuer_page = issuer_page.clickOnfirstRowIssuerCode();
							  browser.sleep(20000).then(function(){console.log("Clicked on Issuer code to navigate to Details Page")});
							  detailsIssuer_page.verifyTextOfUpdatedOn();
							  detailsIssuer_page.verifyTextOfUpdatedBy();
							  detailsIssuer_page.verifyTextOfCreatedBy(testData1.authentication.login.username);

					});		

                  	it('Issuer_Management_088:Verify that Subsidiary selection is mandatory while creating a new Issuer ',function () {
								console.log('Issuer_Management_088 started execution');
                                
							 var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                            
							 var create_Issuer= issuer_page.clickOnIssuerCreateButton();                             
							 browser.sleep(5000).then(function(){console.log("Clicked on Issuer create button")});
                             create_Issuer.eneterTextInCreateIssuerCode(testData.issuer.IssuerManagement087.issuerCode);
							 create_Issuer.eneterTextInCreateIssuerName(testData.issuer.IssuerManagement087.issuerName);							
							 create_Issuer.eneterTextInValidDateFrom(testData.issuer.IssuerManagement087.validFrom);
							 create_Issuer.eneterTextInValidDateTo(testData.issuer.IssuerManagement087.validTo);                          

                             create_Issuer.clickOnDefaultLanguageDrpDwn();
							  browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
                              create_Issuer.selectParticularLanguage(testData.issuer.IssuerManagement087.language);
                             create_Issuer.eneterTextInNotificationRetentionPeriod(testData.issuer.IssuerManagement087.notificationRetentionPeriod);

							  create_Issuer.clickOnSaveButton();
							  browser.sleep(30000).then(function(){console.log("clicked on Save Btn")});
                              create_Issuer.verifyMissingSubsidiaryErrorMessage(testData.issuer.IssuerManagement087.missingSubsidiaryErrorMSg);
					  });			
   
                   	it('Issuer_Management_093:System should allow to add issuer horizontally and vertically in the hierarchy',function () {
								console.log('Issuer_Management_093 started execution');
                                
							 var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
	                           

						 for (var i in testData.issuer.IssuerManagement092) {   							
                              var create_Issuer= issuer_page.clickOnIssuerCreateButton();
							 browser.sleep(5000).then(function(){console.log("Clicked on Issuer create button")});
                             create_Issuer.eneterTextInCreateIssuerCode(testData.issuer.IssuerManagement092[i].issuerCode);
							 create_Issuer.eneterTextInCreateIssuerName(testData.issuer.IssuerManagement092[i].issuerName);
							 create_Issuer.eneterTextInCreateIssuerDebitor(testData.issuer.IssuerManagement092[i].debitor);
							 create_Issuer.eneterTextInCreateIssuerDisponent(testData.issuer.IssuerManagement092[i].disponent);
							 create_Issuer.eneterTextInValidDateFrom(testData.issuer.IssuerManagement092[i].validFrom);
							 create_Issuer.eneterTextInValidDateTo(testData.issuer.IssuerManagement092[i].validTo);
 
							 create_Issuer.clickOnIssuerSubsidiaryDrpDwn();
							  browser.sleep(5000).then(function(){console.log("Issuer Subisdiary Drp Dwn")});

							 create_Issuer.selectParticularIssuerSubsidiaryCode(testData.issuer.IssuerManagement092[i].SubsidiaryCode);


                             create_Issuer.clickOnParentIssuerDrpDwn();
							  browser.sleep(5000).then(function(){console.log("Click on Paren Issuer Drpdwn")});
							  create_Issuer.selectParticularParentIssuer(testData.issuer.IssuerManagement092[i].parentIssuer);
							 create_Issuer.clickOnDefaultLanguageDrpDwn();
							  browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
                              create_Issuer.selectParticularLanguage(testData.issuer.IssuerManagement092[i].language);

							 create_Issuer.eneterTextInDocumentRetentionPeriod(testData.issuer.IssuerManagement092[i].documentRetentionPeriod);
						     
						

							 create_Issuer.eneterTextInNotificationRetentionPeriod(testData.issuer.IssuerManagement092[i].notificationRetentionPeriod);
						

							 issuer_page= create_Issuer.clickOnSaveButton();
							  browser.sleep(30000).then(function(){console.log("clicked on Save Btn")});
														
						 }
					   });


					 it('Issuer_Management_096:System should not allowed to create looping within hierarchy. Means, child can’t be parent of his own parent',function () {
								console.log('Issuer_Management_096 started execution');
                                
							 var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
						
					            issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement096.issuer);
								browser.sleep(5000).then(function(){console.log("enter text in Issuer name box")});							
								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(20000).then(function(){console.log("Click on filter Apply Btn")});
								var edit_page=issuer_page.clickOnFirstRowsEditButton();
								browser.sleep(20000).then(function(){console.log("Click on Edit Btn")});
								edit_page.clickOnParentIssuerDrpdwn();
								browser.sleep(10000).then(function(){console.log("Click on Edit parent issuer drpdwn")});
								edit_page.elementNotPresentInParentIssuerDrpdwn(testData.issuer.IssuerManagement096.chanageParentIssuerTo);				
			          });

				it('Issuer_Management_111:Verify that * mark is present against each mandatory field.',function () {
						   
						   console.log('Issuer_Management_111 started execution');
                                
							 var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
	                        				   							
                             var create_Issuer= issuer_page.clickOnIssuerCreateButton();
							 browser.sleep(5000).then(function(){console.log("Clicked on Create Button")});
                             create_Issuer.issuerNameStarIsPresent();
							 create_Issuer.issuerCodeStarIsPresent();
							 create_Issuer.subsidiaryStarIsPresent();
							 create_Issuer.validFromStarIsPresent();
							 create_Issuer.validToStarIsPresent();
							 console.log('* is present for mandatory fields');
						
					});	  



						it('Issuer_Management_112:Verify that Issuer is not created when Issuer Code is missing',function () {
								console.log('Issuer_Management_112 started execution');
                                
							 var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                            
							 var create_Issuer= issuer_page.clickOnIssuerCreateButton();                             
							 browser.sleep(5000).then(function(){console.log("Clicked on Issuer create button")});
                           //  create_Issuer.eneterTextInCreateIssuerCode(testData.issuer.IssuerManagement087.issuerCode);
							 create_Issuer.eneterTextInCreateIssuerName(testData.issuer.IssuerManagement112.issuerName);							
							 create_Issuer.eneterTextInValidDateFrom(testData.issuer.IssuerManagement112.validFrom);
							 create_Issuer.eneterTextInValidDateTo(testData.issuer.IssuerManagement112.validTo);                          
                              
							 create_Issuer.clickOnIssuerSubsidiaryDrpDwn();
							 browser.sleep(5000).then(function(){console.log("Issuer Subisdiary Drp Dwn")});
							 create_Issuer.selectParticularIssuerSubsidiaryCode(testData.issuer.IssuerManagement112.SubsidiaryCode);
                            
							 create_Issuer.clickOnDefaultLanguageDrpDwn();
							 browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
                              create_Issuer.selectParticularLanguage(testData.issuer.IssuerManagement112.language);
                             create_Issuer.eneterTextInNotificationRetentionPeriod(testData.issuer.IssuerManagement112.notificationRetentionPeriod);
                            
							  create_Issuer.clickOnSaveButton();
							  browser.sleep(30000).then(function(){console.log("clicked on Save Btn")});
                              create_Issuer.verifyMissingIssuerCodeErrorMessage(testData.issuer.IssuerManagement112.issuerErrorCodeMsg);
					  });	

					  it('Issuer_Management_114:Verify that Issuer is not created when Issuer Name is missing',function () {
								console.log('Issuer_Management_114 started execution');
                                
							 var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                            
							 var create_Issuer= issuer_page.clickOnIssuerCreateButton();                             
							 browser.sleep(5000).then(function(){console.log("Clicked on Issuer create button")});
                             create_Issuer.eneterTextInCreateIssuerCode(testData.issuer.IssuerManagement112.issuerCode);
						    // create_Issuer.eneterTextInCreateIssuerName(testData.issuer.IssuerManagement112.issuerName);							
							 create_Issuer.eneterTextInValidDateFrom(testData.issuer.IssuerManagement112.validFrom);
							 create_Issuer.eneterTextInValidDateTo(testData.issuer.IssuerManagement112.validTo);                          
                              
							 create_Issuer.clickOnIssuerSubsidiaryDrpDwn();
							 browser.sleep(5000).then(function(){console.log("Issuer Subisdiary Drp Dwn")});
							 create_Issuer.selectParticularIssuerSubsidiaryCode(testData.issuer.IssuerManagement112.SubsidiaryCode);
                            
							 create_Issuer.clickOnDefaultLanguageDrpDwn();
							 browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
                              create_Issuer.selectParticularLanguage(testData.issuer.IssuerManagement112.language);
                             create_Issuer.eneterTextInNotificationRetentionPeriod(testData.issuer.IssuerManagement112.notificationRetentionPeriod);
                            
							  create_Issuer.clickOnSaveButton();
							  browser.sleep(30000).then(function(){console.log("clicked on Save Btn")});
                              create_Issuer.verifyMissingIssuerNameErrorMessage(testData.issuer.IssuerManagement112.issuerNameErrorMsg);
					  });

					  it('Issuer_Management_116:Verify that Issuer is not created when Issuer Subsidiary is missing',function () {
								console.log('Issuer_Management_116 started execution');
                                
							 var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                            
							 var create_Issuer= issuer_page.clickOnIssuerCreateButton();                             
							 browser.sleep(5000).then(function(){console.log("Clicked on Issuer create button")});
                             create_Issuer.eneterTextInCreateIssuerCode(testData.issuer.IssuerManagement112.issuerCode);
						     create_Issuer.eneterTextInCreateIssuerName(testData.issuer.IssuerManagement112.issuerName);							
							 create_Issuer.eneterTextInValidDateFrom(testData.issuer.IssuerManagement112.validFrom);
							 create_Issuer.eneterTextInValidDateTo(testData.issuer.IssuerManagement112.validTo);                       
                              
							
                            
							 create_Issuer.clickOnDefaultLanguageDrpDwn();
							 browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
                              create_Issuer.selectParticularLanguage(testData.issuer.IssuerManagement112.language);
                             create_Issuer.eneterTextInNotificationRetentionPeriod(testData.issuer.IssuerManagement112.notificationRetentionPeriod);
                            
							  create_Issuer.clickOnSaveButton();
							  browser.sleep(30000).then(function(){console.log("clicked on Save Btn")});
                              create_Issuer.verifyMissingSubsidiaryErrorMessage(testData.issuer.IssuerManagement112.subsidiaryErrorMsg);
					  });	

					  it('Issuer_Management_122:Verify the error message when all the mandatory fields are missing.',function () {
								console.log('Issuer_Management_122 started execution');
                                
							 var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                            
							 var create_Issuer= issuer_page.clickOnIssuerCreateButton();                             
							 browser.sleep(5000).then(function(){console.log("Clicked on Issuer create button")});
                             
							  create_Issuer.clickOnSaveButton();
							  browser.sleep(30000).then(function(){console.log("clicked on Save Btn")});
                              create_Issuer.verifyMissingIssuerCodeErrorMessage(testData.issuer.IssuerManagement112.issuerErrorCodeMsg);
							  create_Issuer.verifyMissingSubsidiaryErrorMessage(testData.issuer.IssuerManagement112.subsidiaryErrorMsg);
							  create_Issuer.verifyMissingIssuerNameErrorMessage(testData.issuer.IssuerManagement112.issuerNameErrorMsg);
					  });	

					 it('Issuer_Management_124:Verify the error message when (Issuer Code and Name) mandatory fields are missing.',function () {
								console.log('Issuer_Management_124 started execution');
                                
							 var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                            
							 var create_Issuer= issuer_page.clickOnIssuerCreateButton();                             
							 browser.sleep(5000).then(function(){console.log("Clicked on Issuer create button")});
                             
                             //  create_Issuer.eneterTextInCreateIssuerCode(testData.issuer.IssuerManagement112.issuerCode);
						    // create_Issuer.eneterTextInCreateIssuerName(testData.issuer.IssuerManagement112.issuerName);							
							 create_Issuer.eneterTextInValidDateFrom(testData.issuer.IssuerManagement112.validFrom);
							 create_Issuer.eneterTextInValidDateTo(testData.issuer.IssuerManagement112.validTo);                          
                              
							 create_Issuer.clickOnIssuerSubsidiaryDrpDwn();
							 browser.sleep(5000).then(function(){console.log("Issuer Subisdiary Drp Dwn")});
							 create_Issuer.selectParticularIssuerSubsidiaryCode(testData.issuer.IssuerManagement112.SubsidiaryCode);
                            
							 create_Issuer.clickOnDefaultLanguageDrpDwn();
							 browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
                              create_Issuer.selectParticularLanguage(testData.issuer.IssuerManagement112.language);
                             create_Issuer.eneterTextInNotificationRetentionPeriod(testData.issuer.IssuerManagement112.notificationRetentionPeriod);
                            

							  create_Issuer.clickOnSaveButton();
							  browser.sleep(30000).then(function(){console.log("clicked on Save Btn")});
                              create_Issuer.verifyMissingIssuerCodeErrorMessage(testData.issuer.IssuerManagement112.issuerErrorCodeMsg);
							 // create_Issuer.verifyMissingSubsidiaryErrorMessage(testData.issuer.IssuerManagement112.subsidiaryErrorMsg);
							  create_Issuer.verifyMissingIssuerNameErrorMessage(testData.issuer.IssuerManagement112.issuerNameErrorMsg);
					  });		 		 
	 		 

			  xit('Issuer_Management_125:Verify the error message when (Subsidiary and Name) mandatory fields are missing.',function () {
							console.log('Issuer_Management_125 started execution');
                                
							 var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                            
							 var create_Issuer= issuer_page.clickOnIssuerCreateButton();                             
							 browser.sleep(5000).then(function(){console.log("Clicked on Issuer create button")});
                             
                              create_Issuer.eneterTextInCreateIssuerCode(testData.issuer.IssuerManagement112.issuerCode);
						    // create_Issuer.eneterTextInCreateIssuerName(testData.issuer.IssuerManagement112.issuerName);							
							 create_Issuer.eneterTextInValidDateFrom(testData.issuer.IssuerManagement112.validFrom);
							 create_Issuer.eneterTextInValidDateTo(testData.issuer.IssuerManagement112.validTo);                          
                              
							
							 create_Issuer.clickOnDefaultLanguageDrpDwn();
							 browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
                              create_Issuer.selectParticularLanguage(testData.issuer.IssuerManagement112.language);
                             create_Issuer.eneterTextInNotificationRetentionPeriod(testData.issuer.IssuerManagement112.notificationRetentionPeriod);
                            

							  create_Issuer.clickOnSaveButton();
							  browser.sleep(30000).then(function(){console.log("clicked on Save Btn")});
                              //create_Issuer.verifyMissingIssuerCodeErrorMessage(testData.issuer.IssuerManagement112.issuerErrorCodeMsg);
							  create_Issuer.verifyMissingSubsidiaryErrorMessage(testData.issuer.IssuerManagement112.subsidiaryErrorMsg);
							  create_Issuer.verifyMissingIssuerNameErrorMessage(testData.issuer.IssuerManagement112.issuerNameErrorMsg);
					  });

				   it('Issuer_Management_126:Verify that user is not able to create Issuer with Duplicate Issuer Code',function () {
								console.log('Issuer_Management_126 started execution');
                                
							 var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                            
							 var create_Issuer= issuer_page.clickOnIssuerCreateButton();                             
							 browser.sleep(5000).then(function(){console.log("Clicked on Issuer create button")});
                             
                              create_Issuer.eneterTextInCreateIssuerCode(testData.issuer.IssuerManagement112.duplicateIssuerCode);
						     create_Issuer.eneterTextInCreateIssuerName(testData.issuer.IssuerManagement112.issuerName);							
							 create_Issuer.eneterTextInValidDateFrom(testData.issuer.IssuerManagement112.validFrom);
							 create_Issuer.eneterTextInValidDateTo(testData.issuer.IssuerManagement112.validTo);                          
                              
							 create_Issuer.clickOnIssuerSubsidiaryDrpDwn();
							 browser.sleep(5000).then(function(){console.log("Issuer Subisdiary Drp Dwn")});
							 create_Issuer.selectParticularIssuerSubsidiaryCode(testData.issuer.IssuerManagement112.SubsidiaryCode);
                            
							 create_Issuer.clickOnDefaultLanguageDrpDwn();
							 browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
                              create_Issuer.selectParticularLanguage(testData.issuer.IssuerManagement112.language);
                             create_Issuer.eneterTextInNotificationRetentionPeriod(testData.issuer.IssuerManagement112.notificationRetentionPeriod);
                            

							  create_Issuer.clickOnSaveButton();
							  browser.sleep(30000).then(function(){console.log("clicked on Save Btn")});
                             
							  create_Issuer.verifyDuplicateIssuerCodeMsg(testData.issuer.IssuerManagement112.duplicateIssuerCodeErrorMsg);
					  });	


					  it('Issuer_Management_127:Verify that Issuer is not created when Valid From > Valid To',function () {
								console.log('Issuer_Management_127 started execution');
                                
							 var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                            
							 var create_Issuer= issuer_page.clickOnIssuerCreateButton();                             
							 browser.sleep(5000).then(function(){console.log("Clicked on Issuer create button")});
                             
                              create_Issuer.eneterTextInCreateIssuerCode(testData.issuer.IssuerManagement112.issuerCode);
						     create_Issuer.eneterTextInCreateIssuerName(testData.issuer.IssuerManagement112.issuerName);							
							 create_Issuer.eneterTextInValidDateFrom(testData.issuer.IssuerManagement112.validFrom);
							 create_Issuer.eneterTextInValidDateTo(testData.issuer.IssuerManagement112.validToGreaterThanValidFrom);                          
                              
							 create_Issuer.clickOnIssuerSubsidiaryDrpDwn();
							 browser.sleep(5000).then(function(){console.log("Issuer Subisdiary Drp Dwn")});
							 create_Issuer.selectParticularIssuerSubsidiaryCode(testData.issuer.IssuerManagement112.SubsidiaryCode);
                            
							 create_Issuer.clickOnDefaultLanguageDrpDwn();
							 browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
                              create_Issuer.selectParticularLanguage(testData.issuer.IssuerManagement112.language);
                             create_Issuer.eneterTextInNotificationRetentionPeriod(testData.issuer.IssuerManagement112.notificationRetentionPeriod);
                            

							  create_Issuer.clickOnSaveButton();
							  browser.sleep(30000).then(function(){console.log("clicked on Save Btn")});
                             
							  create_Issuer.verifyDuplicateIssuerCodeMsg(testData.issuer.IssuerManagement112.fromDateGreaterThanToDateErrMsg);
					  });		

					 it('Issuer_Management_132:Verify when other than numeric value entered in Notification Retention Period field',function () {
								console.log('Issuer_Management_132 started execution');
                                
							 var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                            
							 var create_Issuer= issuer_page.clickOnIssuerCreateButton();                             
							 browser.sleep(5000).then(function(){console.log("Clicked on Issuer create button")});
                             
                              create_Issuer.eneterTextInCreateIssuerCode(testData.issuer.IssuerManagement112.issuerCode);
						     create_Issuer.eneterTextInCreateIssuerName(testData.issuer.IssuerManagement112.issuerName);							
							 create_Issuer.eneterTextInValidDateFrom(testData.issuer.IssuerManagement112.validFrom);
							 create_Issuer.eneterTextInValidDateTo(testData.issuer.IssuerManagement112.validTo);                          
                              
							 create_Issuer.clickOnIssuerSubsidiaryDrpDwn();
							 browser.sleep(5000).then(function(){console.log("Issuer Subisdiary Drp Dwn")});
							 create_Issuer.selectParticularIssuerSubsidiaryCode(testData.issuer.IssuerManagement112.SubsidiaryCode);
                            
							 create_Issuer.clickOnDefaultLanguageDrpDwn();
							 browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
                              create_Issuer.selectParticularLanguage(testData.issuer.IssuerManagement112.language);
                             create_Issuer.eneterTextInNotificationRetentionPeriod(testData.issuer.IssuerManagement112.wrongNotificationRetentionPeriod);
                            

							  create_Issuer.clickOnSaveButton();
							  browser.sleep(30000).then(function(){console.log("clicked on Save Btn")});
                             
							  create_Issuer.verifyWrongRetentionNotificationErrorMessage(testData.issuer.IssuerManagement112.wrongNotificationRetentionPeriodErrorMsg);
					  });	


				
					  it('Issuer_Management_133:Verify Upload Logo link.',function () {
								console.log('Issuer_Management_133 started execution');
                                
							 var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                             
						     var create_Issuer= issuer_page.clickOnIssuerCreateButton();                             
							 browser.sleep(5000).then(function(){console.log("Clicked on Issuer create button")});
							 create_Issuer.uploadLogoBtnIsPresent();
                             
					  });

					  it('Issuer_Management_146:Verify that user can Cancel the create request..',function () {
								console.log('Issuer_Management_146 started execution');
                                
							 var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                             
						     var create_Issuer= issuer_page.clickOnIssuerCreateButton();                             
							 browser.sleep(25000).then(function(){console.log("Clicked on Issuer create button")});
							 create_Issuer.clickOnCancelButton();
							  browser.sleep(25000).then(function(){console.log("Clicked on Cancel  button")});
							 // expect(browser.getCurrentUrl()).toContain(testData.issuer.IssuerManagement146.urlContain);
                             
							   browser.getCurrentUrl().then(function(url) {
										console.log("URL= "+ url);
										expect(url).toContain(testData.issuer.IssuerManagement146.urlContain);	
									});	
					  });	 	

					   it('Issuer_Management_147:Verify that user can Cancel the create request..',function () {
								console.log('Issuer_Management_147 started execution');
                                
						     var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                            
							 var create_Issuer= issuer_page.clickOnIssuerCreateButton();                             
							 browser.sleep(25000).then(function(){console.log("Clicked on Issuer create button")});
                             
                              create_Issuer.eneterTextInCreateIssuerCode(testData.issuer.IssuerManagement147.issuerCode);
						     create_Issuer.eneterTextInCreateIssuerName(testData.issuer.IssuerManagement147.issuerName);							
							 create_Issuer.eneterTextInValidDateFrom(testData.issuer.IssuerManagement147.validFrom);
							 create_Issuer.eneterTextInValidDateTo(testData.issuer.IssuerManagement147.validTo);                          
                              
							
                            
							  create_Issuer.clickOnCancelButton();
							  browser.sleep(25000).then(function(){console.log("Clicked on Cancel  button")});
							  create_Issuer.clickOnCanacelPopUpOk();
							  browser.sleep(25000).then(function(){console.log("Clicked on Cancel popup OK  button")});


							  //expect(browser.getCurrentUrl()).toContain(testData.issuer.IssuerManagement147.urlContain);

							   browser.getCurrentUrl().then(function(url) {
										console.log("URL= "+ url);
										expect(url).toContain(testData.issuer.IssuerManagement147.urlContain);	
									});	
                             
					  });	 	  		  		 		 
	 		 

			  it('Issuer_Management_148:Verify that user can Cancel the Cancel request.',function () {
								console.log('Issuer_Management_148 started execution');
                                
						     var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                            
							

							 var create_Issuer= issuer_page.clickOnIssuerCreateButton();
							 browser.sleep(5000).then(function(){console.log("Clicked on Issuer create button")});
                             create_Issuer.eneterTextInCreateIssuerCode(testData.issuer.IssuerManagement148.issuerCode);
							 create_Issuer.eneterTextInCreateIssuerName(testData.issuer.IssuerManagement148.issuerName);							
							 create_Issuer.eneterTextInValidDateFrom(testData.issuer.IssuerManagement148.validFrom);
							 create_Issuer.eneterTextInValidDateTo(testData.issuer.IssuerManagement148.validTo);
 
							 create_Issuer.clickOnIssuerSubsidiaryDrpDwn();
							  browser.sleep(5000).then(function(){console.log("Issuer Subisdiary Drp Dwn")});

							 create_Issuer.selectParticularIssuerSubsidiaryCode(testData.issuer.IssuerManagement148.SubsidiaryCode);


                          
							 create_Issuer.clickOnDefaultLanguageDrpDwn();
							  browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
                              create_Issuer.selectParticularLanguage(testData.issuer.IssuerManagement148.language);

						

							 create_Issuer.eneterTextInNotificationRetentionPeriod(testData.issuer.IssuerManagement148.notificationRetentionPeriod);
							
							 create_Issuer.clickOnCancelButton();
							  browser.sleep(25000).then(function(){console.log("clicked on Cancel Btn")});
							  create_Issuer.clickOnCanacelPopUpCancel();
							  browser.sleep(25000).then(function(){console.log("clicked on Cancelled cancel Btn")});
							  issuer_page=create_Issuer.clickOnSaveButton();
							  	  browser.sleep(30000).then(function(){console.log("clicked on Cancel Btn")});

                             issuer_page.clickOnissuerFilterButton();
							  browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
							
							  issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement148.issuerName);
							  issuer_page.clickOnFilterIssuerCodeDrpdwn();
							  browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer code dropdown")});
							  issuer_page.selectParticularIssuer(testData.issuer.IssuerManagement148.issuerCode);    
                              browser.sleep(5000).then(function(){console.log("selected particular issuer from drop down")});
                              issuer_page.clickOnFilterApplyButton();
                              browser.sleep(20000).then(function(){console.log("Clicked on Filter Apply Btn")});
							  issuer_page.rowCountInTable();


			  });	


			    it('Issuer_Management_151,152:Verify Edit button is available on View Issuer Details screen.',function () {
								console.log('Issuer_Management_151,152 started execution');
                                
						     var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

							var details_page= issuer_page.clickOnfirstRowIssuerCode();
							   browser.sleep(20000).then(function(){console.log("Clicked on First row issuer code")});
                                 details_page.detailsIssuerEditButtonIsPresent();

						     details_page.clickOnDetailsEditButton();
							  browser.sleep(20000).then(function(){console.log("Clicked on Edit button")});
							// expect(browser.getCurrentUrl()).toContain(testData.issuer.IssuerManagement152.urlContain);

							  browser.getCurrentUrl().then(function(url) {
										console.log("URL= "+ url);
										expect(url).toContain(testData.issuer.IssuerManagement152.urlContain);	
									});		 
                            
				});	

				it('Issuer_Management_153:Verify default elements of Update Issuer screen.',function () {
								console.log('Issuer_Management_153 started execution');
                                
						     var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

							var details_page= issuer_page.clickOnfirstRowIssuerCode();
							   browser.sleep(20000).then(function(){console.log("Clicked on First row issuer code")});
                                 details_page.detailsIssuerEditButtonIsPresent();

						    var edit_page= details_page.clickOnDetailsEditButton();
							  browser.sleep(20000).then(function(){console.log("Clicked on Edit button")});
							  edit_page.editIssuerCodeIsPresent();
							  edit_page.editIssuerNameIsPresent();
							  edit_page.editIssuerDebitorIsPresent();
							  edit_page.editIssuerDisponentIsPresent();
							  edit_page.editValidFromIsPresent();
							  edit_page.editValidToIsPresent();
							  edit_page.editSubsidiaryDrpdwnIsPresent();
							  edit_page.editParentIssuerDrpdwnIsPresent();
							  edit_page.editLanguageDrpdwnIsPresent();
							  edit_page.editDocumentRetentionIsPresent();
							  edit_page.editDocumentRetentionIsPresent();
							  edit_page.changeLogoOptionIsPresent();

							  edit_page.editIssuerSaveButtonIsPresent();
							  edit_page.editIssuerCancelButtonIsPresent();
								 
                            
				});		


				
				it('Issuer_Management_154,156:Verify the data displayed on Edit screen',function () {
								console.log('Issuer_Management_154 started execution');
                                
						     var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
							 var loginData=require('../../../testData/loginPage.json');

							 	issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								issuer_page.eneterTextInfilter_IssuerName(testData.issuer.sampleData.issuerName);
								browser.sleep(5000).then(function(){console.log("enter text in Issuer name box")});							
								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(20000).then(function(){console.log("Click on filter Apply Btn")});
								var edit_page=issuer_page.clickOnFirstRowsEditButton();
								browser.sleep(20000).then(function(){console.log("Clicked on Edit Btn")});
								edit_page.verifyTextOfEditIssuerCode(testData.issuer.sampleData.issuerCode);
								edit_page.verifyTextOfEditIssuerName(testData.issuer.sampleData.issuerName);
								edit_page.verifyTextOfEditDebitor(testData.issuer.sampleData.debitor);
								edit_page.verifyTextOfEditDisponent(testData.issuer.sampleData.disponent);

							  edit_page.clickLanguageDrpdwnt();
							  browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
                              edit_page.selectParticularLanguage(testData.issuer.IssuerManagement156.language);
							  browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
							  issuer_page=edit_page.clickOnSaveButton();
							  browser.sleep(30000).then(function(){console.log("IClick on Save")});
							  issuer_page.clickOnFilterApplyButton();
							  browser.sleep(20000).then(function(){console.log("Click on filter apply btn")});
							  issuer_page.verifyTextOfFirstRowUpdatedBy(loginData.authentication.login.username);
				});		


				it('Issuer_Management_158,159:Verify that user is able to update Issuer Code ,Issuer Name',function () {
								console.log('Issuer_Management_158,159 started execution');
                                
						     var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
							

							 	issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								issuer_page.clickOnFilterIssuerCodeDrpdwn();
								browser.sleep(10000).then(function(){console.log("click on Issuer code drpdwn")});
								issuer_page.selectParticularIssuer(testData.issuer.IssuerManagement158.issuerCode);
								browser.sleep(5000).then(function(){console.log("Select particular issuer")});
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(20000).then(function(){console.log("Click on filter Apply Btn")});
								var edit_page=issuer_page.clickOnFirstRowsEditButton();
								browser.sleep(20000).then(function(){console.log("Clicked on Edit Btn")});
								edit_page.clearEditIssuerCode();
								browser.sleep(10000).then(function(){console.log("Cleared on issuer code")});
								edit_page.eneterTextInEditIssuerCode(testData.issuer.IssuerManagement158.chnagedIssuerCode);					
                                edit_page.clearEditIssuerName();
								browser.sleep(10000).then(function(){console.log("Cleared on issuerName1")});
								edit_page.eneterTextInEditIssuerName(testData.issuer.IssuerManagement158.changedIssuerName);
								browser.sleep(10000).then(function(){console.log("Enter text in issuerName1")});
							    issuer_page=edit_page.clickOnSaveButton();
								browser.sleep(30000).then(function(){console.log("click on Save Btn")});
								issuer_page.clickOnFilterClearButton();
								browser.sleep(20000).then(function(){console.log("click on Filter Clear Btn")});
						
								issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement158.changedIssuerName);
							

						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(20000).then(function(){console.log("Clicked on Apply button")});
								issuer_page.rowCountInTable();
								var details_Issuer=issuer_page.clickOnfirstRowIssuerCode();
								browser.sleep(20000).then(function(){console.log("Clicked on 1st row issuer code")});
								details_Issuer.verifyTextOfIssuerCode(testData.issuer.IssuerManagement158.chnagedIssuerCode);
								details_Issuer.verifyTextOfIssuerName(testData.issuer.IssuerManagement158.changedIssuerName);

				});		


				it('Issuer_Management_161:Verify that user is able to update Valid From and Valid To date range.',function () {
								console.log('Issuer_Management_161 started execution');
                                
						     var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
							

							 	issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
							    issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement161.issuerName);								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(20000).then(function(){console.log("Click on filter Apply Btn")});
								var edit_page=issuer_page.clickOnFirstRowsEditButton();
								browser.sleep(20000).then(function(){console.log("Clicked on Edit Btn")});
								edit_page.clearValidFromDate();
								edit_page.eneterTextInValidDateFrom(testData.issuer.IssuerManagement161.validFrom);

								edit_page.clearValidToDate();
								edit_page.eneterTextInValidDateTo(testData.issuer.IssuerManagement161.validTo);
							    issuer_page=edit_page.clickOnSaveButton();
								browser.sleep(30000).then(function(){console.log("click on Save Btn")});
								issuer_page.clickOnFilterClearButton();
								browser.sleep(20000).then(function(){console.log("click on Filter Clear Btn")});
						
								issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement161.issuerName);
							

						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(20000).then(function(){console.log("Clicked on Apply button")});
								issuer_page.rowCountInTable();
								var details_Issuer=issuer_page.clickOnfirstRowIssuerCode();
								browser.sleep(20000).then(function(){console.log("Clicked on 1st row issuer code")});
								details_Issuer.verifyTextOfValidFrom(testData.issuer.IssuerManagement161.validFrom);
								details_Issuer.verifyTextOfValidTo(testData.issuer.IssuerManagement161.validTo);

				});	


				it('Issuer_Management_162:Verify that user is able to update debitor and / or Disponent of a Issuer..',function () {
								console.log('Issuer_Management_158 started execution');
                                
						     var testData=require('../../../testData/issuerPageData.json');							
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
							

							 	issuer_page.clickOnissuerFilterButton();
								browser.sleep(15000).then(function(){console.log("Clicked on Filter Button")});
							    issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement162.issuerName);
                                browser.sleep(5000).then(function(){console.log("Enter TExt In Issuer Name")});
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(20000).then(function(){console.log("Click on filter Apply Btn")});
								var edit_page=issuer_page.clickOnFirstRowsEditButton();
								browser.sleep(20000).then(function(){console.log("Clicked on Edit Btn")});
								edit_page.eneterTextInEditIssuerDisponent(testData.issuer.IssuerManagement162.disponent);
								edit_page.eneterTextInEditIssuerDebitor(testData.issuer.IssuerManagement162.debitor);

							    
							    issuer_page=edit_page.clickOnSaveButton();
								browser.sleep(30000).then(function(){console.log("click on Save Btn")});
								issuer_page.clickOnFilterClearButton();
								browser.sleep(20000).then(function(){console.log("click on Filter Clear Btn")});
						
								issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement161.issuerName);
							

						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(20000).then(function(){console.log("Clicked on Apply button")});
								issuer_page.rowCountInTable();
								var details_Issuer=issuer_page.clickOnfirstRowIssuerCode();
								browser.sleep(20000).then(function(){console.log("Clicked on 1st row issuer code")});
								details_Issuer.verifyTextOfDebitor(testData.issuer.IssuerManagement162.debitor);
								details_Issuer.verifyTextOfDisponent(testData.issuer.IssuerManagement162.disponent);

				});			 		 
	 	 

     		  it('Issuer_Management_241:Verify Delete button at upper right corner of Issuer management landing screen. ',function () {
								console.log('Issuer_Management_241 started execution');
                             						
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
							 issuer_page.issuerDeleteButtonIsPresent();
			   });	

			   it('Issuer_Management_242:Verify that user is able to select one or more Issuer records.',function () {
								console.log('Issuer_Management_242 started execution');
                             						
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
							 issuer_page.selectMultipleRecordsWithCheckBox();
			   });	

			   it('Issuer_Management_243:Verify the warning message displayed when Delete button is clicked.',function () {
								console.log('Issuer_Management_242 started execution');
                             						
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
							 issuer_page.selectMultipleRecordsWithCheckBox();
							 issuer_page.clickOnIssuerDeleteButton();
							 browser.sleep(10000).then(function(){console.log("Clicked on Delete Button")});
                             issuer_page.getTextOfDeletePopup();
                              browser.sleep(5000).then(function(){console.log("Clicked on close icon")});
							 issuer_page.clickOnCloseIconOfPopUp();


			   });

			    it('Issuer_Management_244:Verify that user is able to Delete single Issuer record.',function () {
								console.log('Issuer_Management_244 started execution');
                             						
                             var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
							  var testData=require('../../../testData/issuerPageData.json');	 
								issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
							    issuer_page.eneterTextInfilter_IssuerName(testData.issuer.IssuerManagement244.issuerName);								
						 		issuer_page.clickOnFilterApplyButton();
								browser.sleep(20000).then(function(){console.log("Click on filter Apply Btn")});
								issuer_page.selectFirstRecordwithCheckbox();
								issuer_page.clickOnIssuerDeleteButton();
								browser.sleep(10000).then(function(){console.log("Click on Delete Btn")});
								issuer_page.clickOnIssuerDeleteYesButton();
					      		browser.sleep(25000).then(function(){console.log("Click on Delete Yes Btn")});
					 			issuer_page.clickOnFilterApplyButton();
                      			browser.sleep(25000).then(function(){console.log("Click on Filter Apply Btn")});
								issuer_page.firstRowFromTableNotPresent();							


			   });	


			   it('Issuer_Management_DeleteData: Deleta all data created before ',function(){
                       var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
					     var testData=require('../../../testData/issuerPageData.json');
					   	issuer_page.clickOnissuerFilterButton();
								browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								issuer_page.eneterTextInfilter_IssuerName(testData.issuer.deleteData.issuerName);								
							for( i=1; i<6;i++){									
									issuer_page.clickOnFilterApplyButton();
									browser.sleep(20000).then(function(){console.log("Clicked on Filter Apply Button")});
                                    issuer_page.selectAllRecordsWithCheckBox();

									issuer_page.clickOnIssuerDeleteButton();
									browser.sleep(5000).then(function(){console.log("Clicked on issuer Delete Button")});
									issuer_page.clickOnIssuerDeleteYesButton();
									browser.sleep(25000).then(function(){console.log("Clicked on issuer Delete Button")});
								
							}

			   }); 

			   
			   it('Issuer_Management_DeleteData: Deleta subsidiary created before ',function(){
                               var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
								var testData=require('../../../testData/issuerPageData.json');												
								 

								element(by.cssContainingText('.section>a>h3>span', 'Subsidiaries')).click();							
							     browser.sleep(10000).then(function(){console.log("clicked on Subsidiaries option in Master Data")});
								 subsidary_page.clickOnFilterButton();
								 subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
								 browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
								 subsidary_page.selectParticularSubCode(testData.issuer.deleteData.subsidiary);
								 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});								  
								 subsidary_page.clickOnFilterApplyButton();
						         browser.sleep(20000).then(function(){console.log("Clicked on subsidary code dropdown")});

								 subsidary_page.selectFirstRecordwithCheckbox();
								 subsidary_page.clickOnDeleteButton();	
							     browser.sleep(10000).then(function(){console.log("Clicked on Delete Button")});
                                 subsidary_page.clickOnDeleteYesButton();
							     browser.sleep(20000).then(function(){console.log("Clicked on Delete Yes Button")});

			   }); 
						 		 
						 
							
 



        

});  
