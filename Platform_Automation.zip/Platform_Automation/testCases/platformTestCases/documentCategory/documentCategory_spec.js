describe('DocumentCategory page', function() {
	
	                    beforeAll(function() {
								var loginData=require('../../../testData/loginPage.json');
								var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
								browser.ignoreSynchronization = true;
								browser.waitForAngularEnabled(false);
								browser.get(loginData.authentication.login.url);
								browser.sleep(5000).then(function(){console.log("Sleep after url launched")});

								//var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
								console.log('Cloooo--11')
								//***********************************************************************
								/*login_page.login();
                                browser.sleep(5000).then(function(){console.log("Sleep after url launched")});*/

						});
						
	
	
						beforeEach(function(){
								/* browser.get('http://10.51.232.73:3000/platform/master-data/subsidiaries');
								//protractor.browser.ignoreSynchronization = true;
								var loginData=require('../../../testData/loginPage.json');
								var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');*/
								var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
								//***************************************************************************************
								var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
								login_page.login();
								browser.sleep(5000).then(function(){console.log("Sleep after url launched")});


						
									home_page.clickBreadCrum();
									browser.driver.sleep(5000);
									element(by.cssContainingText('.section>a>h3>span', 'Document Category')).click();
									//browser.driver.navigate().refresh();
									browser.sleep(10000).then(function(){console.log("clicked on Products option in Master Data")});
									//ement(by.cssContainingText('.section>a>h3>span','Subsidiaries')).click();							
						
												
						});
						
						
					   afterEach(function(){
						 /*  var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
						   home_page.clickBreadCrum();
						   browser.driver.sleep(5000);*/
						   element(by.css('.header-icon-panel .icon-logout')).click();
						   browser.sleep(10000).then(function(){console.log("Clicked on logout Button")});
					   });

					   it('Document_Category_033,40:Create Sample data1 For DocumentCategory',function () {
						  console.log('Document_Category_033,40 Document Category started execution');
						 	  var testData=require('../../../testData/documentCategoryData.json');	
						       var docCategory_page=require('../../../pageObject/platformPOM/documentCatgoryPOM/documentCategoryPageObject.js');
							 var status = false;
				        
							//Sample Document_Category created for this
							 for (var i in testData.documentCategory.SampleTestData) {   
									var create_docCategory=docCategory_page.clickOnCreateButton();
									browser.sleep(5000).then(function(){console.log("Clicked on Create button")});
									create_docCategory.enterTextInDocument_Category(testData.documentCategory.SampleTestData[i].docCategory);
									create_docCategory.enterTextInDescription(testData.documentCategory.SampleTestData[i].description);
									create_docCategory.enterTextInValidDateFrom(testData.documentCategory.SampleTestData[i].validFrom);
									create_docCategory.enterTextInValidDateTo(testData.documentCategory.SampleTestData[i].validTo);
									create_docCategory.clickOnUsersDrpDwn();
									browser.sleep(5000).then(function(){console.log("Clicked on users drpdwn")});
									create_docCategory.selectParticularUsers(testData.documentCategory.SampleTestData[i].users);
										browser.sleep(5000).then(function(){console.log("Selected Users ")});
									create_docCategory.clickOnGroupsDrpDwn();
									browser.sleep(5000).then(function(){console.log("Clicked on groups drpdwn")});
									create_docCategory.selectParticularGroups(testData.documentCategory.SampleTestData[i].groups);
                                    	browser.sleep(5000).then(function(){console.log("Selected groups ")});
									create_docCategory.clickOnSaveButton();
									browser.sleep(20000).then(function(){console.log("Clicked on Save Btn")});

							 }
					 });


					 

					
					
			      it('Document_Category_001:Verify that superadmin user is able to navigate landing page of Document Category screen.', function() {
						 console.log('Document_Category_001 started execution');
						  var testData=require('../../../testData/documentCategoryData.json');	
						// expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);	
						 //console.log('Url='+browser.getCurrentUrl());	

								browser.getCurrentUrl().then(function(url) {
										console.log("URL= "+ url);
										expect(url).toContain(testData.documentCategory.Document_Category_001.urlContain);	
									});

					});


                   it('Document_Category_005:Verify the fields available on Document Category screen', function() {
						 console.log('Document_Category_005 started execution');
						  var testData=require('../../../testData/documentCategoryData.json');	
						  var docCategory_page=require('../../../pageObject/platformPOM/documentCatgoryPOM/documentCategoryPageObject.js');
						// expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);	
						 //console.log('Url='+browser.getCurrentUrl());	

								docCategory_page.filterButtonIsPresent();
								docCategory_page.createButtonIsPresent();
								docCategory_page.exportOptionIsPresent();
								docCategory_page.docCategoryTextIsPresent();
								docCategory_page.deleteButtonIsPresent();

					});

				it('Document_Category_006:Verify the columns of Document Category Grid', function() {
						 console.log('Document_Category_006 started execution');
						  var testData=require('../../../testData/documentCategoryData.json');	
						  var docCategory_page=require('../../../pageObject/platformPOM/documentCatgoryPOM/documentCategoryPageObject.js');
						// expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);	
						 //console.log('Url='+browser.getCurrentUrl());	

								docCategory_page.documnet_CategoryIsPresent();
								docCategory_page.descriptionIsPresent();
								docCategory_page.valid_fromIsPresent();
								docCategory_page.valid_ToIsPresent();
								docCategory_page.updatedByIsPresent();
								docCategory_page.updatedOnIsPresent();

					});


				 it('Document_Category_009:Verify the Document Categories listed in the grid.', function() {
						 console.log('Document_Category_009 started execution');
						  var testData=require('../../../testData/documentCategoryData.json');	
						  var docCategory_page=require('../../../pageObject/platformPOM/documentCatgoryPOM/documentCategoryPageObject.js');
						// expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);	
						 //console.log('Url='+browser.getCurrentUrl());	

						        docCategory_page.clickOnfilterButton();
								browser.sleep(5000).then(function(){console.log("click on Filter Button")});

								docCategory_page.filterDocCategory_drpdwnIsPresent();
								docCategory_page.filter_DescrptionIsPresent();
								docCategory_page.filter_Clear_ButtonIsPresent();
								docCategory_page.filter_Apply_ButtonIsPresent();						

					});

                    it('Document_Category_010:Verify the Categories Name in Document Category name dropdown.', function() {
						 console.log('Document_Category_010 started execution');
						  var testData=require('../../../testData/documentCategoryData.json');	
						  var docCategory_page=require('../../../pageObject/platformPOM/documentCatgoryPOM/documentCategoryPageObject.js');
						// expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);	
						 //console.log('Url='+browser.getCurrentUrl());	

						        docCategory_page.clickOnfilterButton();
								browser.sleep(5000).then(function(){console.log("click on Filter Button")});

								docCategory_page.clickOnfilterDocCategoryDrpdwn();
								browser.sleep(5000).then(function(){console.log("click on Filter DocCategoryDrpdwn")});
								docCategory_page.rowCountInTable();							

					});

					  it('Document_Category_011:Verify the Categories Name in Document Category name dropdown.', function() {
						 console.log('Document_Category_011 started execution');
						  var testData=require('../../../testData/documentCategoryData.json');	
						  var docCategory_page=require('../../../pageObject/platformPOM/documentCatgoryPOM/documentCategoryPageObject.js');
						// expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);	
						 //console.log('Url='+browser.getCurrentUrl());	

						        docCategory_page.clickOnfilterButton();
								browser.sleep(5000).then(function(){console.log("click on Filter Button")});

								docCategory_page.clickOnfilterDocCategoryDrpdwn();
								browser.sleep(5000).then(function(){console.log("click on Filter DocCategoryDrpdwn")});
								docCategory_page.selectParticularDocumentCategory(testData.documentCategory.Document_Category_011.docCategory);
								browser.sleep(5000).then(function(){console.log("particular docCategory is Selected")});
								docCategory_page.clickOnFilterApplyButton();
								browser.sleep(5000).then(function(){console.log("Clicked on filter apply Button")});
								docCategory_page.rowCountInTable();							

					});

					  it('Document_Category_012:Verify that user is able to search by Description.', function() {
						 console.log('Document_Category_012 started execution');
						  var testData=require('../../../testData/documentCategoryData.json');	
						  var docCategory_page=require('../../../pageObject/platformPOM/documentCatgoryPOM/documentCategoryPageObject.js');
						// expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);	
						 //console.log('Url='+browser.getCurrentUrl());	

						        docCategory_page.clickOnfilterButton();
								browser.sleep(5000).then(function(){console.log("click on Filter Button")});

								docCategory_page.eneterTextInFilter_Descrption(testData.documentCategory.Document_Category_012.description);
								browser.sleep(5000).then(function(){console.log("click on Filter DocCategoryDrpdwn")});
							    docCategory_page.clickOnFilterApplyButton();
								browser.sleep(5000).then(function(){console.log("Clicked on filter apply Button")});
								docCategory_page.rowCountInTable();							

					});

					 it('Document_Category_013:Verify that user is able to search by Document Category Name and Description.', function() {
						 console.log('Document_Category_013 started execution');
						  var testData=require('../../../testData/documentCategoryData.json');	
						  var docCategory_page=require('../../../pageObject/platformPOM/documentCatgoryPOM/documentCategoryPageObject.js');
						// expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);	
						 //console.log('Url='+browser.getCurrentUrl());	

						        docCategory_page.clickOnfilterButton();
								browser.sleep(5000).then(function(){console.log("click on Filter Button")});
                                docCategory_page.clickOnfilterDocCategoryDrpdwn();
								browser.sleep(5000).then(function(){console.log("click on Filter DocCategoryDrpdwn")});
								docCategory_page.selectParticularDocumentCategory(testData.documentCategory.Document_Category_013.docCategory);
								browser.sleep(5000).then(function(){console.log("click on Filter DocCategoryDrpdwn")});
								docCategory_page.eneterTextInFilter_Descrption(testData.documentCategory.Document_Category_013.description);
								browser.sleep(5000).then(function(){console.log("click on Filter DocCategoryDrpdwn")});
							    docCategory_page.clickOnFilterApplyButton();
								browser.sleep(5000).then(function(){console.log("Clicked on filter apply Button")});
								docCategory_page.rowCountInTable();							

					});

					 it('Document_Category_014:Verify that no record is displayed if search criteria doesnt meet.', function() {
						 console.log('Document_Category_014 started execution');
						  var testData=require('../../../testData/documentCategoryData.json');	
						  var docCategory_page=require('../../../pageObject/platformPOM/documentCatgoryPOM/documentCategoryPageObject.js');
						// expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);	
						 //console.log('Url='+browser.getCurrentUrl());	

						        docCategory_page.clickOnfilterButton();
								browser.sleep(5000).then(function(){console.log("click on Filter Button")});

								docCategory_page.eneterTextInFilter_Descrption(testData.documentCategory.Document_Category_014.description);
								browser.sleep(5000).then(function(){console.log("click on Filter DocCategoryDrpdwn")});
							    docCategory_page.clickOnFilterApplyButton();
								browser.sleep(5000).then(function(){console.log("Clicked on filter apply Button")});
								docCategory_page.firstRowFromTableNotPresent();							

					});



				 it('Document_Category_015:Verify the attribute details listed for search result in the grid.', function() {
						 console.log('Document_Category_015 started execution');
						  var testData=require('../../../testData/documentCategoryData.json');	
						  var docCategory_page=require('../../../pageObject/platformPOM/documentCatgoryPOM/documentCategoryPageObject.js');
						

						    docCategory_page.documnet_CategoryIsPresent();
							docCategory_page.descriptionIsPresent();
							docCategory_page.valid_fromIsPresent();
							docCategory_page.valid_ToIsPresent();	
							docCategory_page.updatedByIsPresent();
							docCategory_page.updatedOnIsPresent();					

					});

       
	             it('Document_Category_016:Verify the attribute details listed on View Document Category screen.', function() {
						 console.log('Document_Category_016 started execution');
						  var testData=require('../../../testData/documentCategoryData.json');	
						  var docCategory_page=require('../../../pageObject/platformPOM/documentCatgoryPOM/documentCategoryPageObject.js');
						
						        docCategory_page.clickOnfilterButton();
								browser.sleep(5000).then(function(){console.log("click on Filter Button")});
                                docCategory_page.clickOnfilterDocCategoryDrpdwn();
								browser.sleep(5000).then(function(){console.log("click on Filter DocCategoryDrpdwn")});
								docCategory_page.selectParticularDocumentCategory(testData.documentCategory.Document_Category_016.docCategory);
								browser.sleep(5000).then(function(){console.log("click on Filter DocCategoryDrpdwn")});
								docCategory_page.eneterTextInFilter_Descrption(testData.documentCategory.Document_Category_016.description);
								browser.sleep(5000).then(function(){console.log("click on Filter DocCategoryDrpdwn")});
							    docCategory_page.clickOnFilterApplyButton();
								browser.sleep(5000).then(function(){console.log("Clicked on filter apply Button")});
								var details_page=docCategory_page.clickOnFirstRowDocCategory();
								browser.sleep(5000).then(function(){console.log("Clicked on Doc Category")});	
								details_page.verifyTextOfDocCategory(testData.documentCategory.Document_Category_016.docCategory);	
								details_page.verifyTextOfDescription(testData.documentCategory.Document_Category_016.description);
								details_page.verifyTextOfValidFrom(testData.documentCategory.Document_Category_016.validFrom);
								details_page.verifyTextOfValidTo(testData.documentCategory.Document_Category_016.validTo);		
                                details_page.verifyTextOfUsers(testData.documentCategory.Document_Category_016.users);
								details_page.verifyTextOfGroups(testData.documentCategory.Document_Category_016.groups);


					});


				it('Document_Category_039:Verify that Document Category is created with Multiple User.', function() {
						 console.log('Document_Category_039 started execution');
						  var testData=require('../../../testData/documentCategoryData.json');	
						  var docCategory_page=require('../../../pageObject/platformPOM/documentCatgoryPOM/documentCategoryPageObject.js');
						

						            var create_docCategory=docCategory_page.clickOnCreateButton();
									browser.sleep(5000).then(function(){console.log("Clicked on Create button")});
									create_docCategory.enterTextInDocument_Category(testData.documentCategory.Document_Category_039.docCategory);
									create_docCategory.enterTextInDescription(testData.documentCategory.Document_Category_039.description);
									create_docCategory.enterTextInValidDateFrom(testData.documentCategory.Document_Category_039.validFrom);
									create_docCategory.enterTextInValidDateTo(testData.documentCategory.Document_Category_039.validTo);
									create_docCategory.clickOnUsersDrpDwn();
									browser.sleep(5000).then(function(){console.log("Clicked on users drpdwn")});
									create_docCategory.selectParticularUsers(testData.documentCategory.Document_Category_039.users1);
										browser.sleep(5000).then(function(){console.log("Selected Users ")});

								    create_docCategory.clickOnUsersDrpDwn();
									browser.sleep(5000).then(function(){console.log("Clicked on users drpdwn")});
									create_docCategory.selectParticularUsers(testData.documentCategory.Document_Category_039.users2);
										browser.sleep(5000).then(function(){console.log("Selected Users ")});


									create_docCategory.clickOnGroupsDrpDwn();
									browser.sleep(5000).then(function(){console.log("Clicked on groups drpdwn")});
									create_docCategory.selectParticularGroups(testData.documentCategory.Document_Category_039.groups);
                                    	browser.sleep(5000).then(function(){console.log("Selected groups ")});
								docCategory_page=create_docCategory.clickOnSaveButton();
									browser.sleep(15000).then(function(){console.log("Clicked on Save Btn")});
                               //     element(by.cssContainingText('.section>a>h3>span', 'Document Category')).click();
                                //   browser.sleep(10000).then(function(){console.log("Navigate to document Category")});
                                    

									docCategory_page.clickOnfilterButton();
									browser.sleep(5000).then(function(){console.log("Click on filter button")});
									docCategory_page.clickOnfilterDocCategoryDrpdwn();
									browser.sleep(5000).then(function(){console.log("click on Filter DocCategoryDrpdwn")});
									docCategory_page.selectParticularDocumentCategory(testData.documentCategory.Document_Category_039.docCategory);
									browser.sleep(5000).then(function(){console.log("click on Filter DocCategoryDrpdwn")});
									docCategory_page.clickOnFilterApplyButton();
									//element(by.css('#document_filter_apply_button')).click();
								 	browser.sleep(5000).then(function(){console.log("click on Filter Apply Button")});
									var details_page=docCategory_page.clickOnFirstRowDocCategory();
									browser.sleep(5000).then(function(){console.log("Clicked on Doc Category")});	
                                    details_page.verifyTextOfUsers(testData.documentCategory.Document_Category_039.users2);
									details_page.verifyTextOfUsers2(testData.documentCategory.Document_Category_039.users1);
                             


					});


					it('Document_Category_041,43,44,45:Verify that Document Category is created with Multiple groups.', function() {
						 console.log('Document_Category_041,43,44,45 started execution');
						  var testData=require('../../../testData/documentCategoryData.json');	
						  var docCategory_page=require('../../../pageObject/platformPOM/documentCatgoryPOM/documentCategoryPageObject.js');
						

						            var create_docCategory=docCategory_page.clickOnCreateButton();
									browser.sleep(5000).then(function(){console.log("Clicked on Create button")});
									create_docCategory.enterTextInDocument_Category(testData.documentCategory.Document_Category_041.docCategory);
									create_docCategory.enterTextInDescription(testData.documentCategory.Document_Category_041.description);
									create_docCategory.enterTextInValidDateFrom(testData.documentCategory.Document_Category_041.validFrom);
									create_docCategory.enterTextInValidDateTo(testData.documentCategory.Document_Category_041.validTo);
								


									create_docCategory.clickOnGroupsDrpDwn();
									browser.sleep(5000).then(function(){console.log("Clicked on groups drpdwn")});
									create_docCategory.selectParticularGroups(testData.documentCategory.Document_Category_041.groups1);
                                   	browser.sleep(5000).then(function(){console.log("Selected groups ")});
							       	

									create_docCategory.clickOnGroupsDrpDwn();
									browser.sleep(5000).then(function(){console.log("Clicked on groups drpdwn")});
									create_docCategory.selectParticularGroups(testData.documentCategory.Document_Category_041.groups2);
                                   	browser.sleep(5000).then(function(){console.log("Selected groups ")});
							       	docCategory_page=create_docCategory.clickOnSaveButton();   
							        browser.sleep(15000).then(function(){console.log("Clicked on save button ")});

									docCategory_page.clickOnfilterButton();
									browser.sleep(5000).then(function(){console.log("Click on filter button")});
									docCategory_page.clickOnfilterDocCategoryDrpdwn();
									browser.sleep(5000).then(function(){console.log("click on Filter DocCategoryDrpdwn")});
									docCategory_page.selectParticularDocumentCategory(testData.documentCategory.Document_Category_041.docCategory);
									browser.sleep(5000).then(function(){console.log("click on Filter DocCategoryDrpdwn")});
									docCategory_page.clickOnFilterApplyButton();
									
								 	browser.sleep(5000).then(function(){console.log("click on Filter Apply Button")});
									docCategory_page.getTextOfFirstRowUpdatedBy();
									docCategory_page.getTextOfFirstRowUpdatedOn();
									browser.sleep(5000).then(function(){console.log("Verifying elements on Grid")});
									var details_page=docCategory_page.clickOnFirstRowDocCategory();
									browser.sleep(5000).then(function(){console.log("Clicked on Doc Category")});	
                                    details_page.verifyTextOfGroups(testData.documentCategory.Document_Category_041.groups1);
									details_page.verifyTextOfGroups1(testData.documentCategory.Document_Category_041.groups2);
                                    details_page.verifyTextOfCreatedBy(testData.documentCategory.Document_Category_041.username);
                                    details_page.verifyTextOfCreatedOn();
									details_page.verifyTextOfUpdatedBy();
									details_page.verifyTextOfUpdatedOn();



					});


					it('Document_Category_046:Verify default elements of Create Document Category screen.', function() {
						 console.log('Document_Category_046 started execution');
						  var testData=require('../../../testData/documentCategoryData.json');	
						  var docCategory_page=require('../../../pageObject/platformPOM/documentCatgoryPOM/documentCategoryPageObject.js');
						

						            var create_docCategory=docCategory_page.clickOnCreateButton();
									browser.sleep(5000).then(function(){console.log("Clicked on Create button")});
									create_docCategory.document_CategoryIsPresent();
									create_docCategory.descriptionIsPresent();
									create_docCategory.createDocumentCategoryValidFromIsPresent();
									create_docCategory.createDocumentCategoryValidToIsPresent();
									create_docCategory.usersDrpDwnIsPresent();
									create_docCategory.groupsDrpDwnIsPresent();
									create_docCategory.docCategoryCancelButtonIsPresent();
									create_docCategory.docCategorySaveButtonIsPresent();
                                    browser.sleep(5000).then(function(){console.log("Wait")});
                                    create_docCategory.clickOnUsersDrpDwn();
									browser.sleep(5000).then(function(){console.log("Clicked on users drpdwn")});
									create_docCategory.selectParticularUsers(testData.documentCategory.Document_Category_046.user);
									browser.sleep(5000).then(function(){console.log("Selected Users ")});
                                    create_docCategory.permissionUploadIsPresent();
									create_docCategory.permissionDeleteIsPresent();

					});		

					it('Document_Category_049:Verify that Upload, View and Delete Permission can be set for a user', function() {
						 console.log('Document_Category_049 started execution');
						  var testData=require('../../../testData/documentCategoryData.json');	
						  var docCategory_page=require('../../../pageObject/platformPOM/documentCatgoryPOM/documentCategoryPageObject.js');
						

						            var create_docCategory=docCategory_page.clickOnCreateButton();
									browser.sleep(5000).then(function(){console.log("Clicked on Create button")});
									create_docCategory.enterTextInDocument_Category(testData.documentCategory.Document_Category_049.docCategory);
									create_docCategory.enterTextInDescription(testData.documentCategory.Document_Category_049.description);
									create_docCategory.enterTextInValidDateFrom(testData.documentCategory.Document_Category_049.validFrom);
									create_docCategory.enterTextInValidDateTo(testData.documentCategory.Document_Category_049.validTo);
								


									create_docCategory.clickOnUsersDrpDwn();
									browser.sleep(10000).then(function(){console.log("Clicked on groups drpdwn")});
									create_docCategory.selectParticularUsers(testData.documentCategory.Document_Category_049.username);
                                   	browser.sleep(5000).then(function(){console.log("Selected groups ")});
							       	create_docCategory.selectUserUploadPermission();
									browser.sleep(5000).then(function(){console.log("Selected Upload permission ")});   
                                    create_docCategory.selectUserDeletePermission();
									browser.sleep(5000).then(function(){console.log("Selected Delete Permission ")});

									create_docCategory.clickOnGroupsDrpDwn();
									browser.sleep(10000).then(function(){console.log("Clicked on groups drpdwn")});
									create_docCategory.selectParticularGroups(testData.documentCategory.Document_Category_049.groups);
                                   	browser.sleep(5000).then(function(){console.log("Selected groups ")});
							       	docCategory_page=create_docCategory.clickOnSaveButton();   
							        browser.sleep(20000).then(function(){console.log("Clicked on save button ")});

									docCategory_page.clickOnfilterButton();
									browser.sleep(5000).then(function(){console.log("Click on filter button")});
									docCategory_page.clickOnfilterDocCategoryDrpdwn();
									browser.sleep(5000).then(function(){console.log("click on Filter DocCategoryDrpdwn")});
									docCategory_page.selectParticularDocumentCategory(testData.documentCategory.Document_Category_049.docCategory);
									browser.sleep(5000).then(function(){console.log("click on Filter DocCategoryDrpdwn")});
									docCategory_page.clickOnFilterApplyButton();
									
								 	browser.sleep(5000).then(function(){console.log("click on Filter Apply Button")});
                                    docCategory_page.rowCountInTable();					



					});
		


					it('Document_Category_050:Verify that Upload, View and Delete Permission can be set for a user', function() {
                        console.log('Document_Category_050 started execution');
                        var testData = require('../../../testData/documentCategoryData.json');
                        var docCategory_page = require('../../../pageObject/platformPOM/documentCatgoryPOM/documentCategoryPageObject.js');

                        docCategory_page.clickOnfilterButton();
                        browser.sleep(10000).then(function(){console.log("Click on filter button")});
                        docCategory_page.eneterTextInFilter_Descrption(testData.documentCategory.Document_Category_050.description)
                        browser.sleep(5000).then(function(){console.log("Enter text in Description")});
                        docCategory_page.clickOnFilterApplyButton();

                        browser.sleep(10000).then(function(){console.log("click on Filter Apply Button")});

                        docCategory_page.clickOnCheckBoxToSelectAllDocumentsOnPage();

                        docCategory_page.clickOnDeleteButton();
                        browser.sleep(5000).then(function(){console.log("click on Delete Button")});
                        docCategory_page.clickOnDeleteYesButton();
                        browser.sleep(15000).then(function(){console.log("click on Delete Yes Button")});

                        docCategory_page.clickOnFilterClearButton();
                        browser.sleep(10000).then(function(){console.log("click on Filter Clear Button")});
                        docCategory_page.eneterTextInFilter_Descrption(testData.documentCategory.Document_Category_050.description)
                        browser.sleep(5000).then(function(){console.log("Enter text in Description")});

                        docCategory_page.clickOnFilterApplyButton();
                        browser.sleep(10000).then(function(){console.log("click on Filter Apply Button")});
                        docCategory_page.firstRowFromTableNotPresent();



                    });

					 
					
   
	
});  
