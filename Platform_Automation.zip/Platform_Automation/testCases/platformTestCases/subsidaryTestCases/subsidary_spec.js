describe('subsidary page', function() {
	
	                    beforeAll(function() {
								var loginData=require('../../../testData/loginPage.json');
								var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
								browser.ignoreSynchronization = true;
								browser.waitForAngularEnabled(false);
								browser.get(loginData.authentication.login.url);
								browser.sleep(5000).then(function(){console.log("Sleep after url launched")});

								//var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
								console.log('Cloooo--11')
								//***********************************************************************
								/*login_page.login();
                                browser.sleep(5000).then(function(){console.log("Sleep after url launched")});*/

						});
						
	
	
						beforeEach(function(){
						/* browser.get('http://10.51.232.73:3000/platform/master-data/subsidiaries');
						  //protractor.browser.ignoreSynchronization = true;
						  var loginData=require('../../../testData/loginPage.json');
						  var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');*/
						  var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
						  //***************************************************************************************
						  var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
						  login_page.login();
                                browser.sleep(5000).then(function(){console.log("Sleep after url launched")});


						 /* browser.waitForAngularEnabled(false);
					      // var b1=browser.forkNewDriverInstance();
						  
						  browser.get(loginData.authentication.login.url); 
							browser.driver.sleep(5000);
							login_page.enterUserName(loginData.authentication.login.username);
							login_page.enterPassword(loginData.authentication.login.password);
							login_page.clickLoginButton();
							 browser.driver.sleep(5000);*/
							//element(by.css('.sli-large.icon-menu')).click();
							home_page.clickBreadCrum();
                            browser.sleep(5000).then(function(){console.log("Clicked on BreadCrum")});
							home_page.clickSubDirectlyOrClickMasterDataFirst();

                            browser.sleep(20000).then(function(){console.log("Clicked on Subsidiary")});
							//browser.driver.navigate().refresh();
							// browser.sleep(5000).then(function(){console.log("clicked on Subsidiaries option in Master Data")});
							//ement(by.cssContainingText('.section>a>h3>span','Subsidiaries')).click();							
						
												
						});
						
						
					   afterEach(function(){
						 /*  var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
						   home_page.clickBreadCrum();
						   browser.driver.sleep(5000);*/
						   element(by.css('.header-icon-panel .icon-logout')).click();
						   browser.sleep(10000).then(function(){console.log("Clicked on logout Button")});
					   });
					 
					  

					   it('Subsidiary_Management_004:Create Sample data:Create Subsidiary',function () {
						  console.log('Subsidiary module started execution');
						  var testData=require('../../../testData/subsidaryData.json');	
						 // var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
                          	 var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
							  var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
							 var status = false;
				        
						
							 var subsidary_CreatePage=subsidary_page.clickOnCreateButton();
							 browser.sleep(5000).then(function(){console.log("Create Button Clicked")});							
							 
							 subsidary_CreatePage.eneterTextInCreateSubsidaryCode(testData.subsidary.SampleSubsidiary.SubsidiaryCode);
							 subsidary_CreatePage.eneterTextInCreateSubsidaryDescription(testData.subsidary.SampleSubsidiary.Description);
							 subsidary_CreatePage.eneterTextInValidDateFrom(testData.subsidary.SampleSubsidiary.validFrom);
							 subsidary_CreatePage.eneterTextInValidDateTo(testData.subsidary.SampleSubsidiary.validTo);
							 subsidary_page=subsidary_CreatePage.clickOnSaveButton();	
							 browser.sleep(20000).then(function(){console.log("clicked on Save Btn")});
                             console.log('Sample subsidiary created successfully');

					 });
					
					 it('Subsidiary_Management_005:Verify default fields / buttons available on Subsidiaries  screen.', function() {
						var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
						console.log('Navigate to subsidary Page');
						console.log('Subsidiary_Management_005 started execution');
						var status = false;
						subsidary_page.subsidaryTextIsPresent();
						subsidary_page.filterButtonIsPresent();
						subsidary_page.deleteButtonIsPresent();
						 subsidary_page.createButtonIsPresent();						
					  });
					  
					  
					  it('Subsidiary_Management_006:Verify the elements of Subsidiary grid.', function(){
						  console.log('Subsidiary_Management_006 started execution');
						  var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
						  var status = false;

						  subsidary_page.checkBoxToSelectAllIsPresent();
						  subsidary_page.subsidaryCodeIsPresent();
						  subsidary_page.subsidary_DescriptionIsPresent();
						  subsidary_page.valid_fromIsPresent();
						  subsidary_page.valid_ToIsPresent();
						  subsidary_page.updatedByIsPresent();
						  subsidary_page.updatedOnIsPresent();
						 
					  });
				  
					 
					  it('Subsidiary_Management_010:Verify default elements of Filter Pane', function(){
						  console.log('Subsidiary_Management_010 started execution');
						  var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
						  var status = false;
							 subsidary_page.clickOnFilterButton();
							 console.log('Clicked On Filter Button');
						  subsidary_page.filter_SubsidaryCode_drpdwnIsPresent();
					      subsidary_page.filter_DescriptionIsPresent();
						  subsidary_page.filter_Clear_ButtonIsPresent();
						  subsidary_page.filter_Apply_ButtonIsPresent();
						  subsidary_page.filter_CloseIconIsPresent();				    
						 
						    
					  });
					  
					  
				it('Subsidiary_Management_012:Verify search functionality by Subsidiary Code', function(){
						  console.log('Subsidiary_Management_012 started execution');
						  var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');						  
						  var status = false;
							 subsidary_page.clickOnFilterButton();
							 console.log('Clicked On Filter Button');
							 subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
							 subsidary_page.firstElementFromDropDownIsPresent();
							 console.log('Control comes in Seleect from Drop Down');
							 subsidary_page.selectFirstElementFromDropDown();
							 
							 subsidary_page.clickOnFilterApplyButton();
							 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});
							subsidary_page.firstRowFromTableIsPresent();			
						    console.log('Filtered Succcessfully');
						 
						  
					  });

                     it('Subsidiary_Management_015:Verify search functionality by selecting a code from Subsidiary Code dropdown.', function(){
						  console.log('Subsidiary_Management_015 started execution');
						  var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
						  var testData=require('../../../testData/subsidaryData.json');						  
						  var status = false;
							 subsidary_page.clickOnFilterButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Filter button clicked")});
							 subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
							 subsidary_page.selectParticularSubCode(testData.subsidary.SubsidiaryManagement015.subsidiaryCode);
							  browser.sleep(5000).then(function(){console.log("Sleep after select Particular SubCode")});
							 subsidary_page.clickOnFilterApplyButton();
							 browser.sleep(5000).then(function(){console.log("Clicked on Filter Apply Button")});
							 subsidary_page.getTextOfFirstRowSubsidaryCode(testData.subsidary.SubsidiaryManagement015.subsidiaryCode);
							subsidary_page.firstRowFromTableIsPresent();
							
					  });


                       it('Subsidiary_Management_017:Verify search functionality by selecting a code from Subsidiary Code dropdown.', function(){
						  console.log('Subsidiary_Management_017 started execution');
						  var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
						  var testData=require('../../../testData/subsidaryData.json');						  
						  var status = false;
								subsidary_page.clickOnFilterButton();
								browser.sleep(5000).then(function(){console.log("Sleep after Filter button clicked")});
								subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
								browser.sleep(5000).then(function(){console.log("Sleep after clicked on Subsidiary code dropdwn")});
								subsidary_page.enterTextInFilterSubsidaryCodeDrpDown(testData.subsidary.SubsidiaryManagement017.partialsubsidiaryCode);
								browser.sleep(5000).then(function(){console.log("Sleep after entering partial subsidary code")});
							    subsidary_page.isParticularSubCodePresentInDropDown(testData.subsidary.SubsidiaryManagement017.subsidiaryCode);
							    browser.sleep(5000).then(function(){console.log("Sleep after selecting particular subsidry code from drop down")});

							
								
					  });

				  it('Subsidiary_Management_018:Verify search functionality by using invalid subsidary code that doesnt belong Subsidiary Code dropdown.', function(){
						  console.log('Subsidiary_Management_018 started execution');
						  var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
						  var testData=require('../../../testData/subsidaryData.json');						  
						  var status = false;
								subsidary_page.clickOnFilterButton();
								browser.sleep(5000).then(function(){console.log("Sleep after Filter button clicked")});
								subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
								subsidary_page.enterTextInFilterSubsidaryCodeDrpDown(testData.subsidary.SubsidiaryManagement018.invalidSubsidiaryCode);
								browser.sleep(5000).then(function(){console.log("Sleep after entering invalid subsidary code")});
                                subsidary_page.isParticularSubCodeNotPresntDropDown(testData.subsidary.SubsidiaryManagement018.invalidSubsidiaryCode);                 
							
								
					  });

					  
					  it('Subsidiary_Management_026:Verify Search Functionality using Description',function(){
						   console.log('Subsidiary_Management_026 started execution');
						  var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
						  var testData=require('../../../testData/subsidaryData.json');
						  var status = false;
						  subsidary_page.clickOnFilterButton();
						  console.log('Clicked On Filter Button');
						  subsidary_page.eneterTextInDescriptionBox(testData.subsidary.SubsidiaryManagement026.validDescription);
						  console.log('text entered in Description Succcessfully');
						  subsidary_page.clickOnFilterApplyButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Apply Button")});
						  subsidary_page.firstRowFromTableIsPresent();
						   

						 
							 
					 });

					it('Subsidiary_Management_027:Verify Search Functionality using invalid Description',function(){
						  console.log('Subsidiary_Management_027 started execution');
						  var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
						  var testData=require('../../../testData/subsidaryData.json');
						  var status = false;
						  subsidary_page.clickOnFilterButton();
						  browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});
						   console.log('Filtered Succcessfully');
						  subsidary_page.eneterTextInDescriptionBox(testData.subsidary.SubsidiaryManagement025.inValidDescription);
						   console.log('text entered in Description Succcessfully');
						  subsidary_page.clickOnFilterApplyButton();
						   browser.sleep(5000).then(function(){console.log("Clicked on Apply Button")});
						   subsidary_page.firstRowFromTableNotPresent();						 
						   console.log('Filtered Succcessfully');					  
						   
							 
					 });


					it('Subsidiary_Management_30:Verify that user is able to search subsidiary using combination of Code and Description filters.', function(){
						   console.log('Subsidiary_Management_030 started execution');
						  var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
						  var testData=require('../../../testData/subsidaryData.json');						  
						  var status = false;
							 subsidary_page.clickOnFilterButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Filter button clicked")});
							 subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
							 subsidary_page.selectParticularSubCode(testData.subsidary.SubsidiaryManagement030.subsidiaryCode);
							 browser.sleep(5000).then(function(){console.log("Sleep after selectParticularSubCode ")});
							 subsidary_page.eneterTextInDescriptionBox(testData.subsidary.SubsidiaryManagement030.validDescription);
							 subsidary_page.clickOnFilterApplyButton();
							 browser.sleep(5000).then(function(){console.log("Clicked on Filter Apply Button")});
							 subsidary_page.firstRowFromTableIsPresent(); 
							 
							
                            subsidary_page.getTextOfFirstRowSubsidaryCode(testData.subsidary.SubsidiaryManagement030.subsidiaryCode);
							subsidary_page.getTextOfFirstRowDescription(testData.subsidary.SubsidiaryManagement030.validDescription);
							browser.sleep(5000).then(function(){console.log("Sleep For verification")});
							
						    
					  });

				   it('Subsidiary_Management_31:Verify that AND condition is used to search Subsidiary', function(){
							 console.log('Subsidiary_Management_031 started execution');
							 var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
							 var testData=require('../../../testData/subsidaryData.json');						  
							 var status = false;
							 subsidary_page.clickOnFilterButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Filter button clicked")});
							 subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
							  browser.sleep(5000).then(function(){console.log("Sleep after click on SubCode DropDown")});
							 subsidary_page.selectParticularSubCode(testData.subsidary.SubsidiaryManagement031.subsidiaryCode);
							 browser.sleep(5000).then(function(){console.log("Sleep after selectParticularSubCode")});
							 subsidary_page.eneterTextInDescriptionBox(testData.subsidary.SubsidiaryManagement031.validDescriptionOfOtherSubsidary);
							 subsidary_page.clickOnFilterApplyButton();
							 browser.sleep(5000).then(function(){console.log("Clicked on Filter Apply Button")});
							 subsidary_page.firstRowFromTableNotPresent();						
							
							browser.sleep(5000).then(function(){console.log("Sleep after verification")});
							
					  });

                  
				      it('Subsidiary_Management_32:Verify that upon clear, all filters are set to default.', function(){
						     console.log('Subsidiary_Management_032 started execution');
						     var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
						     var testData=require('../../../testData/subsidaryData.json');						  
						     var status = false;
							 subsidary_page.clickOnFilterButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Filter button clicked")});
							 subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();							
							 subsidary_page.selectParticularSubCode(testData.subsidary.SubsidiaryManagement032.subsidiaryCode);
							 browser.sleep(5000).then(function(){console.log("Sleep after selectParticularSubCode")});
							 subsidary_page.eneterTextInDescriptionBox(testData.subsidary.SubsidiaryManagement032.validDescription);
							 subsidary_page.clickOnFilterClearButton();
							 browser.sleep(5000).then(function(){console.log("Clicked on Filter Clear Button")});
							

							 subsidary_page.getTextOfFilterDescription();	                     
							
							browser.sleep(5000).then(function(){console.log("Sleep For verification")});
						
					  });


				      it('Subsidiary_Management_044:Verify that user is able to Navigate Create Subsidiary screen.',function(){
						     console.log('Subsidiary_Management_044 started execution');
							 var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');							 
							 var subsidary_CreatePage=subsidary_page.clickOnCreateButton();
							 console.log('Navigate to create subsidary screen'+browser.getCurrentUrl());
							 expect(browser.getCurrentUrl()).toContain("/create");
						});	

						
					it('Subsidiary_Management_045:Verify default elements of Create Subsidiary screen.',function(){
						    console.log('Subsidiary_Management_045 started execution');
							 var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
							  var status = false;
							 var subsidary_CreatePage=subsidary_page.clickOnCreateButton();
						     subsidary_CreatePage.creatSubsidaryCodeIsPresent();
							 subsidary_CreatePage.creatSubsidaryDescriptionIsPresent();
							 subsidary_CreatePage.creatSubsidaryValidFromIsPresent();
							 subsidary_CreatePage.creatSubsidaryValidToIsPresent();
							 subsidary_CreatePage.creatSubsidaryCancelButtonIsPresent();
							 subsidary_CreatePage.creatSubsidarySaveButtonIsPresent();						
							
						});	
						
					it('Subsidiary_Management_046,47,48,49:Verify that user is able to create a new Subsidiary and Newly created subsidary present in Grid',function(){
						     console.log('Subsidiary_Management_046 started execution');
						     var testData=require('../../../testData/subsidaryData.json');
							 var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
							  var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
							 var status = false;
							 var subsidary_CreatePage=subsidary_page.clickOnCreateButton();
							 browser.sleep(10000).then(function(){console.log("Create Button Clicked")});
							 
							 subsidary_CreatePage.eneterTextInCreateSubsidaryCode(testData.subsidary.createData.SubsidiaryCode);
							 subsidary_CreatePage.eneterTextInCreateSubsidaryDescription(testData.subsidary.createData.Description);
							 subsidary_CreatePage.eneterTextInValidDateFrom(testData.subsidary.createData.ValidFrom);
							 subsidary_CreatePage.eneterTextInValidDateTo(testData.subsidary.createData.ValidTo);
							 subsidary_page=subsidary_CreatePage.clickOnSaveButton();
							 browser.sleep(15000).then(function(){console.log("Sleep after save button clicked")});
							 home_page.clickSubDirectlyOrClickMasterDataFirst();
							 browser.sleep(5000).then(function(){console.log("Clicked on subsidary")});
							 subsidary_page.clickOnFilterButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Filter button clicked")});
							 subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
							 subsidary_page.selectParticularSubCode(testData.subsidary.createData.SubsidiaryCode);
							  browser.sleep(5000).then(function(){console.log("Sleep after selectParticularSubCode")});
							 subsidary_page.clickOnFilterApplyButton();
							 browser.sleep(10000).then(function(){console.log("Sleep after Filter button clicked")});
							 subsidary_page.firstRowFromTableIsPresent();
							 subsidary_page.getDataOfFirstRowParticularColumn(2,testData.subsidary.createData.SubsidiaryCode);	
                             subsidary_page.getDataOfFirstRowParticularColumn(3,testData.subsidary.createData.Description);	

							 //Verification for Subsidiary_Management_049
							 subsidary_page.getDataOfFirstRowParticularColumn(6,'');	
                             subsidary_page.getDataOfFirstRowParticularColumn(7,'');	


                             var details_Subsidary_Page=subsidary_page.clickOnfirstRowSubsidaryCode();	
							 browser.sleep(5000).then(function(){console.log("Clicked on subsidary code")});	   
                             expect(browser.getCurrentUrl()).toContain("/subsidiaries/details")
							 details_Subsidary_Page.verifyTextOfSubsidaryCode(testData.subsidary.createData.SubsidiaryCode);
							 details_Subsidary_Page.verifyTextOfSubsidaryDescription(testData.subsidary.createData.Description);
                        browser.sleep(5000).then(function(){console.log("Clicked on subsidary code")});

                    });

                    
					it('Subsidiary_Management_75:Verify that Code is unique field.',function(){
						     console.log('Subsidiary_Management_075 started execution');
						     var testData=require('../../../testData/subsidaryData.json');
							 var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
							  var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
							 var status = false;
							 var subsidary_CreatePage=subsidary_page.clickOnCreateButton();
							 browser.sleep(5000).then(function(){console.log("Create Button Clicked")});							
							 
							 subsidary_CreatePage.eneterTextInCreateSubsidaryCode(testData.subsidary.SubsidiaryManagement075.SubsidiaryCode);
							 subsidary_CreatePage.eneterTextInCreateSubsidaryDescription(testData.subsidary.SubsidiaryManagement075.Description);
							 subsidary_CreatePage.eneterTextInValidDateFrom(testData.subsidary.SubsidiaryManagement075.ValidFrom);
							 subsidary_CreatePage.eneterTextInValidDateTo(testData.subsidary.SubsidiaryManagement075.ValidTo);
							 subsidary_page=subsidary_CreatePage.clickOnSaveButton();
							 browser.sleep(20000).then(function(){console.log("Sleep after save button clicked")});
							 home_page.clickSubDirectlyOrClickMasterDataFirst();
							 browser.sleep(5000).then(function(){console.log("Clicked on subsidary")});
							 subsidary_CreatePage=subsidary_page.clickOnCreateButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Create button clicked")});
                             subsidary_CreatePage.eneterTextInCreateSubsidaryCode(testData.subsidary.SubsidiaryManagement075.newSubsidiaryCode);
							 subsidary_CreatePage.eneterTextInCreateSubsidaryDescription(testData.subsidary.SubsidiaryManagement075.newDescription);
							 subsidary_CreatePage.eneterTextInValidDateFrom(testData.subsidary.SubsidiaryManagement075.newValidFrom);
							 subsidary_CreatePage.eneterTextInValidDateTo(testData.subsidary.SubsidiaryManagement075.newValidTo);
                             subsidary_CreatePage.clickOnSaveButton();
							 browser.sleep(20000).then(function(){console.log("Sleep after save button clicked")});
							 //Verify Erro Message
							 subsidary_CreatePage.verifyTextOfErrorMessage(testData.subsidary.SubsidiaryManagement075.errorMsg);
							 subsidary_CreatePage.clickOnCancelButton();                             
                             browser.sleep(5000).then(function(){console.log("Sleep after cancel button clicked")});
							 subsidary_CreatePage.clickOnCanacelPopUpOk();
                             browser.sleep(5000).then(function(){console.log("Sleep after cancel OK button clicked")});

                              //Verification of old subsidary is not modified
							 //home_page.clickSubDirectlyOrClickMasterDataFirst();
							 browser.sleep(5000).then(function(){console.log("Clicked on subsidary")});
                             subsidary_page.clickOnFilterButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Filter button clicked")});
							 subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
							 subsidary_page.selectParticularSubCode(testData.subsidary.SubsidiaryManagement075.SubsidiaryCode);
							 browser.sleep(5000).then(function(){console.log("Sleep after selectParticularSubCode")});
							 subsidary_page.clickOnFilterApplyButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Filter button clicked")});
							 subsidary_page.firstRowFromTableIsPresent();
							 subsidary_page.getDataOfFirstRowParticularColumn(2,testData.subsidary.SubsidiaryManagement075.SubsidiaryCode);	
                             subsidary_page.getDataOfFirstRowParticularColumn(3,testData.subsidary.SubsidiaryManagement075.Description);	
                             subsidary_page.getDataOfFirstRowParticularColumn(4,testData.subsidary.SubsidiaryManagement075.ValidFrom);	
                             subsidary_page.getDataOfFirstRowParticularColumn(5,testData.subsidary.SubsidiaryManagement075.ValidTo); 

							 subsidary_page.selectFirstRecordwithCheckbox();
							 subsidary_page.clickOnDeleteButton();	
							 browser.sleep(5000).then(function(){console.log("Clicked on Delete Button")});	
                             subsidary_page.clickOnDeleteYesButton();
							 browser.sleep(15000).then(function(){console.log("Clicked on Delete Yes Button")});
			    	});	

									
					
					it('Subsidiary_Management_083:Verify that Edit icon is available for each subsidiary record.',function(){
						    console.log('Subsidiary_Management_083 started execution');
							var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
							var status = false;
							subsidary_page.checkEditButtonForEachSubsidary();							
					});	
						
						
					it('Subsidiary_Management_084:Verify that user is able to Navigate Update Subsidiary screen.',function(){
						     console.log('Subsidiary_Management_084 started execution');
							 var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
							 var status = false;
							 browser.driver.sleep(5000);
							 subsidary_page.firstRowFromTableIsPresent();
							 browser.driver.sleep(5000);
						     subsidary_page.clickOnFirstRowsEditButton();								 
							
							 console.log('Navigate Successfully to edit screen');
							 expect(browser.getCurrentUrl()).toContain("/subsidiaries/edit/");
					});	
						

					it('Subsidiary_Management_085:Verify default elements of Update Subsidiary screen.',function(){
						     console.log('Subsidiary_Management_085 started execution');
							 var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
							
							 browser.driver.sleep(5000);
							 subsidary_page.firstRowFromTableIsPresent();
							 browser.driver.sleep(5000);
							 var edit_Subsidary_Page=subsidary_page.clickOnFirstRowsEditButton();
								 
								 edit_Subsidary_Page.editSubsidaryCodeIsPresent(); 
								 edit_Subsidary_Page.editSubsidaryDescriptionIsPresent() ;
								 edit_Subsidary_Page.editSubsidaryValidFromIsPresent();
								 edit_Subsidary_Page.editSubsidaryValidToIsPresent();
								 edit_Subsidary_Page.editSubsidaryCancelButtonIsPresent(); 
								 edit_Subsidary_Page.editSubsidarySaveButtonIsPresent();		
														 
					});		

						
					it('Subsidiary_Management_086:Verify elements of Update Screen when navigated through View Detail screen.',function(){
						     console.log('Subsidiary_Management_086 started execution');
							 var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
							 
							 var status = false;
							 browser.driver.sleep(5000);
							 subsidary_page.firstRowFromTableIsPresent();								 
							 browser.driver.sleep(5000);
							 var details_Subsidary_Page=subsidary_page.clickOnfirstRowSubsidaryCode();								
							 browser.driver.sleep(5000);
							 var edit_Subsidary_Page=details_Subsidary_Page.clickOnDetailsEditButton();								
							 browser.driver.sleep(5000);
							 edit_Subsidary_Page.editSubsidaryCodeIsPresent();
							 edit_Subsidary_Page.editSubsidaryDescriptionIsPresent();
							 edit_Subsidary_Page.editSubsidaryValidFromIsPresent();
							 edit_Subsidary_Page.editSubsidaryValidToIsPresent();
							 edit_Subsidary_Page.editSubsidaryCancelButtonIsPresent();
							 edit_Subsidary_Page.editSubsidarySaveButtonIsPresent();								
							 console.log('Navigate Successfully');							
					 });		
	


                    it('Subsidiary_Management_087,88,90,91:Verify that user is 1.navigated to Subsidiary landing page 2.able to  edit subsidiary, Updated By and Updated On fields for newly created  on View Subsidiary screen 3.user is able to search modified subsidiary record using new Code /     	Description',function(){
						     console.log('Subsidiary_Management_087,88,90.91 started execution');
							 var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
							 var testData=require('../../../testData/subsidaryData.json');
							 var status = false;
							 var flag = false;
							 browser.driver.sleep(5000);
								 
							 subsidary_page.clickOnFilterButton();
							 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});
							 subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
							 browser.sleep(5000).then(function(){console.log("Clicked on subsidary code dropdown")});
							 subsidary_page.selectParticularSubCode(testData.subsidary.SubsidiaryManagement087.OldSubsidiaryCode);
							 subsidary_page.clickOnFilterApplyButton();
							 browser.sleep(5000).then(function(){console.log("Clicked on Apply Button")});
								
							 var edit_Subsidary_Page=subsidary_page.clickOnFirstRowsEditButton();
						     browser.sleep(5000).then(function(){console.log("Clicked on first row edit button Button")});
						 	 edit_Subsidary_Page.clearEditSubsidaryCode();
							 edit_Subsidary_Page.eneterTextInEditSubsidaryCode(testData.subsidary.SubsidiaryManagement087.NewSubsidiaryCode);
							 subsidary_page=edit_Subsidary_Page.clickOnSaveButton();
							  browser.sleep(20000).then(function(){console.log("Clicked on save button")});
							 expect(browser.getCurrentUrl()).toContain(testData.subsidary.SubsidiaryManagement087.UrlContain);
							 browser.sleep(5000).then(function(){console.log("Clicked on subsidary code dropdown")});
							 subsidary_page.clickOnFilterClearButton();
							  browser.sleep(5000).then(function(){console.log("Clicked on Save button")});
								// subsidary_page.clickOnFilterButton();
							 subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
						     browser.sleep(5000).then(function(){console.log("Clicked on subsidary code dropdown")});
							 subsidary_page.selectParticularSubCode(testData.subsidary.SubsidiaryManagement087.NewSubsidiaryCode);
							 subsidary_page.clickOnFilterApplyButton();
						     browser.sleep(5000).then(function(){console.log("Clicked on subsidary code dropdown")});
							 subsidary_page.firstRowFromTableIsPresent();										
							 subsidary_page.getDataOfFirstRowParticularColumn(2,testData.subsidary.SubsidiaryManagement087.NewSubsidiaryCode);

							 subsidary_page.dataForParticularColumnIsPresent(5) ; 
							 subsidary_page.dataForParticularColumnIsPresent(6);
									
							 console.log('Edited Succcessfully');

                        browser.sleep(10000).then(function(){console.log("Clicked on subsidary code dropdown")});
							
					    });		
 
 
                     it('Subsidiary_Management_92:Verify that user is not able to search using old Code.',function(){
						     console.log('Subsidiary_Management_92 started execution');
							 var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
							 var testData=require('../../../testData/subsidaryData.json');
							 var status = false;
							 var flag = false;
							 browser.driver.sleep(5000);
								 
							 subsidary_page.clickOnFilterButton();
							 browser.sleep(5000).then(function(){console.log("Clicked on subsidary code dropdown")});
							 subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
						     browser.sleep(5000).then(function(){console.log("Clicked on subsidary code dropdown")});
							 subsidary_page.selectParticularSubCode(testData.subsidary.SubsidiaryManagement92.OldSubsidiaryCode);
							 subsidary_page.clickOnFilterApplyButton();
							 console.log('22222222');
							 browser.sleep(5000).then(function(){console.log("Clicked on subsidary code dropdown")});
							 var edit_Subsidary_Page=subsidary_page.clickOnFirstRowsEditButton();
							 edit_Subsidary_Page.clearEditSubsidaryCode();
							 browser.sleep(5000).then(function(){console.log("Cleared text subsidary code dropdown")});
							 edit_Subsidary_Page.eneterTextInEditSubsidaryCode(testData.subsidary.SubsidiaryManagement92.NewSubsidiaryCode);
							 subsidary_page=edit_Subsidary_Page.clickOnSaveButton();								 
							 browser.sleep(20000).then(function(){console.log("Clicked on Save button")});
							 subsidary_page.clickOnFilterClearButton();
							  browser.sleep(5000).then(function(){console.log("Clicked on Save button")});
								// subsidary_page.clickOnFilterButton();
							 subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
							 browser.sleep(5000).then(function(){console.log("Clicked on subsidary code dropdown")});
							 subsidary_page.isParticularSubCodeNotPresntDropDown(testData.subsidary.SubsidiaryManagement92.OldSubsidiaryCode);
							//	 expect(subsidary_page.isParticularSubCodePresentInDropDown(testData.subsidary.SubsidiaryManagement92.OldSubsidiaryCode)).toBe(false);

                         browser.sleep(10000).then(function(){console.log("Wait")});
							
					    });
						
							
						it('Subsidiary_Management_117,118:Verify Delete button at upper right corner',function(){
								 console.log('Subsidiary_Management_117,118 started execution');
								 var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');							 
								 var status = false;
								 var flag = false;
								 subsidary_page.deleteButtonIsPresent();								 
								 console.log('Delete button present');
									
								 subsidary_page.checkMultipleRecordsWithCheckBox()
								
								 console.log('selected multiple records');
								 browser.driver.sleep(5000);

								 subsidary_page.clickOnCheckBoxToSelectAllSubsidaryOnPage();
                            browser.sleep(5000).then(function(){console.log("Wait")});
								 subsidary_page.clickOnCheckBoxToSelectAllSubsidaryOnPage();
                            browser.sleep(5000).then(function(){console.log("Wait")});


						  });

						  
					  it('Subsidiary_Management_119:Verify the warning message displayed when Delete button is clicked',function(){
							 console.log('Subsidiary_Management_119 started execution');
							 var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
							 var testData=require('../../../testData/subsidaryData.json');							 
							 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});			 
								
			                 subsidary_page.selectFirstRecordwithCheckbox();
							 browser.sleep(5000).then(function(){console.log("Clicked on selectFirstRecordwithCheckbox")});
							 subsidary_page.clickOnDeleteButton();	
						     browser.sleep(5000).then(function(){console.log("Clicked on DeleteButton ")});
                             subsidary_page.getTextOfDeletePopup();
								
							 subsidary_page.closeIconOfPopUpIsPresent();					 
							 subsidary_page.clickOnCloseIconOfPopUp();							 
							 browser.sleep(5000).then(function(){console.log("Clicked on Close Icon of pop Up")});
							  subsidary_page.selectFirstRecordwithCheckbox();	
							  browser.sleep(5000).then(function(){console.log("Uncheck 1st Record")});                          					 
							
					    });
						
						
                       it('Subsidiary_Management_120:Verify that user is able to Delete single Subsidiary record.',function(){
								console.log('Subsidiary_Management_120 started execution');
								var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
								var testData=require('../../../testData/subsidaryData.json');													
								 
								 subsidary_page.clickOnFilterButton();
								 subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
								 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});	
								 subsidary_page.selectParticularSubCode(testData.subsidary.SubsidiaryManagement120.SelectParticularSubsidaryCode);
								 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});								  
								 subsidary_page.clickOnFilterApplyButton();
						         browser.sleep(5000).then(function(){console.log("Clicked on subsidary code dropdown")});

								 subsidary_page.selectFirstRecordwithCheckbox();
								 subsidary_page.clickOnDeleteButton();	
							     browser.sleep(5000).then(function(){console.log("Clicked on Delete Button")});	
                                 subsidary_page.clickOnDeleteYesButton();
							     browser.sleep(5000).then(function(){console.log("Clicked on Delete Yes Button")});	
								 subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
                                 browser.sleep(5000).then(function(){console.log("Wait")});
								 subsidary_page.isParticularSubCodeNotPresntDropDown(testData.subsidary.SubsidiaryManagement120.SelectParticularSubsidaryCode);	
								 console.log('Entry Deleted successfully'); 

												 
							
					    });
						
						it('Subsidiary_Management_122:Verify the warning message displayed when Delete button is clicked for entire page',function(){
									console.log('Subsidiary_Management_122 started execution');
									var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
										
										
									subsidary_page.clickOnCheckBoxToSelectAllSubsidaryOnPage();
									browser.sleep(5000).then(function(){console.log("Clicked on CheckBoxTo select All subsidary")}); 
									subsidary_page.clickOnDeleteButton();	
									browser.sleep(5000).then(function(){console.log("Clicked on Delete Button")}); 
									subsidary_page.getTextOfDeletePopupForEntirePage();
								
									 subsidary_page.closeIconOfPopUpIsPresent();					 
							         subsidary_page.clickOnCloseIconOfPopUp();	
									browser.sleep(5000).then(function(){console.log("Clicked on Close Icon")});    								 
					     });
               

						  it('Delete sample Data:Verify that user is able to Delete single Subsidiary record.',function(){
								console.log('Delete Sample Data started execution');
								var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
								var testData=require('../../../testData/subsidaryData.json');													
								 
								 subsidary_page.clickOnFilterButton();
								 subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
								 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});	
								 subsidary_page.selectParticularSubCode(testData.subsidary.SubsidiaryManagement122.SelectParticularSubsidaryCode);
								 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});								  
								 subsidary_page.clickOnFilterApplyButton();
						         browser.sleep(5000).then(function(){console.log("Clicked on subsidary code dropdown")});

								 subsidary_page.selectFirstRecordwithCheckbox();
								 subsidary_page.clickOnDeleteButton();	
							     browser.sleep(5000).then(function(){console.log("Clicked on Delete Button")});	
                                 subsidary_page.clickOnDeleteYesButton();
							     browser.sleep(5000).then(function(){console.log("Clicked on Delete Yes Button")});	
								 									 
							
					    });


						
					

                   
				
					
   
	
});  
