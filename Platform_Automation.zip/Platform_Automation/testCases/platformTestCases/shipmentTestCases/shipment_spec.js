describe('Sites page', function() {
	
	                    beforeAll(function() {
								var loginData=require('../../../testData/loginPage.json');
								var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
								browser.ignoreSynchronization = true;
								browser.waitForAngularEnabled(false);
								browser.get(loginData.authentication.login.url);
								browser.sleep(5000).then(function(){console.log("Sleep after url launched")});
								//login_page.clickLoginButton
								//var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
						});
						
	
	
						beforeEach(function(){
						  var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
						  //***************************************************************************************
						    var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
						    login_page.login();
                            browser.sleep(5000).then(function(){console.log("Sleep after url launched")});
							home_page.clickBreadCrum();
							browser.driver.sleep(5000);
							element(by.cssContainingText('.section>a>h3>span', 'Shipment Providers')).click();
							//home_page.clickSitesLink();
							//home_page.clickSitesDirectlyOrClickMasterDataFirst();
							browser.sleep(5000).then(function(){console.log("clicked on Shipment Providers option in Master Data")});
												
						});
						
						
					   afterEach(function(){
						   element(by.css('.header-icon-panel .icon-logout')).click();
						   browser.sleep(10000).then(function(){console.log("Clicked on logout Button")});
					   });	
					/*	   
					    it('Platform_Search_Shipment_Provider_01:Verify the internal user with appropriate permission (Manage G&D Shipment_Providers), able to login platform home page and manage Shipment_Providers', function() {
						 var shipment_page=require('../../../pageObject/platformPOM/shipmentPOM/shipmentPageObject.js');
						  shipment_page.shipmentTextIsPresent();
						 console.log('Platform_Search_Shipment_Provider_01 started execution');
						 expect(browser.getCurrentUrl()).toContain("/shipment-providers");
						 console.log('Current URL :'+browser.getCurrentUrl());
						
					  });
*/
					    it('Platform_Search_Shipment_Provider_08,11: Verify the options for managing Shipment_Providers on Master Data Page', function() {
						 console.log('Platform_Search_Shipment_Provider_08 started execution');
						 var shipment_page=require('../../../pageObject/platformPOM/shipmentPOM/shipmentPageObject.js');
						 browser.sleep(5000).then(function(){console.log("Sleep 5 secs")});
						      shipment_page.shipmentTextIsPresent();
							  shipment_page.shipmentCreateButtonIsPresent();
							  shipment_page.shipmentexportButtonIsPresent();
							  shipment_page.shipmentDeleteButtonIsPresent();
							  shipment_page.shipmentfilterButtonIsPresent();
							  shipment_page.shipmentApplyButtonIsPresent();
							  shipment_page.shipmentClearButtonIsPresent();	
							  shipment_page.shipmentproviderDropdownIsPresent();
							  shipment_page.shipmentDescriptionInputBoxIsPresent();

						});

/*
					  it('Platform_Create_New_Site_065: Verify the type of creation of new Site .', function() {
						 console.log('Platform_Create_New_Site_065 started execution');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 sites_page.clickOnSitesCreateButton();
						 browser.sleep(5000).then(function(){console.log("Sleep 5 secs")});
						 console.log('Navigate to Create Sites screen'+browser.getCurrentUrl());
						
					  });
						  

					  it('Platform_Create_New_Site_066: Verify the type of creation of new Site .', function() {
						 console.log('Platform_Create_New_Site_066 started execution');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sites_CreatePage=sites_page.clickOnSitesCreateButton();
						 //sites_page.clickOnSitesCreateButton();
						 browser.sleep(5000).then(function(){console.log("Sleep 5 secs")});
						 console.log('Navigate to Create Sites screen'+browser.getCurrentUrl());
						   	 sites_CreatePage.createSubsidaryCodeIsPresent();
							 sites_CreatePage.createSiteDescriptionIsPresent();
							 sites_CreatePage.createSiteIsPresent();
							 sites_CreatePage.createSiteCancelButtonIsPresent();
							 sites_CreatePage.createSiteSaveButtonIsPresent();
							 sites_CreatePage.creatSiteValidFromIsPresent();
							 sites_CreatePage.creatSiteValidToIsPresent();
							 
						
					  });
							  


					 it('Platform_Create_New_Site_069,70:Verify the users provision to submit the creation request ',function(){
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sites_CreatePage=sites_page.clickOnSitesCreateButton();
						 var sitesTestData=require('../../../testData/sitesData.json');
						  //sites_page.clickOnSitesCreateButton();
						 browser.sleep(5000).then(function(){console.log("Sleep 5 secs")});
						 console.log('Navigate to Create Sites screen'+browser.getCurrentUrl());

						// for (var i in sitesTestData.sites.createData) {  
						     sites_CreatePage.clickSubsidaryCodeDropdown();
							 sites_CreatePage.enterTextInCreateSubsidaryCodeInputBox(sitesTestData.sites.createData.SubsidiaryCode);
							 sites_CreatePage.SelectSubCodeFromDropDownByEnter();
							 sites_CreatePage.enterTextInCreateSite(sitesTestData.sites.createData.Site); 
							 sites_CreatePage.enterTextInCreateDescription(sitesTestData.sites.createData.Description);
							 sites_CreatePage.enterTextInValidDateFrom(sitesTestData.sites.createData.ValidFrom);
							 sites_CreatePage.enterTextInValidDateTo(sitesTestData.sites.createData.ValidTo);
							 sites_page=sites_CreatePage.clickOnSaveButton();
							 browser.sleep(15000).then(function(){console.log("Sleep after save button clicked")});
						 
							 element(by.cssContainingText('.section>a>h3>span', 'Sites')).click();
							 browser.sleep(5000).then(function(){console.log("Clicked on Sites")});
							 
							  //Verify Site Creation
							 sites_page.clickOnSitesFilterButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Filter button clicked")});
							 sites_page.selectParticularSubCode(sitesTestData.sites.createData.SubsidiaryCode);
							 var enter_sub = browser.actions().sendKeys(protractor.Key.ENTER);
							 enter_sub.perform();						  
							  browser.sleep(3000).then(function(){console.log("Sleep after selectParticularSubCode")});
							 sites_page.clickOnFilterApplyButton();
							 browser.sleep(4000).then(function(){console.log("Sleep after Filter button clicked")});
							 sites_page.firstRowFromTableIsPresent();
							 sites_page.getDataOfFirstRowParticularColumn(2,sitesTestData.sites.createData.SubsidiaryCode);	
                             sites_page.getDataOfFirstRowParticularColumn(3,sitesTestData.sites.createData.Site);	
							 sites_page.getDataOfFirstRowParticularColumn(4,sitesTestData.sites.createData.Description);	

							 //Verification for Subsidiary_Management_049
							  
							 sites_page.getDataOfFirstRowParticularColumn(6,'');	
                             sites_page.getDataOfFirstRowParticularColumn(7,'');	

                             var details_sites_page=sites_page.clickOnfirstRowSubsidaryCode();	
							 browser.sleep(5000).then(function(){console.log("Clicked on subsidary code")});	   
                             expect(browser.getCurrentUrl()).toContain("/sites/details")
							 details_sites_page.verifyTextOfSubsidaryCode(sitesTestData.sites.createData.SubsidiaryCode);
							 details_sites_page.verifyTextOfSitesDescription(sitesTestData.sites.createData.Description);
                        
						});	
						
						it('Platform_Create_New_Site_072:Verify the creation of new Site and prompt user friendly message to the user',function(){
						 console.log('Platform_Create_New_Site_066 started execution');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sites_CreatePage=sites_page.clickOnSitesCreateButton();
						 var sitesTestData=require('../../../testData/sitesData.json');
						  //sites_page.clickOnSitesCreateButton();
						 browser.sleep(5000).then(function(){console.log("Sleep 5 secs")});
						 console.log('Navigate to Create Sites screen'+browser.getCurrentUrl());

						// for (var i in sitesTestData.sites.createData) {  
						     sites_CreatePage.clickSubsidaryCodeDropdown();
							 sites_CreatePage.enterTextInCreateSubsidaryCodeInputBox(sitesTestData.sites.createData.SubsidiaryCode);
							 sites_CreatePage.SelectSubCodeFromDropDownByEnter();
							 sites_CreatePage.enterTextInCreateSite(sitesTestData.sites.createData.Site); 
							 sites_CreatePage.enterTextInCreateDescription(sitesTestData.sites.createData.Description);
							 sites_CreatePage.enterTextInValidDateFrom(sitesTestData.sites.createData.ValidFrom);
							 sites_CreatePage.enterTextInValidDateTo(sitesTestData.sites.createData.ValidTo);
							 sites_page=sites_CreatePage.clickOnSaveButton();
							 browser.sleep(15000).then(function(){console.log("Sleep after save button clicked")});
						 
							 element(by.cssContainingText('.section>a>h3>span', 'Sites')).click();
							 browser.sleep(5000).then(function(){console.log("Clicked on Sites")});
							 
						});	
						
						
						 it('Platform_Create_New_Site_075,76,77:Verify the user cancel the create request',function(){
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sites_CreatePage=sites_page.clickOnSitesCreateButton();
						 var sitesTestData=require('../../../testData/sitesData.json');
						 browser.sleep(5000).then(function(){console.log("Sleep 5 secs")});
						 console.log('Navigate to Create Sites screen'+browser.getCurrentUrl());
						     sites_CreatePage.clickSubsidaryCodeDropdown();
							 sites_CreatePage.enterTextInCreateSubsidaryCodeInputBox(sitesTestData.sites.createData.SubsidiaryCode);
							 sites_CreatePage.SelectSubCodeFromDropDownByEnter();
							 sites_CreatePage.enterTextInCreateSite(sitesTestData.sites.createData.Site); 
							 sites_CreatePage.enterTextInCreateDescription(sitesTestData.sites.createData.Description);
							 sites_CreatePage.enterTextInValidDateFrom(sitesTestData.sites.createData.ValidFrom);
							 sites_CreatePage.enterTextInValidDateTo(sitesTestData.sites.createData.ValidTo);
							 sites_CreatePage.clickOnCancelButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Cancel button clicked")});
							 sites_CreatePage.clickOnCanacelPopUpOk();
                             browser.sleep(5000).then(function(){console.log("Sleep after cancel OK button clicked")});

							 
						});	


						 it('Platform_Create_New_Site_80:Verify the text pattern of Site Code',function(){
						 console.log('Starting Execution of : Platform_Create_New_Site_80');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sites_CreatePage=sites_page.clickOnSitesCreateButton();
						 var sitesTestData=require('../../../testData/sitesData.json');
						 browser.sleep(5000).then(function(){console.log("Sleep 5 secs")});
						 console.log('Navigate to Create Sites screen'+browser.getCurrentUrl());
						     sites_CreatePage.clickSubsidaryCodeDropdown();
							 sites_CreatePage.enterTextInCreateSubsidaryCodeInputBox(sitesTestData.sites.Platform_Create_New_Site_080.SubsidiaryCode);
							 sites_CreatePage.SelectSubCodeFromDropDownByEnter();
							 sites_CreatePage.enterTextInCreateSite(sitesTestData.sites.Platform_Create_New_Site_080.Site); 
							 sites_CreatePage.enterTextInCreateDescription(sitesTestData.sites.Platform_Create_New_Site_080.Description);
							 sites_CreatePage.enterTextInValidDateFrom(sitesTestData.sites.Platform_Create_New_Site_080.ValidFrom);
							 sites_CreatePage.enterTextInValidDateTo(sitesTestData.sites.Platform_Create_New_Site_080.ValidTo);
							 sites_CreatePage.clickOnSaveButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Cancel button clicked")});
							 
						});	

						 it('Platform_Create_New_Site_81:Verify the text pattern of Site Code',function(){
						 console.log('Starting Execution of : Platform_Create_New_Site_81');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sites_CreatePage=sites_page.clickOnSitesCreateButton();
						 var sitesTestData=require('../../../testData/sitesData.json');
						 browser.sleep(5000).then(function(){console.log("Sleep 5 secs")});
						 console.log('Navigate to Create Sites screen'+browser.getCurrentUrl());
						     sites_CreatePage.clickSubsidaryCodeDropdown();
							 sites_CreatePage.enterTextInCreateSubsidaryCodeInputBox(sitesTestData.sites.Platform_Create_New_Site_081.SubsidiaryCode);
							 sites_CreatePage.SelectSubCodeFromDropDownByEnter();
							 sites_CreatePage.enterTextInCreateSite(sitesTestData.sites.Platform_Create_New_Site_081.Site); 
							 sites_CreatePage.enterTextInCreateDescription(sitesTestData.sites.Platform_Create_New_Site_081.Description);
							 sites_CreatePage.enterTextInValidDateFrom(sitesTestData.sites.Platform_Create_New_Site_081.ValidFrom);
							 sites_CreatePage.enterTextInValidDateTo(sitesTestData.sites.Platform_Create_New_Site_081.ValidTo);
							 sites_CreatePage.clickOnSaveButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Save button clicked")});
							 
						});	
						

						it('Platform_Create_New_Site_82:Verify the text pattern of Site Code',function(){
						 console.log('Starting Execution of : Platform_Create_New_Site_82');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sites_CreatePage=sites_page.clickOnSitesCreateButton();
						 var sitesTestData=require('../../../testData/sitesData.json');
						 browser.sleep(5000).then(function(){console.log("Sleep 5 secs")});
						 console.log('Navigate to Create Sites screen'+browser.getCurrentUrl());
						     sites_CreatePage.clickSubsidaryCodeDropdown();
							 sites_CreatePage.enterTextInCreateSubsidaryCodeInputBox(sitesTestData.sites.Platform_Create_New_Site_082.SubsidiaryCode);
							 sites_CreatePage.SelectSubCodeFromDropDownByEnter();
							 sites_CreatePage.enterTextInCreateSite(sitesTestData.sites.Platform_Create_New_Site_082.Site); 
							 sites_CreatePage.enterTextInCreateDescription(sitesTestData.sites.Platform_Create_New_Site_082.Description);
							 sites_CreatePage.enterTextInValidDateFrom(sitesTestData.sites.Platform_Create_New_Site_082.ValidFrom);
							 sites_CreatePage.enterTextInValidDateTo(sitesTestData.sites.Platform_Create_New_Site_082.ValidTo);
							 sites_CreatePage.clickOnSaveButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Save button clicked")});
							 
						});	

						it('Platform_Create_New_Site_82:Verify the text pattern of Site Code',function(){
						 console.log('Starting Execution of : Platform_Create_New_Site_82');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sites_CreatePage=sites_page.clickOnSitesCreateButton();
						 var sitesTestData=require('../../../testData/sitesData.json');
						 browser.sleep(5000).then(function(){console.log("Sleep 5 secs")});
						 console.log('Navigate to Create Sites screen'+browser.getCurrentUrl());
						     sites_CreatePage.clickSubsidaryCodeDropdown();
							 sites_CreatePage.enterTextInCreateSubsidaryCodeInputBox(sitesTestData.sites.Platform_Create_New_Site_082.SubsidiaryCode);
							 sites_CreatePage.SelectSubCodeFromDropDownByEnter();
							 sites_CreatePage.enterTextInCreateSite(sitesTestData.sites.Platform_Create_New_Site_082.Site); 
							 sites_CreatePage.enterTextInCreateDescription(sitesTestData.sites.Platform_Create_New_Site_082.Description);
							 sites_CreatePage.enterTextInValidDateFrom(sitesTestData.sites.Platform_Create_New_Site_082.ValidFrom);
							 sites_CreatePage.enterTextInValidDateTo(sitesTestData.sites.Platform_Create_New_Site_082.ValidTo);
							 sites_CreatePage.clickOnSaveButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Save button clicked")});
							 
						});	

							it('Platform_Create_New_Site_83:Verify the text pattern of Description',function(){
						 console.log('Starting Execution of : Platform_Create_New_Site_83 : Test Description Size_99');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sites_CreatePage=sites_page.clickOnSitesCreateButton();
						 var sitesTestData=require('../../../testData/sitesData.json');
						 browser.sleep(5000).then(function(){console.log("Sleep 5 secs")});
						 console.log('Navigate to Create Sites screen'+browser.getCurrentUrl());
						     sites_CreatePage.clickSubsidaryCodeDropdown();
							 sites_CreatePage.enterTextInCreateSubsidaryCodeInputBox(sitesTestData.sites.Platform_Create_New_Site_083.SubsidiaryCode);
							 sites_CreatePage.SelectSubCodeFromDropDownByEnter();
							 sites_CreatePage.enterTextInCreateSite(sitesTestData.sites.Platform_Create_New_Site_083.Site); 
							 sites_CreatePage.enterTextInCreateDescription(sitesTestData.sites.Platform_Create_New_Site_083.Description);
							 sites_CreatePage.enterTextInValidDateFrom(sitesTestData.sites.Platform_Create_New_Site_083.ValidFrom);
							 sites_CreatePage.enterTextInValidDateTo(sitesTestData.sites.Platform_Create_New_Site_083.ValidTo);
							 sites_CreatePage.clickOnSaveButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Save button clicked")});
							 
						});	

						it('Platform_Create_New_Site_84:Verify the text pattern of Description',function(){
						 console.log('Starting Execution of : Platform_Create_New_Site_84 : Test Description Size_100');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sites_CreatePage=sites_page.clickOnSitesCreateButton();
						 var sitesTestData=require('../../../testData/sitesData.json');
						 browser.sleep(5000).then(function(){console.log("Sleep 5 secs")});
						 console.log('Navigate to Create Sites screen'+browser.getCurrentUrl());
						     sites_CreatePage.clickSubsidaryCodeDropdown();
							 sites_CreatePage.enterTextInCreateSubsidaryCodeInputBox(sitesTestData.sites.Platform_Create_New_Site_084.SubsidiaryCode);
							 sites_CreatePage.SelectSubCodeFromDropDownByEnter();
							 sites_CreatePage.enterTextInCreateSite(sitesTestData.sites.Platform_Create_New_Site_084.Site); 
							 sites_CreatePage.enterTextInCreateDescription(sitesTestData.sites.Platform_Create_New_Site_084.Description);
							 sites_CreatePage.enterTextInValidDateFrom(sitesTestData.sites.Platform_Create_New_Site_084.ValidFrom);
							 sites_CreatePage.enterTextInValidDateTo(sitesTestData.sites.Platform_Create_New_Site_084.ValidTo);
							 sites_CreatePage.clickOnSaveButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Save button clicked")});
						});	

						it('Platform_Create_New_Site_85	:Verify the string more than the max char limit of the field.',function(){
						 console.log('Starting Execution of : Platform_Create_New_Site_85 : Test Description Size_105');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sites_CreatePage=sites_page.clickOnSitesCreateButton();
						 var sitesTestData=require('../../../testData/sitesData.json');
						 browser.sleep(5000).then(function(){console.log("Sleep 5 secs")});
						 console.log('Navigate to Create Sites screen'+browser.getCurrentUrl());
						     sites_CreatePage.clickSubsidaryCodeDropdown();
							 sites_CreatePage.enterTextInCreateSubsidaryCodeInputBox(sitesTestData.sites.Platform_Create_New_Site_085.SubsidiaryCode);
							 sites_CreatePage.SelectSubCodeFromDropDownByEnter();
							 sites_CreatePage.enterTextInCreateSite(sitesTestData.sites.Platform_Create_New_Site_085.Site); 
							 sites_CreatePage.enterTextInCreateDescription(sitesTestData.sites.Platform_Create_New_Site_085.Description);
							 sites_CreatePage.enterTextInValidDateFrom(sitesTestData.sites.Platform_Create_New_Site_085.ValidFrom);
							 sites_CreatePage.enterTextInValidDateTo(sitesTestData.sites.Platform_Create_New_Site_085.ValidTo);
							 sites_CreatePage.clickOnSaveButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Save button clicked")});
						});	

						it('Platform_Create_New_Site_85	:Verify the string more than the max char limit of the field.',function(){
						 console.log('Starting Execution of : Platform_Create_New_Site_85 : Test Description Size_105');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sites_CreatePage=sites_page.clickOnSitesCreateButton();
						 var sitesTestData=require('../../../testData/sitesData.json');
						 browser.sleep(5000).then(function(){console.log("Sleep 5 secs")});
						 console.log('Navigate to Create Sites screen'+browser.getCurrentUrl());
						     sites_CreatePage.clickSubsidaryCodeDropdown();
							 sites_CreatePage.enterTextInCreateSubsidaryCodeInputBox(sitesTestData.sites.Platform_Create_New_Site_085.SubsidiaryCode);
							 sites_CreatePage.SelectSubCodeFromDropDownByEnter();
							 sites_CreatePage.enterTextInCreateSite(sitesTestData.sites.Platform_Create_New_Site_085.Site); 
							 sites_CreatePage.enterTextInCreateDescription(sitesTestData.sites.Platform_Create_New_Site_085.Description);
							 sites_CreatePage.enterTextInValidDateFrom(sitesTestData.sites.Platform_Create_New_Site_085.ValidFrom);
							 sites_CreatePage.enterTextInValidDateTo(sitesTestData.sites.Platform_Create_New_Site_085.ValidTo);
							 sites_CreatePage.clickOnSaveButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Save button clicked")});
						});	

						it('Platform_Create_New_Site_87	:Verify that Site is not created when mandatory field (Site) is missing',function(){
						 console.log('Starting Execution of : Platform_Create_New_Site_87 : Test Description Size_105');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sites_CreatePage=sites_page.clickOnSitesCreateButton();
						 var sitesTestData=require('../../../testData/sitesData.json');
						 browser.sleep(5000).then(function(){console.log("Sleep 5 secs")});
						 console.log('Navigate to Create Sites screen'+browser.getCurrentUrl());
						    
							 sites_CreatePage.clickOnSaveButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Save button clicked")});

							 sites_CreatePage.mandatoryerrormsg_subcode_isPresent(sitesTestData.sites.Platform_Create_New_Site_087.SubCodeErrMsg);
							 sites_CreatePage.mandatoryerrormsg_site_isPresent(sitesTestData.sites.Platform_Create_New_Site_087.SiteErrMsg);
						     sites_CreatePage.mandatoryerrormsg_description_isPresent(sitesTestData.sites.Platform_Create_New_Site_087.DescErrMsg);
							 sites_CreatePage.mandatoryerrormsg_fromDate_isPresent(sitesTestData.sites.Platform_Create_New_Site_087.ValidFromErrMsg);
							 sites_CreatePage.mandatoryerrormsg_toDate_isPresent(sitesTestData.sites.Platform_Create_New_Site_087.ValidToErrMsg);
							  
							 browser.sleep(5000).then(function(){console.log("Sleep after Save button clicked")});

							 //*Verify Erro Message
						
							 //sites_CreatePage.verifyTextOfErrorMessage(testData.subsidary.SubsidiaryManagement075.errorMsg);
							 //sites_CreatePage.clickOnCancelButton();                             
                             //browser.sleep(5000).then(function(){console.log("Sleep after cancel button clicked")});
							 //sites_CreatePage.clickOnCanacelPopUpOk();
                             //browser.sleep(5000).then(function(){console.log("Sleep after cancel OK button clicked")});


						});	



						it('Platform_Create_New_Site_95	:Verify the error message when all the mandatory fields are missing.',function(){
						 console.log('Starting Execution of : Platform_Create_New_Site_87 : Test Description Size_105');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sites_CreatePage=sites_page.clickOnSitesCreateButton();
						 var sitesTestData=require('../../../testData/sitesData.json');
						 browser.sleep(5000).then(function(){console.log("Sleep 5 secs")});
						 console.log('Navigate to Create Sites screen'+browser.getCurrentUrl());
						    
							 sites_CreatePage.clickOnSaveButton();
							 browser.sleep(5000).then(function(){console.log("Sleep after Save button clicked")});

							 sites_CreatePage.mandatoryerrormsg_subcode_isPresent(sitesTestData.sites.Platform_Create_New_Site_087.SubCodeErrMsg);
							 sites_CreatePage.mandatoryerrormsg_site_isPresent(sitesTestData.sites.Platform_Create_New_Site_087.SiteErrMsg);
						     sites_CreatePage.mandatoryerrormsg_description_isPresent(sitesTestData.sites.Platform_Create_New_Site_087.DescErrMsg);
							 sites_CreatePage.mandatoryerrormsg_fromDate_isPresent(sitesTestData.sites.Platform_Create_New_Site_087.ValidFromErrMsg);
							 sites_CreatePage.mandatoryerrormsg_toDate_isPresent(sitesTestData.sites.Platform_Create_New_Site_087.ValidToErrMsg);
							  
							 browser.sleep(5000).then(function(){console.log("Sleep after Save button clicked")});

							 //Verify Erro Message
						
							 //sites_CreatePage.verifyTextOfErrorMessage(testData.subsidary.SubsidiaryManagement075.errorMsg);
							 //sites_CreatePage.clickOnCancelButton();                             
                            //browser.sleep(5000).then(function(){console.log("Sleep after cancel button clicked")});
							 //sites_CreatePage.clickOnCanacelPopUpOk();
                             //browser.sleep(5000).then(function(){console.log("Sleep after cancel OK button clicked")});


						});	
							
					
					 	it('Platform_Search_Site_02:Verify the external user with appropriate permission (Manage G&D Sites), able to login platform home page and manage sites', function() {
						 console.log('Platform_Search_Site_02 started execution');
						  var testData=require('../../../testData/sitesData.json');	
						 expect(browser.getCurrentUrl()).toContain(testData.sites.Platform_Search_Site_02.expected);	
						 console.log('Url='+browser.getCurrentUrl());					
					  });
						
					 	it('Platform_Search_Site_07:Verify that the user navigated to search or landing page of the Manage G&D Sites', function() {
						 console.log('Platform_Search_Site_07 started execution');
						  var testData=require('../../../testData/sitesData.json');	
						 expect(true);	
						 console.log('Url='+browser.getCurrentUrl());					
					  });
						it('Platform_Search_Site_08:Verify the options for managing Sites on Master Data Page', function() {
						 console.log('Platform_Search_Site_08 started execution');
						  var testData=require('../../../testData/sitesData.json');	
						 expect(browser.getCurrentUrl()).toContain(testData.sites.Platform_Search_Site_02.expected);	
						 console.log('Url='+browser.getCurrentUrl());					
					  });
						
					    it('Platform_Search_Site_12:Verify the Search or Filter Button functionality', function() {
						 console.log('Platform_Search_Site_12 started execution');
						  var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						  sites_page.clickOnSitesFilterButton();
						   browser.sleep(10000).then(function(){console.log("Clicked on Filter Button")});
						  sites_page.filter_Clear_ButtonIsPresent();
						  sites_page.filter_Apply_ButtonIsPresent();
						  sites_page.filter_SubsidiaryCode_drpdwnIsPresent();
						  sites_page.filter_DescriptionInputBoxIsPresent();
						  sites_page.filter_SiteInputBoxIsPresent();
                          

					  });

						it('Platform_Search_Site_13:Verify the default page for managing Sites on Master Data Page', function() {
						 console.log('Platform_Search_Site_13 started execution');
						  var testData=require('../../../testData/sitesData.json');	
						 expect(browser.getCurrentUrl()).toContain(testData.sites.Platform_Search_Site_02.expected);	
						 console.log('Url='+browser.getCurrentUrl());					
					  });
				
						it('Platform_Search_Site_14:Verify the default page for managing Sites on Master Data Page', function() {
						 console.log('Platform_Search_Site_02 started execution');
						  var testData=require('../../../testData/sitesData.json');	
						 expect(browser.getCurrentUrl()).toContain(testData.sites.Platform_Search_Site_02.expected);	
						 console.log('Url='+browser.getCurrentUrl());					
					  });
						it('Platform_Search_Site_15:Verify the user clear selected search/filter criteria', function() {
						 console.log('Platform_Search_Site_02 started execution');
						  var testData=require('../../../testData/sitesData.json');	
						 expect(browser.getCurrentUrl()).toContain(testData.sites.Platform_Search_Site_02.expected);	
						 console.log('Url='+browser.getCurrentUrl());					
					  });
					
						 
					    it('Platform_Search_Site_16:Verify the user clear selected search/filter criteria', function() {
						 console.log('Platform_Search_Site_16 started execution');
						   var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 sites_page.clickOnSitesFilterButton();
						 sites_page.checkSitesClearBtnDisabled();
					
					  });

					    it('Platform_Search_Site_17:Verify that user closes Filter pane for Sites', function() {
						 console.log('Platform_Search_Site_17 started execution');
						   var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.closeFilterPane();
						 browser.sleep(5000).then(function(){console.log("Clicked on Close Filter Pane")});
					
					  });

					    it('Platform_Search_Site_18:Verify the selection of search criteria option for managing Sites on Master Data Page', function() {
						 console.log('Platform_Search_Site_18 started execution');
						  status = true;
						   var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 sites_page.clickOnSitesFilterButton();
						  expect(status).toBe(true);
					  });
						it('Platform_Search_Site_19:Verify that Subsidiary Code dropdown displays all subsidiary codes available in the system', function() {
						 console.log('Platform_Search_Site_19 started execution');
						  status = true;
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						sites_page.clickOnFilterSubsidiaryCodeDrpdwn();
						sites_page.clickSubsidiaryCodeList();
						browser.sleep(2000).then(function(){console.log("Clicked on Subsidiary Code DropDown")});

					  });
					  	it('Platform_Search_Site_20:Verify that user is able to select a code from Subsidiary Code dropdown.', function() {
						 console.log('Platform_Search_Site_20 started execution');
						  status = true;
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickOnFilterSubsidiaryCodeDrpdwn();
						 browser.sleep(5000).then(function(){console.log("Clicked on Subsidiary Code DropDown")});
						 //sites_page.clickSubsidiaryCodeList();
						 //browser.sleep(2000).then(function(){console.log("Clicked on Subsidiary Code DropDown")});
						 sites_page.selectFirstElementFromDropDown();
						 browser.sleep(10000).then(function(){console.log("Select 1st element from dropdown")});

					  });
		                it('Platform_Search_Site_21:Verify search functionality by selecting a code from Subsidiary Code dropdown.', function() {
						 console.log('Platform_Search_Site_21 started execution');
						  status = true;
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickOnFilterSubsidiaryCodeDrpdwn();
						 browser.sleep(5000).then(function(){console.log("Clicked on Subsidiary Code DropDown")});
						 sites_page.selectFirstElementFromDropDown();
						 browser.sleep(5000).then(function(){console.log("Select 1st element from dropdown")});
					  });
	
					  it('Platform_Search_Site_22:Verify partial search for Subsidiary Code', function() {
						 console.log('Platform_Search_Site_22 started execution');
						  status = true;
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sitesTestData=require('../../../testData/sitesData.json');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickOnFilterSubsidiaryCodeDrpdwn();
						 browser.sleep(5000).then(function(){console.log("Clicked on Subsidiary Code DropDown")});
 						 sites_page.enterTextInFilterSubsidaryCodeDrpDown(sitesTestData.sites.Platform_Search_Site_22.validSubsidiaryCode);
						 browser.sleep(10000).then(function(){console.log("Sleep after entering invalid subsidary code")});
						 sites_page.isParticularSubCodePresentInDropDown(sitesTestData.sites.Platform_Search_Site_22.validSubsidiaryCode);                 
						 browser.sleep(5000).then(function(){console.log("--isParticularSubCodePresentInDropDown--")});
 						 sites_page.clickOnFilterApplyButton();
						 browser.sleep(5000).then(function(){console.log("Clicked on Apply Button")});
						
					  });
	
					   it('Platform_Search_Site_23:Verify search functionality using Subsidiary Code that do not belong to any subsidiary.', function() {
						 console.log('Platform_Search_Site_23 started execution');
						  status = true;
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sitesTestData=require('../../../testData/sitesData.json');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickOnFilterSubsidiaryCodeDrpdwn();
						 browser.sleep(5000).then(function(){console.log("Clicked on Subsidiary Code DropDown")});
						 sites_page.enterTextInFilterSubsidaryCodeDrpDown(sitesTestData.sites.Platform_Search_Site_23.invalidSubsidiaryCode);
						 browser.sleep(5000).then(function(){console.log("Sleep after entering invalid subsidary code")});
                         sites_page.isParticularProductCodeNotPresntDropDown(sitesTestData.sites.Platform_Search_Site_23.invalidSubsidiaryCode);                 
							
					  });

					   it('Platform_Search_Site_24,126:Verify Suggest Word functionality for Subsidiary Code field.', function() {
						 console.log('Platform_Search_Site_24 and Platform_Delete_Site_126 : started execution');
						  status = true;
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');		
						 var sitesTestData=require('../../../testData/sitesData.json');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickOnFilterSubsidiaryCodeDrpdwn();
						 browser.sleep(5000).then(function(){console.log("Clicked on Subsidiary Code DropDown")});
						sites_page.enterTextInFilterSubsidaryCodeDrpDown(sitesTestData.sites.Platform_Search_Site_24.suggestValidSubcodeText);
						browser.sleep(2000).then(function(){console.log("Enter Text in Sub Code Drop down")});
						sites_page.selectFirstElementFromDropDown();
						 browser.sleep(5000).then(function(){console.log("Select 1st element from dropdown")});
						 sites_page.clickOnFilterApplyButton();
						 browser.sleep(5000).then(function(){console.log("Click Apply")});
						//Delete Site and linked Subsidiary from Sub Screen.
						 sites_page.selectFirstRecordwithCheckbox();
						 sites_page.clickOnSitesDeleteButton();
						 browser.sleep(5000).then(function(){console.log("Clicked on Delete Button")});	
                         sites_page.clickOnSitesDeleteYesButton();
						 browser.sleep(10000).then(function(){console.log("Clicked on Delete Yes Button")});

						// var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
								//var testData=require('../../../testData/subsidaryData.json');													
							 nav_subsidary_page = sites_page.clickOnSubsidiaryNavLink();
							  nav_subsidary_page.clickOnFilterButton();
							  
								 subsidary_page.clickOnFilterButton();
								 subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
								 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});	
								 subsidary_page.selectParticularSubCode(sitesTestData.sites.Platform_Search_Site_24.suggestValidSubcodeText);
								 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});								  
								 subsidary_page.clickOnFilterApplyButton();
						         browser.sleep(5000).then(function(){console.log("Clicked on subsidary code dropdown")});

								 subsidary_page.selectFirstRecordwithCheckbox();
								 subsidary_page.clickOnDeleteButton();	
							     browser.sleep(5000).then(function(){console.log("Clicked on Delete Button")});	
                                 subsidary_page.clickOnDeleteYesButton();
							     browser.sleep(5000).then(function(){console.log("Clicked on Delete Yes Button")});	
								 subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
								 subsidary_page.isParticularSubCodeNotPresntDropDown(sitesTestData.sites.Platform_Search_Site_24.suggestValidSubcodeText);	
								 console.log('Entry Deleted successfully'); 

							 
						  
					  });
//-----------------------

					   it('Platform_Search_Site_25:Verify Suggest Word functionality when entered subsidiary code is not available in the system.', function() {
						 console.log('Platform_Search_Site_25 started execution');
						  status = true;
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sitesTestData=require('../../../testData/sitesData.json');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickOnFilterSubsidiaryCodeDrpdwn();
						 browser.sleep(5000).then(function(){console.log("Clicked on Subsidiary Code DropDown")});
						sites_page.enterTextInFilterSubsidaryCodeDrpDown(sitesTestData.sites.Platform_Search_Site_25.suggestInvalidSubcodeText);
						browser.sleep(2000).then(function(){console.log("Enter Invalid SubCode")});
						sites_page.clickOnFilterApplyButton();
						browser.sleep(5000).then(function(){console.log("Click Apply")});
						  
					  });


					   it('Platform_Search_Site_26:Verify search for wildcard chars (*) for subsidiary code', function() {
						 console.log('Platform_Search_Site_26 started execution');
						  status = true;
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sitesTestData=require('../../../testData/sitesData.json');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickOnFilterSubsidiaryCodeDrpdwn();
						 browser.sleep(5000).then(function(){console.log("Clicked on Subsidiary Code DropDown")});
						 sites_page.enterTextInFilterSubsidaryCodeDrpDown(sitesTestData.sites.Platform_Search_Site_26.wildcard);
						 browser.sleep(2000).then(function(){console.log("Enter WildCard (*) in SubCode")});
						 sites_page.clickOnFilterApplyButton();
						 browser.sleep(5000).then(function(){console.log("Click Apply")});
						 sites_page.firstRowFromTableIsPresent();
						 sites_page.filter_CloseIconIsPresent();					 
						 sites_page.clickOnFilterClearButton();
						 //sites_page.clickfilter_CloseIcon();
						 browser.sleep(5000).then(function(){console.log("Sleep 5 secs")});
						
						  
					  });

					   it('Platform_Search_Site_27:Verify the auto expand ,type ahead functionality during entering/selecting search criteria', function() {
						 console.log('Platform_Search_Site_27 started execution');
						  status = true;
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sitesTestData=require('../../../testData/sitesData.json');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickOnFilterSubsidiaryCodeDrpdwn();
						 browser.sleep(5000).then(function(){console.log("Clicked on Subsidiary Code DropDown")});
						sites_page.enterTextInFilterSubsidaryCodeDrpDown(sitesTestData.sites.Platform_Search_Site_24.suggestValidSubcodeText);
						browser.sleep(2000).then(function(){console.log("Enter Text in Sub Code Drop down")});
						sites_page.selectFirstElementFromDropDown();
						 browser.sleep(5000).then(function(){console.log("Select 1st element from dropdown")});
						 
					  });

					   it('Platform_Search_Site_28:Verify Search Functionality using Description.', function() {
						 console.log('Platform_Search_Site_28 started execution');
						  status = true;
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sitesTestData=require('../../../testData/sitesData.json');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 //sites_page.clickOnFilterSubsidiaryCodeDrpdwn();
						 browser.sleep(5000).then(function(){console.log("Clicked on Subsidiary Code DropDown")});
						 sites_page.enterTextInDescriptionInputBox(sitesTestData.sites.Platform_Search_Site_28.validDescription);
						 browser.sleep(5000).then(function(){console.log("enterTextInDescriptionInputBox")});
						 sites_page.clickOnFilterApplyButton();
						 browser.sleep(5000).then(function(){console.log("Click Apply")});
						 sites_page.firstRowFromTableIsPresent();
						 sites_page.filter_CloseIconIsPresent();					 
						 sites_page.clickOnFilterClearButton();
						 //sites_page.clickfilter_CloseIcon();
						 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});
						
						  
					  });

					  it('Platform_Search_Site_29:Verify search functionality using Description that do not belong to any subsidiary.', function() {
						 console.log('Platform_Search_Site_29 started execution');
						  status = true;
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sitesTestData=require('../../../testData/sitesData.json');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 //sites_page.clickOnFilterSubsidiaryCodeDrpdwn();
						 browser.sleep(5000).then(function(){console.log("Clicked on Subsidiary Code DropDown")});
						 sites_page.enterTextInDescriptionInputBox(sitesTestData.sites.Platform_Search_Site_29.InvalidDescription);
						 browser.sleep(2000).then(function(){console.log("Enter Invalid Text in Description")});
						 sites_page.clickOnFilterApplyButton();
						 browser.sleep(5000).then(function(){console.log("Select 1st element from dropdown")});
						 sites_page.firstRowFromTableNotPresent();						 
						 console.log('Filtered Succcessfully');
						 sites_page.filter_CloseIconIsPresent();					 
						 sites_page.clickOnFilterClearButton();
						 //sites_page.clickfilter_CloseIcon();
						 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});
							 
					  });

					    it('Platform_Search_Site_30:Verify search subsidiary functionality by "Description" filter', function() {
						 console.log('Platform_Search_Site_30 started execution');
						  status = true;
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sitesTestData=require('../../../testData/sitesData.json');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.enterTextInDescriptionInputBox(sitesTestData.sites.Platform_Search_Site_30.InvalidDescription);
						 browser.sleep(2000).then(function(){console.log("Enter Invalid Text in Description")});
						 sites_page.clickOnFilterApplyButton();
						 browser.sleep(5000).then(function(){console.log("Click Apply Button")});
						 sites_page.firstRowFromTableNotPresent();
						 sites_page.clickOnFilterClearButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Clear Button")});
						 sites_page.enterTextInDescriptionInputBox(sitesTestData.sites.Platform_Search_Site_30.validDescription);
						 browser.sleep(2000).then(function(){console.log("Enter Valid Text in Description")});
						 sites_page.clickOnFilterApplyButton();
						 sites_page.firstRowFromTableIsPresent();
						 sites_page.filter_CloseIconIsPresent();					 
						 sites_page.clickOnFilterClearButton();
						 //sites_page.clickfilter_CloseIcon();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Clear Button")});
							 
					  });


					  it('Platform_Search_Site_31:Verify search subsidiary functionality by "Description" filter', function() {
						 console.log('Platform_Search_Site_31 started execution');
						  status = true;
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sitesTestData=require('../../../testData/sitesData.json');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickOnFilterSubsidiaryCodeDrpdwn();
						 browser.sleep(5000).then(function(){console.log("Clicked on Subsidiary Code DropDown")});
						 sites_page.enterTextInDescriptionInputBox(sitesTestData.sites.Platform_Search_Site_30.InvalidDescription);
						 browser.sleep(2000).then(function(){console.log("Enter Invalid Text in Description")});
						 sites_page.clickOnFilterApplyButton();
						 browser.sleep(5000).then(function(){console.log("Click Apply Button")});
						 sites_page.firstRowFromTableNotPresent();
						 sites_page.clickOnFilterClearButton();
						 browser.sleep(2000).then(function(){console.log("Sleep 2 secs")});
						 sites_page.enterTextInDescriptionInputBox(sitesTestData.sites.Platform_Search_Site_30.validDescription);
						 browser.sleep(2000).then(function(){console.log("Enter Valid Text in Description")});
						 sites_page.clickOnFilterApplyButton();
						 sites_page.firstRowFromTableIsPresent();
						 sites_page.filter_CloseIconIsPresent();					 
						 sites_page.clickOnFilterClearButton();
						 //sites_page.clickfilter_CloseIcon();
						 browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});
							 
					  });

						 
			 it('Platform_Search_Site_32:Verify search for wildcard chars (*) for Description field.', function() {
						 console.log('Platform_Search_Site_32 started execution');
						  status = true;
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sitesTestData=require('../../../testData/sitesData.json');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.enterTextInDescriptionInputBox(sitesTestData.sites.Platform_Search_Site_32.wildcard);
						 browser.sleep(2000).then(function(){console.log("Enter WildCard (*) in Description")});
						 sites_page.clickOnFilterApplyButton();
						 browser.sleep(5000).then(function(){console.log("Click Apply")});
						 sites_page.firstRowFromTableIsPresent();
						 sites_page.filter_CloseIconIsPresent();					 
						 sites_page.clickOnFilterClearButton();
						 //sites_page.clickfilter_CloseIcon();
						 browser.sleep(5000).then(function(){console.log("Clicked on Filter Close Icon")}); 
					  });

					   it('Platform_Search_Site_47:Verify the search for alphanumeric characters text pattern', function() {
						 console.log('Platform_Search_Site_47 started execution');
						  status = true;
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sitesTestData=require('../../../testData/sitesData.json');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.enterTextInDescriptionInputBox(sitesTestData.sites.Platform_Search_Site_47.alphanumData);
						 browser.sleep(2000).then(function(){console.log("Enter alphanumData in Description")});
						 sites_page.clickOnFilterApplyButton();
						 browser.sleep(5000).then(function(){console.log("Click Apply")});
						 sites_page.firstRowFromTableIsPresent();
						 sites_page.filter_CloseIconIsPresent();					 
						 sites_page.clickOnFilterClearButton();
						 //sites_page.clickfilter_CloseIcon();
						 browser.sleep(5000).then(function(){console.log("Clicked on Filter Close Icon")}); 
					  });

					  it('Platform_Search_Site_48:Verify the search for alphanumeric and special characters text pattern', function() {
						 console.log('Platform_Search_Site_48 started execution');
						  status = true;
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sitesTestData=require('../../../testData/sitesData.json');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.enterTextInDescriptionInputBox(sitesTestData.sites.Platform_Search_Site_48.alphanum_specialChar_Data);
						 browser.sleep(2000).then(function(){console.log("Enter alphanum_specialChar_Data in Description")});
						 sites_page.clickOnFilterApplyButton();
						 browser.sleep(5000).then(function(){console.log("Click Apply")});
						 sites_page.firstRowFromTableIsPresent();
						 sites_page.filter_CloseIconIsPresent();					 
						 sites_page.clickOnFilterClearButton();
						 //sites_page.clickfilter_CloseIcon();
						 browser.sleep(5000).then(function(){console.log("Clicked on Filter Close Icon")}); 
					  });

					   it('Platform_Search_Site_49:Verify the search for alphanumeric and special characters text pattern', function() {
						 console.log('Platform_Search_Site_49 started execution');
						  status = true;
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 var sitesTestData=require('../../../testData/sitesData.json');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.enterTextInDescriptionInputBox(sitesTestData.sites.Platform_Search_Site_48.alphanum_specialChar_Data);
						 browser.sleep(2000).then(function(){console.log("Enter alphanum_specialChar_Data in Description")});
						 sites_page.clickOnFilterApplyButton();
						 browser.sleep(5000).then(function(){console.log("Click Apply")});
						 sites_page.firstRowFromTableIsPresent();
						 sites_page.filter_CloseIconIsPresent();					 
						 sites_page.clickOnFilterClearButton();
						 //sites_page.clickfilter_CloseIcon();
						 browser.sleep(5000).then(function(){console.log("Clicked on Filter Close Icon")}); 
					  });

					   it('Platform_Search_Site_58:Verify the sorting of search result page.', function() {
						 console.log('Platform_Search_Site_58 started execution');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickSortingForSite();
						 browser.sleep(5000).then(function(){console.log("Site Sorting Asc: Sleep 5 secs")});
						 sites_page.clickSortingForSite();
						 browser.sleep(5000).then(function(){console.log("Site Sorting Dsc: Sleep 5 secs")});

					  });

					   it('Platform_Search_Site_59:Verify the sorting of search result page.', function() {
						 console.log('Platform_Search_Site_58 started execution');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickSortingForSubsidiary();
						 browser.sleep(5000).then(function(){console.log("Subsidiary Sorting Asc: Sleep 5 secs")});
						 sites_page.clickSortingForSubsidiary();
						 browser.sleep(5000).then(function(){console.log("Subsidiary Sorting Dsc: Sleep 5 secs")});

					  });
					   it('Platform_Search_Site_60:Verify the sorting of search result page.', function() {
						 console.log('Platform_Search_Site_58 started execution');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickSortingForDescription();
						 browser.sleep(5000).then(function(){console.log("Description Sorting Asc: Sleep 5 secs")});
						 sites_page.clickSortingForDescription();
						 browser.sleep(5000).then(function(){console.log("Description Sorting Dsc: Sleep 5 secs")});

					  });
					   it('Platform_Search_Site_61:Verify the sorting of search result page.', function() {
						 console.log('Platform_Search_Site_61 started execution');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickSortingForSite();
						 browser.sleep(5000).then(function(){console.log("Site Sorting Asc: Sleep 5 secs")});
						 sites_page.clickSortingForSite();
						 browser.sleep(5000).then(function(){console.log("Site-Sorting Desc: Sleep 5 secs")});

					  });

					  it('Platform_Search_Site_62:Verify the sorting of search result page.', function() {
						 console.log('Platform_Search_Site_62 started execution');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickSortingForValidFrom();
						 browser.sleep(5000).then(function(){console.log("Valid From Sorting Asc: Sleep 5 secs")});
						 sites_page.clickSortingForValidFrom();
						 browser.sleep(5000).then(function(){console.log("Valid From Sorting Desc: Sleep 5 secs")});

					  });

					  it('Platform_Search_Site_63:Verify the sorting of search result page.', function() {
						 console.log('Platform_Search_Site_63 started execution');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickSortingForValidTo();
						 browser.sleep(5000).then(function(){console.log("Valid To Sorting Asc: Sleep 5 secs")});
						 sites_page.clickSortingForValidTo();
						 browser.sleep(5000).then(function(){console.log("Valid To Sorting Desc: Sleep 5 secs")});

					  });
						  
//---------------------------------------------------------------
					 
							
							it('Platform_Update_Site_098,99,100,101,102,105,110,113,114,115,116,118 :Verify the user with appropriate permission (Manage G&D Sites), able to update new Site .',function(){
						     console.log('Starting Execution of : Platform_Update_Site_098');
						     var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
							 var sitesTestData=require('../../../testData/sitesData.json');
							 var status = false;
							 browser.driver.sleep(5000);
							 sites_page.firstRowFromTableIsPresent();
							 browser.driver.sleep(5000);
							 var edit_sites_page=sites_page.clickOnFirstRowsEditButton();
						     browser.sleep(5000).then(function(){console.log("Clicked on first row edit button Button")});
							edit_sites_page.clearEditSite();
							edit_sites_page.clearEditDescription();
							edit_sites_page.clearEditValidFrom();
							edit_sites_page.clearEditValidTo();
							edit_sites_page.eneterTextInEditSite(sitesTestData.sites.Platform_Update_Site_098.EditedSite);
							edit_sites_page.eneterTextInEditSiteDescription(sitesTestData.sites.Platform_Update_Site_098.EditDescription);
							edit_sites_page.eneterTextInValidDateFrom(sitesTestData.sites.Platform_Update_Site_098.EditValidFrom);
							edit_sites_page.eneterTextInValidDateTo(sitesTestData.sites.Platform_Update_Site_098.EditValidTo);
							 sites_page=edit_sites_page.clickOnSaveButton();
							 expect(browser.getCurrentUrl()).toContain(sitesTestData.sites.Platform_Update_Site_098.UrlContain);
							 browser.sleep(5000).then(function(){console.log("Clicked on save button")});
							sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
			
						 sites_page.enterTextInSiteInputBox(sitesTestData.sites.Platform_Update_Site_098.EditedSite);
						 browser.sleep(5000).then(function(){console.log("enter Edited Site in SiteInputBox")});

						 sites_page.clickOnFilterApplyButton();
						 browser.sleep(5000).then(function(){console.log("Click Apply")});
						 sites_page.firstRowFromTableIsPresent();
						 browser.sleep(5000).then(function(){console.log("check 1 row available after filter apply")});
						  sites_page.getDataOfFirstRowParticularColumn(3,sitesTestData.sites.Platform_Update_Site_098.EditedSite);
						  sites_page.getDataOfFirstRowParticularColumn(4,sitesTestData.sites.Platform_Update_Site_098.EditDescription);
						  sites_page.getDataOfFirstRowParticularColumn(5,sitesTestData.sites.Platform_Update_Site_098.EditValidFrom);
						  sites_page.getDataOfFirstRowParticularColumn(6,sitesTestData.sites.Platform_Update_Site_098.EditValidTo);
						  sites_page.dataForParticularColumnIsPresent(2) ;
						  sites_page.dataForParticularColumnIsPresent(3) ; 
						  sites_page.dataForParticularColumnIsPresent(4); 
						  sites_page.dataForParticularColumnIsPresent(5); 
						  sites_page.dataForParticularColumnIsPresent(6) ; 
				
						  console.log('Edited Succcessfully');
							
						});	


					  it('Platform_Create_New_Site_068:Verify the users provision to submit the creation request ', function() {
						 var sitesTestData=require('../../../testData/sitesData.json');
							 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						     var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
							 var status = false;
							 browser.sleep(5000).then(function(){console.log("Wait 5 secs before click on Create")});   
							
							 sites_page.clickOnSitesCreateButton();
						    
							 browser.sleep(5000).then(function(){console.log("Create Button Clicked")});   
							
					  });

					  it('Platform_Create_New_Site_069:Verify the users provision to submit the creation request ', function() {
						 console.log('Platform_Create_New_Site_069 started execution');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickSortingForValidTo();
						 browser.sleep(5000).then(function(){console.log("Valid To Sorting Asc: Sleep 5 secs")});
						 sites_page.clickSortingForValidTo();
						 browser.sleep(5000).then(function(){console.log("Valid To Sorting Desc: Sleep 5 secs")});

					  });

					  it('Platform_Create_New_Site_070:Verify the users provision to submit the creation request ', function() {
						 console.log('Platform_Create_New_Site_070 started execution');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickSortingForValidTo();
						 browser.sleep(5000).then(function(){console.log("Valid To Sorting Asc: Sleep 5 secs")});
						 sites_page.clickSortingForValidTo();
						 browser.sleep(5000).then(function(){console.log("Valid To Sorting Desc: Sleep 5 secs")});

					  });

					  it('Platform_Create_New_Site_071:Verify the users provision to submit the creation request ', function() {
						 console.log('Platform_Create_New_Site_071 started execution');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickSortingForValidTo();
						 browser.sleep(5000).then(function(){console.log("Valid To Sorting Asc: Sleep 5 secs")});
						 sites_page.clickSortingForValidTo();
						 browser.sleep(5000).then(function(){console.log("Valid To Sorting Desc: Sleep 5 secs")});

					  });

					  it('Platform_Create_New_Site_072:Verify the creation of new Site and prompt user friendly message to the user', function() {
						 console.log('Platform_Create_New_Site_072 started execution');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickSortingForValidTo();
						 browser.sleep(5000).then(function(){console.log("Valid To Sorting Asc: Sleep 5 secs")});
						 sites_page.clickSortingForValidTo();
						 browser.sleep(5000).then(function(){console.log("Valid To Sorting Desc: Sleep 5 secs")});

					  });
						  it('Platform_Create_New_Site_073:Verify the standard audit details after creation of new Sites', function() {
						 console.log('Platform_Create_New_Site_073 started execution');
						 var sites_page=require('../../../pageObject/platformPOM/sitesPOM/sitesPageObject.js');
						 sites_page.clickOnSitesFilterButton();
						 browser.sleep(2000).then(function(){console.log("Clicked on Filter Button")});
						 sites_page.clickSortingForValidTo();
						 browser.sleep(5000).then(function(){console.log("Valid To Sorting Asc: Sleep 5 secs")});
						 sites_page.clickSortingForValidTo();
						 browser.sleep(5000).then(function(){console.log("Valid To Sorting Desc: Sleep 5 secs")});

					  });
						  
*/	    
});  
