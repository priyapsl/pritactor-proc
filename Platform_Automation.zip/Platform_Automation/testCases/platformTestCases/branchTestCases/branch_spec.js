describe('Branch page', function() {
	
	                    beforeAll(function() {
								var loginData=require('../../../testData/loginPage.json');
								var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
								browser.ignoreSynchronization = true;
								browser.waitForAngularEnabled(false);
								browser.get(loginData.authentication.login.url);
								browser.sleep(5000).then(function(){console.log("Sleep after url launched")});

								//var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
								console.log('Cloooo--11')
								//***********************************************************************
								/*login_page.login();
                                browser.sleep(5000).then(function(){console.log("Sleep after url launched")});*/

						});
						
	
	
						beforeEach(function(){
								/* browser.get('http://10.51.232.73:3000/platform/master-data/subsidiaries');
								//protractor.browser.ignoreSynchronization = true;
								var loginData=require('../../../testData/loginPage.json');
								var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');*/
								var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
								//***************************************************************************************
								var login_page=require('../../../pageObject/LoginPOM/loginPageObject.js');
								login_page.login();
								browser.sleep(10000).then(function(){console.log("Sleep after url launched")});


						
									home_page.clickBreadCrum();
									browser.driver.sleep(5000);
									element(by.cssContainingText('.section>a>h3>span', 'Branches')).click();
									//browser.driver.navigate().refresh();
									browser.sleep(25000).then(function(){console.log("clicked on Products option in Master Data")});
									//ement(by.cssContainingText('.section>a>h3>span','Subsidiaries')).click();							
						
												
						});
						
						
					   afterEach(function(){
						 /*  var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
						   home_page.clickBreadCrum();
						   browser.driver.sleep(5000);*/
						   element(by.css('.header-icon-panel .icon-logout')).click();
						   browser.sleep(10000).then(function(){console.log("Clicked on logout Button")});
					   });

                     it('Create Sample data for Branch:Create Subsidiary',function () {
                        console.log('Sample subsidiary for Branches');
                        var testData=require('../../../testData/branchesData.json');
                       // var products_page=require('../../../pageObject/platformPOM/productsPOM/productsPageObject.js');
                             var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
                            var home_page=require('../../../pageObject/platformPOM/homePOM/homePageObject.js');
                           var status = false;

                       element(by.cssContainingText('.section>a>h3>span', 'Subsidiaries')).click();
                       browser.sleep(25000).then(function(){console.log("clicked on Issuer option in Master Data")});

                       var subsidary_CreatePage=subsidary_page.clickOnCreateButton();
                       browser.sleep(15000).then(function(){console.log("Create Button Clicked")});

                       subsidary_CreatePage.eneterTextInCreateSubsidaryCode(testData.branches.SampleBranchesSubsidiary.SubsidiaryCode);
                       subsidary_CreatePage.eneterTextInCreateSubsidaryDescription(testData.branches.SampleBranchesSubsidiary.Description);
                       subsidary_CreatePage.eneterTextInValidDateFrom(testData.branches.SampleBranchesSubsidiary.validFrom);
                       subsidary_CreatePage.eneterTextInValidDateTo(testData.branches.SampleBranchesSubsidiary.validTo);
                       subsidary_page=subsidary_CreatePage.clickOnSaveButton();
                       browser.sleep(20000).then(function(){console.log("clicked on Save Btn")});
                       console.log('Sample subsidiary created successfully');

               });

                  it('Create Sample Branches data For Issuers',function () {

                    console.log('Sample Issuer for Branches');
                    var testData=require('../../../testData/branchesData.json');


                       element(by.cssContainingText('.section>a>h3>span', 'Issuers')).click();
                       browser.sleep(30000).then(function(){console.log("clicked on Issuer option in Master Data")});

                       var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');
                        var create_Issuer= issuer_page.clickOnIssuerCreateButton();
                       browser.sleep(15000).then(function(){console.log("Clicked on Issuer create button")});
                       create_Issuer.eneterTextInCreateIssuerCode(testData.branches.SampleBranchesIssuerData.issuerCode);
                       create_Issuer.eneterTextInCreateIssuerName(testData.branches.SampleBranchesIssuerData.issuerName);
                       create_Issuer.eneterTextInValidDateFrom(testData.branches.SampleBranchesIssuerData.validFrom);
                       create_Issuer.eneterTextInValidDateTo(testData.branches.SampleBranchesIssuerData.validTo);
                       create_Issuer.clickOnIssuerSubsidiaryDrpDwn();
                        browser.sleep(5000).then(function(){console.log("Issuer Subisdiary Drp Dwn")});
                       create_Issuer.selectParticularIssuerSubsidiaryCode(testData.branches.SampleBranchesIssuerData.SubsidiaryCode);

                       create_Issuer.clickOnDefaultLanguageDrpDwn();
                        browser.sleep(5000).then(function(){console.log("Issuer language Drp Dwn")});
                        create_Issuer.selectParticularLanguage(testData.branches.SampleBranchesIssuerData.language);
                       create_Issuer.eneterTextInNotificationRetentionPeriod(testData.branches.SampleBranchesIssuerData.notificationRetentionPeriod);

                       create_Issuer.clickOnSaveButton();
                        browser.sleep(20000).then(function(){console.log("Click On save btn")});





               });


                 it('sample Branch creation ',function () {
                    console.log('Sample branch creation ');
                     var testData=require('../../../testData/branchesData.json');
                    var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

                   var create_page=    branches_page.clickOnBranchesCreateButton();
                       browser.sleep(15000).then(function(){console.log("Clicked on Create Button")});
                       create_page.eneterTextInCreateBranchCode(testData.branches.SampleBranchesTestData.branchCode);
                       create_page.eneterTextInCreateBranchName(testData.branches.SampleBranchesTestData.branchName);
                       create_page.eneterTextInCreateBranchAddress(testData.branches.SampleBranchesTestData.address);

                       create_page.clickOnIssuerDrpDwn();
                       browser.sleep(5000).then(function(){console.log("Clicked on issuer Drpdwn")});
                       create_page.selectParticularIssuer(testData.branches.SampleBranchesTestData.issuer);

                       create_page.eneterTextInValidDateFrom(testData.branches.SampleBranchesTestData.validFrom);
                       create_page.eneterTextInValidDateTo(testData.branches.SampleBranchesTestData.validTo);
                       create_page.clickOnSaveButton();
                       browser.sleep(20000).then(function(){console.log("Clicked on Save btn")});

                 });






            it('Branch_Management_004:Verify that superadmin user is able to navigate landing page of Branches screen.', function() {
                   console.log('Branch_Management_004 started execution');
                    var testData=require('../../../testData/branchesData.json');
                  // expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);
                   //console.log('Url='+browser.getCurrentUrl());

                          browser.getCurrentUrl().then(function(url) {
                                  console.log("URL= "+ url);
                                  expect(url).toContain(testData.branches.Branch_Management_004.urlContain);
                              });

              });


          it('Branch_Management_005:Verify the default fields available on Branches screen', function() {
          console.log('Branch_Management_005 started execution');
            var testData=require('../../../testData/branchesData.json');
           var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');
         // expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);
          //console.log('Url='+browser.getCurrentUrl());

                 branches_page.brnachesFilterButtonIsPresent();
                 branches_page.branchesCreateButtonIsPresent();
                 branches_page.branchesExoprtOPtionIsPresent();
                 branches_page.branchesTextIsPresent();
                 branches_page.branchesDeleteButtonIsPresent();

     });

      it('Branch_Management_006:Verify the elements of Branches grid.', function() {
          console.log('Branch_Management_006 started execution');
             var testData=require('../../../testData/branchesData.json');
           var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');
         // expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);
          //console.log('Url='+browser.getCurrentUrl());

                 branches_page.checkBoxToSelectAllIsPresent();
                 branches_page.branchCodeIsPresent();
                 branches_page.branchNameIsPresent();
                 branches_page.branchAddressIsPresent();
                 branches_page.branchIssuerIsPresent();
                 branches_page.valid_fromIsPresent();
                 branches_page.valid_ToIsPresent();
                 branches_page.updatedByIsPresent();
                 branches_page.updatedOnIsPresent();


     });

 it('Branch_Management_007:Verify that Branch grid displays all Branches available in the system..', function() {
          console.log('Document_Category_007 started execution');
              var testData=require('../../../testData/branchesData.json');
              var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');
         // expect(browser.getCurrentUrl()).toContain(testData.Products.Platform_Search_Product_05.expected);
          //console.log('Url='+browser.getCurrentUrl());

               branches_page.rowCountInTable();

     });



  xit('Branch_Management_008:Verify that by default Filter panel is Collapsed.', function() {
          console.log('Branch_Management_008 started execution');
            var testData=require('../../../testData/branchesData.json');
              var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');


             branches_page.filter_Clear_ButtonIsNotPresent();
             branches_page.filter_Apply_ButtonIsNotPresent();
             branches_page.filter_CloseIconIsNotPresent();

     });

   it('Branch_Management_009,010:Verify that  Filter panel is expandable.', function() {
          console.log('Branch_Management_009,10 started execution');
            var testData=require('../../../testData/branchesData.json');
              var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

             branches_page.clickOnBrnachesFilterButton();
             browser.sleep(5000).then(function(){console.log("Clicked on filter Button")});

             branches_page.filter_BranchCode_drpdwnIsPresent();
             branches_page.filter_BranchName_drpdwnIsPresent();
             branches_page.filter_Issuer_drpdwnIsPresent();
             branches_page.filter_Clear_ButtonIsPresent();
             branches_page.filter_Apply_ButtonIsPresent();
             branches_page.filter_CloseIconIsPresent();

     });


      xit('Branch_Management_11:Verify that there is a provision Close/Collapse the Filter pane', function() {
          console.log('Branch_Management_011 started execution');
            var testData=require('../../../testData/branchesData.json');
              var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

             branches_page.clickOnBrnachesFilterButton();
             browser.sleep(5000).then(function(){console.log("Clicked on filter Button")});

             branches_page.filter_BranchCode_drpdwnIsPresent();
             branches_page.filter_BranchName_drpdwnIsPresent();
             branches_page.filter_Issuer_drpdwnIsPresent();
             branches_page.filter_Clear_ButtonIsPresent();
             branches_page.filter_Apply_ButtonIsPresent();

             branches_page.clickfilter_CloseIcon();
              browser.sleep(5000).then(function(){console.log("Clicked on filter Button")});
              branches_page.filter_BranchCode_drpdwnIsNotPresent();
             branches_page.filter_BranchName_drpdwnIsNotPresent();
             branches_page.filter_Issuer_drpdwnIsNotPresent();
             branches_page.filter_Clear_ButtonIsNotPresent();
             branches_page.checkBoxToSelectAllIsPresent();



     });


      xit('Branch_Management_12,14,15:Verify that there is a provision Close/Collapse the Filter pane', function() {
          console.log('Branch_Management_012,14,15 started execution');
            var testData=require('../../../testData/branchesData.json');
              var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

             branches_page.clickOnBrnachesFilterButton();
             browser.sleep(5000).then(function(){console.log("Clicked on filter Button")});

             branches_page.clickOnFilterBranchCodeDrpdwn();
             browser.sleep(5000).then(function(){console.log("Clicked on filter branch code drpdwn")});
             branches_page.selectParticularBranchode(testData.branches.Branch_Management_012.branchCode);
              browser.sleep(5000).then(function(){console.log("Selected particular  branch code from drpdwn")});
              branches_page.clickOnFilterApplyButton();
               browser.sleep(5000).then(function(){console.log("Clicked on filter Apply Btn")});
                branches_page.rowCountInTable();

     });


      it('Branch_Management_13:Verify that Branch Code dropdown displays all branch codes available in the system.', function() {
          console.log('Branch_Management_013 started execution');
            var testData=require('../../../testData/branchesData.json');
              var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

             branches_page.clickOnBrnachesFilterButton();
             browser.sleep(5000).then(function(){console.log("Clicked on filter Button")});

             branches_page.clickOnFilterBranchCodeDrpdwn();
             browser.sleep(5000).then(function(){console.log("Clicked on filter branch code drpdwn")});

              branches_page.elementsInBranchCodeDrpDown();
               browser.sleep(5000).then(function(){console.log("Clicked on filter Apply Btn")});


     });



    it('Branch_Management_16:Verify that user is able to enter Branch Code Manually as well', function() {
          console.log('Branch_Management_016 started execution');
            var testData=require('../../../testData/branchesData.json');
              var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

             branches_page.clickOnBrnachesFilterButton();
             browser.sleep(5000).then(function(){console.log("Clicked on filter Button")});

             branches_page.clickOnFilterBranchCodeDrpdwn();
             browser.sleep(5000).then(function(){console.log("Clicked on filter branch code drpdwn")});

              branches_page.enterTextInFilterBranchCodeDrpDown(testData.branches.Branch_Management_016.branchCode);
               browser.sleep(5000).then(function(){console.log("Clicked on filter Apply Btn")});
             branches_page.elementsInBranchCodeDrpDown();

     });

     it('Branch_Management_17,19:Verify partial search for Branch Code', function() {
          console.log('Branch_Management_017,019 started execution');
            var testData=require('../../../testData/branchesData.json');
              var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

             branches_page.clickOnBrnachesFilterButton();
             browser.sleep(5000).then(function(){console.log("Clicked on filter Button")});

             branches_page.clickOnFilterBranchCodeDrpdwn();
             browser.sleep(5000).then(function(){console.log("Clicked on filter branch code drpdwn")});

              branches_page.enterTextInFilterBranchCodeDrpDown(testData.branches.Branch_Management_017.branchCode);
               browser.sleep(5000).then(function(){console.log("Clicked on filter Apply Btn")});
               branches_page.selectFirstElementFromDropDown();
               browser.sleep(5000).then(function(){console.log("Selected 1st record from drp dwn")});
             branches_page.rowCountInTable();

     });





   it('Branch_Management_18,20:Verify search functionality using Branch Code that do not belong to any Branch.', function() {
          console.log('Branch_Management_018,020 started execution');
            var testData=require('../../../testData/branchesData.json');
              var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

             branches_page.clickOnBrnachesFilterButton();
             browser.sleep(5000).then(function(){console.log("Clicked on filter Button")});

             branches_page.clickOnFilterBranchCodeDrpdwn();
             browser.sleep(5000).then(function(){console.log("Clicked on filter branch code drpdwn")});

              branches_page.enterTextInFilterBranchCodeDrpDown(testData.branches.Branch_Management_018.invalidBranchCode);
               browser.sleep(5000).then(function(){console.log("Clicked on filter Apply Btn")});
               branches_page.branchCodeNotPresentInDropDown();



     });


					it('Branch_Management_024:Verify search functionality by Branch name.', function() {
						 console.log('Branch_Management_024 started execution');
						   var testData=require('../../../testData/branchesData.json');	
						     var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');
                            
							branches_page.clickOnBrnachesFilterButton();
                            browser.sleep(5000).then(function(){console.log("Clicked on filter Button")});   

							branches_page.clickOnFilterBranchNameDrpdwn();
							browser.sleep(5000).then(function(){console.log("Clicked on filter branch Name drpdwn")}); 	
                            
							 branches_page.selectParticularBranchName(testData.branches.Branch_Management_024.branchName);
							  browser.sleep(5000).then(function(){console.log("Select particular branchNAme from dropdwn")});   
							  branches_page.clickOnFilterApplyButton();
							    browser.sleep(5000).then(function(){console.log("Clicked on filter Apply Btn")});
							branches_page.rowCountInTable();
							
                        

					});	 

				it('Branch_Management_025:Verify that Branch Name dropdown displays all branch name available in the system.', function() {
						 console.log('Branch_Management_024 started execution');
						   var testData=require('../../../testData/branchesData.json');	
						     var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');
                            
							branches_page.clickOnBrnachesFilterButton();
                            browser.sleep(5000).then(function(){console.log("Clicked on filter Button")});   

							branches_page.clickOnFilterBranchNameDrpdwn();
							browser.sleep(5000).then(function(){console.log("Clicked on filter branch Name drpdwn")}); 	
                            branches_page.elementsInBranchNameDrpDown();
							
							  browser.sleep(5000).then(function(){console.log("Select particular branchNAme from dropdwn")});   
							
                        

					});	 

					it('Branch_Management_029:Verify partial search for Branch Name', function() {
						 console.log('Branch_Management_029 started execution');
						   var testData=require('../../../testData/branchesData.json');	
						     var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');
                            
							branches_page.clickOnBrnachesFilterButton();
                            browser.sleep(5000).then(function(){console.log("Clicked on filter Button")});   

							branches_page.clickOnFilterBranchNameDrpdwn();
							browser.sleep(5000).then(function(){console.log("Clicked on filter branch Name drpdwn")}); 	
                            branches_page.enterTextInFilterBranchNameDrpDown(testData.branches.Branch_Management_029.partialBranchName);
							browser.sleep(5000).then(function(){console.log("enter partial  branchNAme in dropdwn")});   
							branches_page.selectParticularBranchName(testData.branches.Branch_Management_029.branchName);
							browser.sleep(5000).then(function(){console.log("Select particular branchNAme from dropdwn")});
                            branches_page.clickOnFilterApplyButton();
                            browser.sleep(5000).then(function(){console.log("Click on filter apply Button")});
                            branches_page.rowCountInTable();

					});	 
					

					it('Branch_Management_030:Verify search functionality using Branch Name that do not belong to any Branch.', function() {
						 console.log('Branch_Management_030 started execution');
						   var testData=require('../../../testData/branchesData.json');	
						     var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');
                            
							branches_page.clickOnBrnachesFilterButton();
                            browser.sleep(5000).then(function(){console.log("Clicked on filter Button")});   

							branches_page.clickOnFilterBranchNameDrpdwn();
							browser.sleep(5000).then(function(){console.log("Clicked on filter branch Name drpdwn")}); 	
                            branches_page.enterTextInFilterBranchNameDrpDown(testData.branches.Branch_Management_030.invalidBranchName);
							browser.sleep(5000).then(function(){console.log("enter  branchNAme in dropdwn")});   
							branches_page.branchNameNotPresentInDropDown();
							

					});	 

					it('Branch_Management_036:Verify search functionality by Issuer', function() {
						 console.log('Branch_Management_036 started execution');
						   var testData=require('../../../testData/branchesData.json');	
						     var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');
                            
							branches_page.clickOnBrnachesFilterButton();
                            browser.sleep(5000).then(function(){console.log("Clicked on filter Button")});   

							branches_page.clickOnFilterIssuerDrpdwn();
							browser.sleep(5000).then(function(){console.log("Clicked on filter Issuer drpdwn")}); 	
                           branches_page.selectFirstElementFromDropDown();
							browser.sleep(5000).then(function(){console.log("enter  branchNAme in dropdwn")});   
							branches_page.rowCountInTable();
							

					});	 
					

	                it('Branch_Management_037:Verify that Issuer dropdown displays all Issuers available in the system.', function() {
						 console.log('Branch_Management_037 started execution');
						   var testData=require('../../../testData/branchesData.json');	
						     var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');
                            
							branches_page.clickOnBrnachesFilterButton();
                            browser.sleep(5000).then(function(){console.log("Clicked on filter Button")});   

							branches_page.clickOnFilterIssuerDrpdwn();
							browser.sleep(5000).then(function(){console.log("Clicked on filter Issuer drpdwn")});                  
							branches_page.elementsInIssuerDrpDown();				

					});	 

					it('Branch_Management_038:Verify that user is able to select a Issuer from Issuer dropdown.', function() {
						 console.log('Branch_Management_038 started execution');
						   var testData=require('../../../testData/branchesData.json');	
						     var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');
                            
							branches_page.clickOnBrnachesFilterButton();
                            browser.sleep(5000).then(function(){console.log("Clicked on filter Button")});   

							branches_page.clickOnFilterIssuerDrpdwn();
							browser.sleep(5000).then(function(){console.log("Clicked on filter Issuer drpdwn")});                  
							branches_page.selectParticularIssuer(testData.branches.Branch_Management_038.issuer);				
                            browser.sleep(5000).then(function(){console.log("Selected particular issuer from drpdwn")}); 
							branches_page.clickOnFilterApplyButton();
						    browser.sleep(5000).then(function(){console.log("Clicked on filter apply Btn")}); 
							branches_page.rowCountInTable();                      
					});

					it('Branch_Management_041:Verify partial search for Issuer.', function() {
						 console.log('Branch_Management_041 started execution');
						   var testData=require('../../../testData/branchesData.json');	
						     var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');
                            
							branches_page.clickOnBrnachesFilterButton();
                            browser.sleep(5000).then(function(){console.log("Clicked on filter Button")});   

							branches_page.clickOnFilterIssuerDrpdwn();
							browser.sleep(5000).then(function(){console.log("Clicked on filter Issuer drpdwn")});
							branches_page.enterTextInFilterIssuerDrpDown(testData.branches.Branch_Management_041.partialIssuer);
							browser.sleep(5000).then(function(){console.log("Clicked on filter Issuer drpdwn")});                  
							branches_page.isParticularIssuerPresentInDropDown(testData.branches.Branch_Management_041.issuer);				
                            browser.sleep(5000).then(function(){console.log("Selected particular issuer from drpdwn")}); 
							                      
					});

					it('Branch_Management_042:Verify search functionality using Issuer that do not belong to any Branch..', function() {
						 console.log('Branch_Management_042 started execution');
						   var testData=require('../../../testData/branchesData.json');	
						     var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');
                            
							branches_page.clickOnBrnachesFilterButton();
                            browser.sleep(5000).then(function(){console.log("Clicked on filter Button")});   

							branches_page.clickOnFilterIssuerDrpdwn();
							browser.sleep(5000).then(function(){console.log("Clicked on filter Issuer drpdwn")});
							branches_page.enterTextInFilterIssuerDrpDown(testData.branches.Branch_Management_042.invalidIssuer);
							browser.sleep(5000).then(function(){console.log("Clicked on filter Issuer drpdwn")});                  
							branches_page.issuerNotPresentInDropDown();				
                            browser.sleep(5000).then(function(){console.log("Selected particular issuer from drpdwn")}); 
							    
					});	 

					it('Branch_Management_046:Verify that user is able to search Branches using combination of Branch Code and Branch Name filters.', function() {
						 console.log('Branch_Management_046 started execution');
						   var testData=require('../../../testData/branchesData.json');	
						     var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');
                            
							branches_page.clickOnBrnachesFilterButton();
                            browser.sleep(5000).then(function(){console.log("Clicked on filter Button")});   

							branches_page.clickOnFilterBranchCodeDrpdwn();
							browser.sleep(5000).then(function(){console.log("Clicked on filter branchcode drpdwn")});
							branches_page.selectParticularBranchode(testData.branches.Branch_Management_046.branchCode);
							browser.sleep(5000).then(function(){console.log("Selected particular branchcode from drpdwn")});                  
							branches_page.clickOnFilterBranchNameDrpdwn();				
                            browser.sleep(5000).then(function(){console.log("Clicked on filter branch name drpdwn")}); 
						    branches_page.selectParticularBranchName(testData.branches.Branch_Management_046.branchName);
							browser.sleep(5000).then(function(){console.log("Selected particular branchNAme from drpdwn")});
                            branches_page.clickOnFilterApplyButton();
							browser.sleep(5000).then(function(){console.log("Clicked apply btn")});
							branches_page.rowCountInTable();

					});	

						it('Branch_Management_061:Verify that upon clear, all filters are set to default.', function() {
						 console.log('Branch_Management_061 started execution');
						     var testData=require('../../../testData/branchesData.json');	
						     var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');
                            
							branches_page.clickOnBrnachesFilterButton();
                            browser.sleep(5000).then(function(){console.log("Clicked on filter Button")});   

							branches_page.clickOnFilterBranchCodeDrpdwn();
							browser.sleep(5000).then(function(){console.log("Clicked on filter branchcode drpdwn")});
							branches_page.selectParticularBranchode(testData.branches.Branch_Management_061.branchCode);
							browser.sleep(5000).then(function(){console.log("Selected particular branchcode from drpdwn")});                  
							branches_page.clickOnFilterBranchNameDrpdwn();				
                            browser.sleep(5000).then(function(){console.log("Clicked on filter branch name drpdwn")}); 
						    branches_page.selectParticularBranchName(testData.branches.Branch_Management_061.branchName);
							browser.sleep(5000).then(function(){console.log("Selected particular branchNAme from drpdwn")});
                            branches_page.clickOnFilterClearButton();
							browser.sleep(5000).then(function(){console.log("Clicked clear btn")});
							branches_page.clickOnFilterBranchCodeDrpdwn();
							browser.sleep(5000).then(function(){console.log("Clicked on filter branchcode drpdwn")});
							branches_page.getTextOfFilterBranchCodeDrpdown();
							branches_page.clickOnFilterBranchNameDrpdwn();				
                            browser.sleep(5000).then(function(){console.log("Clicked on filter branch name drpdwn")}); 
							branches_page.getTextOfFilterBranchNameDrpdown();


					});	  

					it('Branch_Management_063:Verify that upon clear, all filters are set to default.', function() {
						 console.log('Branch_Management_063 started execution');
						     var testData=require('../../../testData/branchesData.json');	
						     var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');
                            
							branches_page.clickOnBranchesCreateButton();
							 browser.sleep(15000).then(function(){console.log("Clicked on Create button")});

							 browser.getCurrentUrl().then(function(url) {
										console.log("URL= "+ url);
										expect(url).toContain(testData.branches.Branch_Management_063.urlContain);	
									});

					});	 

					it('Branch_Management_064:Verify that user is able to Navigate Create Branch screen..', function() {
						 console.log('Branch_Management_064 started execution');
						     var testData=require('../../../testData/branchesData.json');	
						     var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');
                            
						var branch_CreatePage=branches_page.clickOnBranchesCreateButton();
							 browser.sleep(15000).then(function(){console.log("Clicked on Create button")});

						  branch_CreatePage.createBranchCodeIsPresent();
						  branch_CreatePage.createBranchNameIsPresent();
						  branch_CreatePage.createIssuerDrpDwnIsPresent();
						  branch_CreatePage.createBranchValidFromIsPresent();
						  branch_CreatePage.createBranchValidToIsPresent();
						  branch_CreatePage.createCancelButtonIsPresent();
						  branch_CreatePage.creatBranchSaveButtonIsPresent();


					});	  


					   it('Branch_Management_065,66,67,70,71:Verify that user is able to create a new Branch. ',function () {
						  console.log('Branch_Management_065,66,67,70,71 started execution ');
						   var testData=require('../../../testData/branchesData.json');	
						  var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');
				               
                         var create_page=branches_page.clickOnBranchesCreateButton();
							 browser.sleep(15000).then(function(){console.log("Clicked on Create Button")});
                             create_page.eneterTextInCreateBranchCode(testData.branches.Branch_Management_065.branchCode);
							 create_page.eneterTextInCreateBranchName(testData.branches.Branch_Management_065.branchName);
							 create_page.eneterTextInCreateBranchAddress(testData.branches.Branch_Management_065.address);

							 create_page.clickOnIssuerDrpDwn();
							 browser.sleep(5000).then(function(){console.log("Clicked on issuer Drpdwn")});
							 create_page.selectParticularIssuer(testData.branches.Branch_Management_065.issuer);

							 create_page.eneterTextInValidDateFrom(testData.branches.Branch_Management_065.validFrom);
							 create_page.eneterTextInValidDateTo(testData.branches.Branch_Management_065.validTo);
                             branches_page= create_page.clickOnSaveButton();
                             browser.sleep(20000).then(function(){console.log("Clicked on Save btn")});

                            branches_page.clickOnBrnachesFilterButton();
							browser.sleep(5000).then(function(){console.log("Clicked on Filter btn")});
							branches_page.clickOnFilterBranchCodeDrpdwn();
							browser.sleep(5000).then(function(){console.log("Clicked on Filter branchCode drpdwn")});
							branches_page.selectParticularBranchode(testData.branches.Branch_Management_065.branchCode);
							browser.sleep(5000).then(function(){console.log("Selected branchCode from drpdwn")});
							branches_page.clickOnFilterApplyButton();
							browser.sleep(5000).then(function(){console.log("Clicked on Filter Apply Btn")});
                            branches_page.rowCountInTable();
							branches_page.getTextOfFirstRowBranchCode(testData.branches.Branch_Management_065.branchCode);
							branches_page.getTextOfFirstRowUpdatedBy();
							branches_page.getTextOfFirstRowUpdatedOn();

							var details_page=branches_page.clickOnfirstRowBranchCode();
                           browser.sleep(10000).then(function(){console.log("Clicked on First record")});
							 details_page.verifyTextOfBranchCode(testData.branches.Branch_Management_065.branchCode);
							 details_page.verifyTextOfBranchName(testData.branches.Branch_Management_065.branchName);
							 details_page.verifyTextOfAddress(testData.branches.Branch_Management_065.address);
                             details_page.verifyTextOfUpdatedBy();
                             details_page.verifyTextOfUpdatedOn();
					   });


						it('Branch_Management_085:Verify that * mark is present against each mandatory field ',function () {
							console.log('Branch_Management_085 started execution ');
							var testData=require('../../../testData/branchesData.json');
							var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

							var create_page=branches_page.clickOnBranchesCreateButton();
							browser.sleep(15000).then(function(){console.log("Clicked on Create Button")});
							create_page.branchCodeStarIsPresent();
							create_page.branchNameStarIsPresent();
							create_page.addressStarIsPresent();
							create_page.issuerStarIsPresent();
							create_page.validFromStarIsPresent();
							create_page.validToStarIsPresent();

						});


						it('Branch_Management_086:Verify that Branch is not created when mandatory field (Branch Code) is missing ',function () {
							console.log('Branch_Management_086 started execution ');
							var testData=require('../../../testData/branchesData.json');
							var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

							var create_page=branches_page.clickOnBranchesCreateButton();
							browser.sleep(15000).then(function(){console.log("Clicked on Create Button")});
							create_page.eneterTextInCreateBranchName(testData.branches.Branch_Management_086.branchName);
							create_page.eneterTextInCreateBranchAddress(testData.branches.Branch_Management_086.address);

							create_page.clickOnIssuerDrpDwn();
							browser.sleep(5000).then(function(){console.log("Clicked on issuer Drpdwn")});
							create_page.selectParticularIssuer(testData.branches.Branch_Management_086.issuer);

							create_page.eneterTextInValidDateFrom(testData.branches.Branch_Management_086.validFrom);
							create_page.eneterTextInValidDateTo(testData.branches.Branch_Management_086.validTo);
							create_page.clickOnClearSaveButton();
							browser.sleep(10000).then(function(){console.log("Clicked on Save btn")});
                            create_page.verifyMissingBranchCodeErrorMessage(testData.branches.Branch_Management_086.errorMsg);

                            create_page.eneterTextInCreateBranchCode(testData.branches.Branch_Management_086.branchCode);
                            branches_page=create_page.clickOnSaveButton();
                            browser.sleep(20000).then(function(){console.log("Clicked on Save btn")});

                            branches_page.clickOnBrnachesFilterButton();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter btn")});
                            branches_page.clickOnFilterBranchCodeDrpdwn();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter branchCode drpdwn")});
                            branches_page.selectParticularBranchode(testData.branches.Branch_Management_086.branchCode);
                            browser.sleep(5000).then(function(){console.log("Selected branchCode from drpdwn")});
                            branches_page.clickOnFilterApplyButton();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter Apply Btn")});
                            branches_page.rowCountInTable();

						});

						it('Branch_Management_106:Verify that user can \'Cancel\' the create request. ',function () {
							console.log('Branch_Management_106 started execution ');
							var testData=require('../../../testData/branchesData.json');
							var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

							var create_page=branches_page.clickOnBranchesCreateButton();
							browser.sleep(15000).then(function(){console.log("Clicked on Create Button")});
							branches_page=create_page.clickOnBlankCancelButton();
                            browser.sleep(15000).then(function(){console.log("Clicked on Cancel Button")});

                            browser.getCurrentUrl().then(function(url) {
                                console.log("URL= "+ url);
                                expect(url).toContain(testData.branches.Branch_Management_004.urlContain);
                            });


                        });


						it('Branch_Management_107:Verify that user can \'Cancel\' the create request. ',function () {
							console.log('Branch_Management_107 started execution ');
							var testData = require('../../../testData/branchesData.json');
							var branches_page = require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

							var create_page = branches_page.clickOnBranchesCreateButton();
							browser.sleep(15000).then(function () {console.log("Clicked on Create Button")});
							create_page.eneterTextInCreateBranchCode(testData.branches.Branch_Management_107.branchCode);
							create_page.eneterTextInCreateBranchName(testData.branches.Branch_Management_107.branchName);
							create_page.eneterTextInCreateBranchAddress(testData.branches.Branch_Management_107.address);

							create_page.clickOnIssuerDrpDwn();
							browser.sleep(5000).then(function () {console.log("Clicked on issuer Drpdwn")});
							create_page.selectParticularIssuer(testData.branches.Branch_Management_107.issuer);

							create_page.eneterTextInValidDateFrom(testData.branches.Branch_Management_107.validFrom);
							create_page.eneterTextInValidDateTo(testData.branches.Branch_Management_107.validTo);

							create_page.clickOnCancelButton();
                            browser.sleep(10000).then(function () {console.log("Clicked on Cacnel Btn")});
                            create_page.verifyCancelPopUpMessage();
                            branches_page=create_page.clickOnCanacelPopUpOk();
                            browser.sleep(15000).then(function () {console.log("Clicked on Cacnel Popup OK Btn")});
                            branches_page.clickOnBrnachesFilterButton();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter btn")});
                            branches_page.clickOnFilterBranchCodeDrpdwn();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter branchCode drpdwn")});
                            branches_page.enterTextInFilterBranchCodeDrpDown(testData.branches.Branch_Management_107.branchCode);
                            branches_page.branchCodeNotPresentInDropDown();

						});

						it('Branch_Management_110:Verify that user is able to Navigate \'Manage Branch\' screen.',function () {
							console.log('Branch_Management_110 started execution ');
							var testData=require('../../../testData/branchesData.json');
							var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

							var edit_page=branches_page.clickOnFirstRowsEditButton();
                            browser.sleep(10000).then(function () {console.log("Clicked on Edit Button")});

								browser.getCurrentUrl().then(function(url) {
									console.log("URL= "+ url);
									expect(url).toContain(testData.branches.Branch_Management_110.urlContain);
								});

                        });

						it('Branch_Management_109:Verify that \'Edit\' icon is available for each Branch record..',function () {
							console.log('Branch_Management_109 started execution ');
							var testData=require('../../../testData/branchesData.json');
							var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

                             branches_page.checkEditButtonForIssuer();

						});


						it('Branch_Management_111:Verify default elements of \'Update Branch\' screen..',function () {
							console.log('Branch_Management_111 started execution ');
							var testData=require('../../../testData/branchesData.json');
							var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

							var edit_page=branches_page.clickOnFirstRowsEditButton();
                            browser.sleep(10000).then(function () {console.log("Clicked on Edit Button")});
                            edit_page.editBranchCodeIsPresent();
                            edit_page.editBranchNameIsPresent();
                            edit_page.editBranchAddressIsPresent();
                            edit_page.editBranchCancelButtonIsPresent();
                            edit_page.editBranchSaveButtonIsPresent();

						});

						it('Branch_Management_112:Verify elements of \'Update Screen\' when navigated through View Detail screen.',function () {
							console.log('Branch_Management_112 started execution ');
							var testData=require('../../../testData/branchesData.json');
							var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

							var details_Page=branches_page.clickOnfirstRowBranchCode();
							browser.sleep(5000).then(function () {console.log("Clicked on BranchCode of 1st row")});
							var edit_page=details_Page.clickOnDetailsEditButton();
                            browser.sleep(10000).then(function () {console.log("Clicked on BranchCode of 1st row")});
							edit_page.editBranchCodeIsPresent();
							edit_page.editBranchNameIsPresent();
							edit_page.editBranchAddressIsPresent();
							edit_page.editBranchCancelButtonIsPresent();
							edit_page.editBranchSaveButtonIsPresent();

						});

						it('Branch_Management_113,114:Verify that user is able to edit Branch',function () {
							console.log('Branch_Management_113,114 started execution ');
							var testData=require('../../../testData/branchesData.json');
							var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

							branches_page.clickOnBrnachesFilterButton();
							browser.sleep(5000).then(function () {console.log("Clicked on filter Btn")});
							branches_page.clickOnFilterBranchCodeDrpdwn();
                            browser.sleep(5000).then(function () {console.log("Clicked on Branchcode Drpdwn")});
                            branches_page.selectParticularBranchode(testData.branches.Branch_Management_113.branchCode);
                            browser.sleep(5000).then(function () {console.log("Select Particular BranchCode")});
                            branches_page.clickOnFilterApplyButton();
                            browser.sleep(5000).then(function () {console.log("Clicked on filter Apply Btn")});
							var edit_page=branches_page.clickOnFirstRowsEditButton();
                            browser.sleep(5000).then(function () {console.log("Clicked on First row Edit Btn")});
                            edit_page.clearEditBranchCode();
                            browser.sleep(5000).then(function () {console.log("Cleared first row Branch Code")});
                            edit_page.eneterTextInEditBranchCode(testData.branches.Branch_Management_113.newBranchCode);

							branches_page=edit_page.clickOnSaveButton();
                            browser.sleep(20000).then(function () {console.log("Clicked on Save Btn")});


                            browser.getCurrentUrl().then(function(url) {
                                console.log("URL= "+ url);
                                expect(url).toContain(testData.branches.Branch_Management_113.urlContain);
                            });




                            branches_page.clickOnFilterBranchCodeDrpdwn();
                            browser.sleep(5000).then(function () {console.log("Clicked on BranchCode Drpdwn")});
                            branches_page.selectParticularBranchode(testData.branches.Branch_Management_113.newBranchCode);
                            browser.sleep(5000).then(function () {console.log("Selected particular BranchCode Drpdwn")});
                            branches_page.clickOnFilterApplyButton();
                            browser.sleep(5000).then(function () {console.log("Clicked on Filter Apply Btn")});
                            branches_page.rowCountInTable();
                            branches_page.getTextOfFirstRowBranchCode(testData.branches.Branch_Management_113.newBranchCode);

						});

						it('Branch_Management_150,151,152:Verify elements of \'Update Screen\' when navigated through View Detail screen.',function () {
							console.log('Branch_Management_150,151,152 started execution ');
							var testData=require('../../../testData/branchesData.json');
							var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

							branches_page.branchesDeleteButtonIsPresent();

							branches_page.selectMultipleRecordsWithCheckBox();

							branches_page.clickOnBranchesDeleteButton();
                            browser.sleep(5000).then(function () {console.log("Clicked on Delete Btn")});
                            branches_page.getTextOfDeletePopup();

                            branches_page.clickOnCloseIconOfPopUp();
                            browser.sleep(5000).then(function () {console.log("Clicked on Close ICon Of Popup Btn")});



						});


						it('Branch_Management_153:Verify that user is able to Delete single Branch record.',function () {
							console.log('Branch_Management_153 started execution ');
							var testData=require('../../../testData/branchesData.json');
							var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

							branches_page.clickOnBrnachesFilterButton();
							browser.sleep(5000).then(function () {console.log("Clicked on filter Btn")});
							branches_page.clickOnFilterBranchCodeDrpdwn();
							browser.sleep(5000).then(function () {console.log("Clicked on Branchcode Drpdwn")});
							branches_page.selectParticularBranchode(testData.branches.Branch_Management_153.branchCode);
							browser.sleep(5000).then(function () {console.log("Select Particular BranchCode")});
							branches_page.clickOnFilterApplyButton();
							browser.sleep(5000).then(function () {console.log("Clicked on filter Apply Btn")});
							branches_page.selectFirstRecordwithCheckbox();

							branches_page.clickOnBranchesDeleteButton();
                            browser.sleep(5000).then(function () {console.log("Clicked on Delete Btn")});
                            branches_page.clickOnBranchesDeleteYesButton();
                            browser.sleep(5000).then(function () {console.log("Clicked on Delete Yes Btn")});

                            branches_page.clickOnFilterClearButton();
                            browser.sleep(5000).then(function () {console.log("Clicked on filter Clear Btn")});



							branches_page.clickOnFilterBranchCodeDrpdwn();
							browser.sleep(5000).then(function () {console.log("Clicked on BranchCode Drpdwn")});
							branches_page.enterTextInFilterBranchCodeDrpDown(testData.branches.Branch_Management_153.branchCode);
                            browser.sleep(5000).then(function () {console.log("Text entered in Branchcode drpdwn")});
							branches_page.branchCodeNotPresentInDropDown();
						});

						it('Branch_Management_154,155:Verify that user is able to Delete multiple Branch record.',function () {
							console.log('Branch_Management_154,155 started execution ');
							var testData=require('../../../testData/branchesData.json');
							var branches_page=require('../../../pageObject/platformPOM/branchesPOM/branchesPageObject.js');

							branches_page.clickOnBrnachesFilterButton();
							browser.sleep(5000).then(function () {console.log("Clicked on filter Btn")});
							branches_page.clickOnFilterIssuerDrpdwn();
							browser.sleep(5000).then(function () {console.log("Clicked on Branchcode Drpdwn")});
							branches_page.selectParticularIssuer(testData.branches.Branch_Management_154.issuer);
							browser.sleep(5000).then(function () {console.log("Select Particular BranchCode")});
							branches_page.clickOnFilterApplyButton();
							browser.sleep(5000).then(function () {console.log("Clicked on filter Apply Btn")});
							branches_page.selectAllRecordwithCheckbox();

							branches_page.clickOnBranchesDeleteButton();
							browser.sleep(5000).then(function () {console.log("Clicked on Delete Btn")});
							branches_page.clickOnBranchesDeleteYesButton();
							browser.sleep(10000).then(function () {console.log("Clicked on Delete Yes Btn")});

							branches_page.clickOnFilterClearButton();
							browser.sleep(5000).then(function () {console.log("Clicked on filter Clear Btn")});



							branches_page.clickOnFilterIssuerDrpdwn();
							browser.sleep(5000).then(function () {console.log("Clicked on BranchCode Drpdwn")});
							branches_page.selectParticularIssuer(testData.branches.Branch_Management_154.issuer);
							browser.sleep(5000).then(function () {console.log("Text entered in Branchcode drpdwn")});
                            branches_page.clickOnFilterApplyButton();
                            browser.sleep(5000).then(function () {console.log("Clicked on filter Apply Btn")});

							branches_page.firstRowFromTableNotPresent();
						});

						it('SAmpleIssuer244:Verify that user is able to Delete single  sampleIssuer record.',function () {
							console.log('Issuer_Management_244 started execution');

							var issuer_page=require('../../../pageObject/platformPOM/issuerPOM/issuerPageObject.js');

                            var testData=require('../../../testData/branchesData.json');

                            element(by.cssContainingText('.section>a>h3>span', 'Issuers')).click();
                            browser.sleep(20000).then(function(){console.log("clicked on Issuer option in Master Data")});

							issuer_page.clickOnissuerFilterButton();
							browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});
                            issuer_page.clickOnFilterIssuerCodeDrpdwn();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter issuer Button")});
							issuer_page.selectParticularIssuer(testData.branches.SampleBranchesIssuerData.issuerName);
                            browser.sleep(5000).then(function(){console.log("Select Particular issuer")});
							issuer_page.clickOnFilterApplyButton();
							browser.sleep(5000).then(function(){console.log("Click on filter Apply Btn")});
							issuer_page.selectFirstRecordwithCheckbox();
							issuer_page.clickOnIssuerDeleteButton();
							browser.sleep(5000).then(function(){console.log("Click on Delete Btn")});
							issuer_page.clickOnIssuerDeleteYesButton();
							browser.sleep(10000).then(function(){console.log("Click on Delete Yes Btn")});

						});

						it('Sample_Subsidiary:Verify that user is able to Delete single Subsidiary record.',function(){
							console.log('Delete sample Subsidiary');
							var subsidary_page=require('../../../pageObject/platformPOM/subsidaryPOM/subsidaryPageObject.js');
                            var testData=require('../../../testData/branchesData.json');

                            element(by.cssContainingText('.section>a>h3>span', 'Subsidiaries')).click();
                            browser.sleep(15000).then(function(){console.log("clicked on Issuer option in Master Data")});

							subsidary_page.clickOnFilterButton();
                            browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});
							subsidary_page.clickOnFilterSubsidaryCodeDrpdwn();
							browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});
							subsidary_page.selectParticularSubCode(testData.branches.SampleBranchesSubsidiary.SubsidiaryCode);
							browser.sleep(5000).then(function(){console.log("Clicked on Filter Button")});
							subsidary_page.clickOnFilterApplyButton();
							browser.sleep(5000).then(function(){console.log("Clicked on subsidary code dropdown")});

							subsidary_page.selectFirstRecordwithCheckbox();
                            browser.sleep(5000).then(function(){console.log("Select 1st Records with CheckBox")});
							subsidary_page.clickOnDeleteButton();
							browser.sleep(5000).then(function(){console.log("Clicked on Delete Button")});
							subsidary_page.clickOnDeleteYesButton();
							browser.sleep(5000).then(function(){console.log("Clicked on Delete Yes Button")});

							console.log('Entry Deleted successfully');



						});














});  
