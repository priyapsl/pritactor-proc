// An example configuration file.
//var AllureReporter = require('jasmine-allure-reporter');

var HtmlReporter = require('protractor-beautiful-reporter');

var reporter = new HtmlReporter({
	baseDirectory: '../reports',
    savePath: '../reports/',  
    screenshotsFolder: 'images',
	takeScreenshots: true,
	takeScreenshotsOnlyOnFailures: true,   
    filename: 'Rapid_Automation_Report.html' });


exports.config = {
  directConnect: true,
  //restartBrowserBetweenTests: true, 
  
	  framework: 'jasmine2',
	  

		onPrepare: function () {
			jasmine.getEnv().addReporter(reporter.getJasmine2Reporter());
		    browser.manage().timeouts().implicitlyWait(15000);
		    var AllureReporter = require('jasmine-allure-reporter');
		    jasmine.getEnv().addReporter(new AllureReporter({
		        allureReport: {
			        
		            resultsDir: '../node_modules/jasmine-allure-reporter/'
		        }
		    }))
		   
		    },


  // Capabilities to be passed to the webdriver instance.
  
     /* multiCapabilities: [{
							  'browserName': 'firefox'
							}, {
							  'browserName': 'chrome'
							}],*/
	  capabilities: {
		'browserName': 'chrome'
	  },

  // Framework to use. Jasmine is recommended.
  framework: 'jasmine',

  // Spec patterns are relative to the current working directory when
  // protractor is called.
  specs: ['../testCases/platformTestCases/subsidaryTestCases/*_spec.js'],

  // Options to be passed to Jasmine.
  jasmineNodeOpts: {
    defaultTimeoutInterval: 200000
  },allScriptsTimeout:220000
  
  
};
