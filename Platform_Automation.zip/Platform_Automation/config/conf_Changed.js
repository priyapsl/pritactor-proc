var Jasmine2HtmlReporter = require('protractor-jasmine2-html-reporter');
var path = require('./Protractor_Automation/');
var downloadloc = path.join(__dirname,'\\downloads');
var reporter = new Jasmine2HtmlReporter({
    savePath: './reports/HTML_Reports/',
    screenshotsFolder: './images/',
    takeScreenshots: true,
    takeScreenshotsOnlyOnFailures: true,
    cleanDestination: false,
    fileNameDateSuffix: true,
    filename: 'Rapid_Automation_Report.html',

    metadataBuilder: function(currentSpec, suites, browserCapabilities) {
        return { id: currentSpec.id, os: browserCapabilities.get('browserName') };
    },

    pathBuilder: function(currentSpec, suites, browserCapabilities) {
        // will return IE/your-spec-name.png
        return browserCapabilities.get('browserName') + '/' + currentSpec.fullName;
    },

    showSummary: true,
    showConfiguration: true,
    reportTitle: null,
    showQuickLinks: true
});


exports.config = {
    //restartBrowserBetweenTests: true,
    onPrepare: function() {
        jasmine.getEnv().addReporter(reporter);
    },

    directConnect: true,
    useAllAngular2AppRoots: true,

    // Capabilities to be passed to the webdriver instance.
    capabilities: {
        'browserName': 'chrome',
        prefs: {
       download: {
         'prompt_for_download': false,
         'directory_upgrade': true,
         'default_directory': downloadloc
                  }
             }
    }
/*,
    localSeleniumStandaloneOpts: {
        jvmArgs: ["-Dwebdriver.gecko.driver=D:\\Protractor_Workspace\\node_modules\\protractor\\node_modules\\webdriver-manager\\selenium\\geckodriver-v0.18.0.exe"]
    }*/,

    // Framework to use. Jasmine is recommended.
    framework: 'jasmine',

    // Spec patterns are relative to the current working directory when
    // protractor is called.
   // specs: ['../testCases/platformTestCases/subsidaryTestCases/*_spec.js'],
    //specs: ['../testCases/platformTestCases/subsidaryTestCases/subsidary_spec.js'],
   specs: ['../testCases/platformTestCases/ProductsTestCases/*_spec.js'],
  //  specs: ['../testCases/platformTestCases/issuerTestCases/*_spec.js'],

    // Options to be passed to Jasmine.
    jasmineNodeOpts: {
        defaultTimeoutInterval: 1200000
    },
    allScriptsTimeout:1600000
};

